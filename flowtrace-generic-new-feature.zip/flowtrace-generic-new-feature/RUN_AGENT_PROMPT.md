# Coding Agent Prompt: Drive the Generic New Feature Trace

You are driving the Flowtrace repository in the current folder and modifying the target
application repository specified in `resources/request.md`.

## First Reads

1. Read `docs/ARCHITECTURE.md`.
2. Read `trace.json`.
3. Read `resources/request.md`.
4. Run:
   ```bash
   flowtrace validate
   flowtrace show --fmt ascii
   flowtrace explain reply
   ```

## Run Setup

Create or select a run:

```bash
RUN="$(flowtrace run new --name "<feature name>" | tail -n 1)"
echo "$RUN"
```

Always pass `--run "$RUN"` on every `flowtrace step`, `flowtrace reply`, and
`flowtrace deliverable` write.

## Execute the DAG

Run the six nodes in topological order:

```text
frame_feature
→ design_feature
→ plan_vertical_slices
→ implement_slices
→ verify_and_review
→ deliver_and_handoff
```

For each node:

1. Mark it running:
   ```bash
   flowtrace step <step_id> running --run "$RUN" --message "<what you are doing>"
   ```
2. Read `steps/<step_id>/STEP.md`.
3. Read upstream artifacts referenced by that contract.
4. Create the runtime folder:
   ```bash
   mkdir -p "runs/$RUN/<step_id>"
   ```
5. Write every declared asset into that folder.
6. Mark the node done with one `--asset` flag per step-relative file:
   ```bash
   flowtrace step <step_id> done --run "$RUN"      --message "<concise result>"      --asset <asset_1>      --asset <asset_2>
   ```
7. Write a rich structured reply. Use `flowtrace explain reply` and cite relevant assets.

When blocked:

```bash
flowtrace step <step_id> blocked --run "$RUN"   --message "<specific missing decision, evidence, permission, or dependency>"
```

Stop guessing. Surface the exact blocker.

## Repository Rules

- Treat `resources/request.md` as authority for target repository path, allowed edits,
  forbidden actions, and human approval boundaries.
- Read existing `CONTEXT.md`, `CONTEXT-MAP.md`, ADRs, agent instructions, and similar code.
- Do not formally edit production source, config, scripts, or infrastructure before
  `implement_slices`.
- During `design_feature`, you may update a glossary or ADR and create a clearly marked
  throwaway prototype when the step contract permits it.
- During `implement_slices`, work in an isolated workspace and edit target-repository files
  directly.
- Build one thin vertical slice at a time. For each slice, capture RED → GREEN evidence.
- Prefer tests through public interfaces. Avoid private-method tests and speculative code.
- During `verify_and_review`, inspect the actual target-repository diff and run fresh proof.
- Do not claim completion based on stale output or another agent's report.
- Do not push, open a PR, merge, discard, delete branches, remove worktrees, apply production
  changes, or run destructive migrations unless explicitly authorized.

## Steering

When a design or plan changes, rerun the node and all descendants:

```bash
flowtrace show --downstream <step_id>
```

The CLI lists downstream nodes in topological order. Re-close the deliverable afterward.

## Close the Deliverable

After all nodes are done:

```bash
flowtrace deliverable done --run "$RUN"   --message "Feature implemented, reviewed, verified, and prepared for delivery"   --asset design_feature/feature_design.md   --asset plan_vertical_slices/implementation_plan.md   --asset implement_slices/change_manifest.json   --asset implement_slices/implementation_summary.md   --asset verify_and_review/verification.json   --asset verify_and_review/review_report.md   --asset deliver_and_handoff/delivery_summary.md   --asset deliver_and_handoff/pr_body.md   --asset deliver_and_handoff/handoff.md
```

## Final Response

Summarize:

- feature value and selected design;
- implemented vertical slices;
- target-repository branch, worktree, and files changed;
- fresh verification commands and outcomes;
- review findings;
- delivery state;
- limitations and human actions still required.
