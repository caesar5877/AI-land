# Generic New Feature Trace Memory

Add only lessons that improve future runs of this trace across repositories. Keep
project-specific knowledge in the target repository's `CONTEXT.md`, ADRs, runbooks, or
agent instructions.

## Portable Lessons

- None yet.

## Trace Improvements

- None yet.
