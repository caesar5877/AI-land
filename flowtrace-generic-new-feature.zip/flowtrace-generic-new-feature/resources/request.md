# New Feature Request

Fill this file before starting a Flowtrace run. Unknown fields may remain blank. Do not
guess. This trace is intentionally generic: it supports backend, frontend, full-stack,
data, integration, configuration, infrastructure, and developer-tooling features.

## Target Repository

- **Repository path:** Absolute or clearly resolvable local path.
- **Base branch:** Branch from which isolated feature work should start.
- **Preferred feature branch:** Optional.
- **Allowed file changes:** Source, tests, configuration, scripts, docs, infrastructure.
- **Forbidden changes:** Files, environments, or operations the agent must not modify.
- **Human approval boundaries:** Decisions or actions that require review before proceeding.
- **Project commands:** Setup, focused tests, full tests, build, lint, typecheck, local run.

## Product Need

- **Feature title:**
- **Problem statement:** What problem exists today?
- **Target user or caller:** Who benefits from the feature?
- **Desired outcome:** What capability should exist when work is complete?
- **Business or engineering value:**
- **Priority and deadline:** Optional.
- **Reference issue, PRD, design, or ticket:** Optional.

## Scope

- **Must-have behaviors:**
- **Nice-to-have behaviors:**
- **Explicitly out of scope:**
- **Compatibility expectations:** API, schema, events, data, clients, deployment.
- **Non-functional requirements:** Security, latency, throughput, resilience, accessibility,
  observability, operability, data integrity, or compliance.
- **Rollout and rollback expectations:**

## Existing System Context

- **Relevant modules or services:**
- **Known public interfaces:** API, event, UI, CLI, scheduled job, data contract.
- **Existing domain vocabulary:** Point to `CONTEXT.md` or describe canonical terms.
- **Relevant ADRs or architecture docs:**
- **Known-good examples:** Similar features, tests, modules, or patterns in this repository.
- **Constraints and dependencies:** External teams, services, credentials, schemas, approvals.
- **Open questions:**

## Completion Criteria

- **Acceptance criteria:**
- **Demo or verification scenario:**
- **Required documentation updates:**
- **Delivery expectation:** Local patch, branch, PR draft, pushed branch, or human-approved PR.
