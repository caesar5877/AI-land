# New Feature Request — Example

## Target Repository

- **Repository path:** `/work/notification-platform`
- **Base branch:** `main`
- **Preferred feature branch:** `feature/webhook-retry-policy`
- **Allowed file changes:** Java source, tests, application config, docs.
- **Forbidden changes:** Production deployment and live queue changes.
- **Human approval boundaries:** Stop before schema changes or production rollout.
- **Project commands:** `./mvnw test`, `./mvnw verify`, local integration-test profile.

## Product Need

- **Feature title:** Configurable webhook retry policy.
- **Problem statement:** Failed webhook deliveries use a fixed retry schedule that does not
  meet partner-specific requirements.
- **Target user or caller:** Platform operators configuring partner integrations.
- **Desired outcome:** Operators can select an approved retry policy per partner without code changes.
- **Business or engineering value:** Reduce manual replay work and improve delivery reliability.
- **Priority and deadline:** Current sprint.
- **Reference issue, PRD, design, or ticket:** `NOTIFY-2048`.

## Scope

- **Must-have behaviors:** Validate approved policies, apply the selected policy to new webhook
  deliveries, preserve existing default behavior, emit metrics with the policy name.
- **Nice-to-have behaviors:** Admin preview endpoint.
- **Explicitly out of scope:** Arbitrary user-defined expressions and production rollout automation.
- **Compatibility expectations:** Existing partners continue using the default policy.
- **Non-functional requirements:** No material increase in event-processing latency; clear metrics.
- **Rollout and rollback expectations:** Feature flag and config rollback.

## Existing System Context

- **Relevant modules or services:** Webhook dispatcher, retry scheduler, partner config.
- **Known public interfaces:** Partner config API and webhook delivery events.
- **Existing domain vocabulary:** `Partner`, `DeliveryAttempt`, `RetryPolicy`.
- **Relevant ADRs or architecture docs:** `docs/adr/0012-webhook-retries.md`.
- **Known-good examples:** Existing per-partner timeout configuration.
- **Constraints and dependencies:** Config platform review.
- **Open questions:** Which policies are approved for the first release?

## Completion Criteria

- **Acceptance criteria:** Existing partner behavior remains unchanged; approved policy selection
  changes retry schedule; invalid policy is rejected; metrics contain policy name.
- **Demo or verification scenario:** Integration test with default and custom policies.
- **Required documentation updates:** Operator configuration guide.
- **Delivery expectation:** PR draft.
