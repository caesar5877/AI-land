# Usage Guide

## 1. Install Flowtrace

Use the upstream installation instructions:

```bash
git clone https://github.com/AIScientists-Dev/Flowtrace.git
cd Flowtrace
./scripts/install.sh
```

Ensure `flowtrace` is available on your `PATH`.

## 2. Unzip This Trace

```bash
unzip flowtrace-generic-new-feature.zip
cd flowtrace-generic-new-feature
```

## 3. Bootstrap the Trace Repository

```bash
bash scripts/bootstrap.sh
```

This initializes git when needed, runs an offline structure check, and then runs:

```bash
flowtrace validate
flowtrace lint
flowtrace show --fmt mermaid
```

## 4. Describe the Feature

Edit:

```text
resources/request.md
```

Specify the target repository path, scope, acceptance criteria, allowed edits, forbidden
actions, approval boundaries, and project commands.

## 5. Create a Run

```bash
bash scripts/new-run.sh "implement webhook retry policy"
```

## 6. Drive the Run with a Coding Agent

Give the coding agent:

```text
RUN_AGENT_PROMPT.md
```

The agent should execute the six nodes in dependency order, write runtime assets beneath
`runs/<run_id>/<step_id>/`, and use `flowtrace step` with an explicit `--run` for every write.

## 7. Open the Web UI

```bash
flowtrace serve --open
```

## Notes

- The package defines a reusable method, not a background executor.
- The target application repository is formally edited in `implement_slices`.
- A design revision should steer `design_feature`, followed by all downstream nodes:
  `flowtrace show --downstream design_feature`.
- Push, PR creation, merge, discard, worktree cleanup, and production rollout remain
  human-controlled unless explicitly authorized.
