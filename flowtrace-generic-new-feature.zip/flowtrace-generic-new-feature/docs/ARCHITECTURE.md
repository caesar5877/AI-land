# Generic New Feature Flowtrace Architecture

## Goal

This Flowtrace template turns a feature request into a controlled, reusable software
implementation workflow. It combines Matt Pocock's domain-aware PRD, vertical-slice, prototype,
handoff, and TDD methods with Superpowers' brainstorming, isolated worktree, implementation-plan,
TDD, code-review, verification, and branch-finishing discipline.

The template is intentionally compact. It keeps only six DAG nodes with durable, separately
reviewable artifacts. Internal loops remain inside `STEP.md`.

## System Boundary

The reusable Flowtrace repository is separate from the application repository being modified:

```text
Flowtrace trace repository                         Target application repository
~/traces/generic-new-feature/                      /path/to/application/
├── trace.json                                     ├── src/
├── resources/request.md  ───── points to ───────> ├── tests/
├── steps/                                         ├── config/
└── runs/<run_id>/                                 └── ...
```

The Flowtrace repository stores method contracts, run state, design artifacts, plans, evidence,
and handoff files. The coding agent modifies the target application repository during
`implement_slices`.

## Six-Node DAG

```mermaid
flowchart TD
    A[frame_feature<br/>Define value, scope, and criteria]
    B[design_feature<br/>Resolve interfaces, seams, and risks]
    C[plan_vertical_slices<br/>Create executable tracer bullets]
    D[implement_slices<br/>Edit target repository with TDD]
    E[verify_and_review<br/>Review diff and run fresh proof]
    F[deliver_and_handoff<br/>Prepare PR-ready delivery package]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
```

## Why These Six Nodes?

Each node has its own durable output consumed by a later node:

| Node | Durable decision |
|---|---|
| `frame_feature` | What problem, value, scope, and success criteria define the feature? |
| `design_feature` | What interface and architecture should be implemented? |
| `plan_vertical_slices` | In which thin, verifiable order should the feature be built? |
| `implement_slices` | Which repository files changed and what RED → GREEN evidence exists? |
| `verify_and_review` | Does the actual diff satisfy criteria with fresh proof? |
| `deliver_and_handoff` | What is ready for review, delivery, or continuation? |

The following remain internal loops rather than separate DAG nodes:

```text
Design loop
  ├── inspect existing code and docs
  ├── compare alternatives
  ├── clarify terminology
  ├── prototype a specific unknown when useful
  └── resolve approval boundaries

Implementation loop per slice
  ├── write one behavior test
  ├── observe RED
  ├── implement minimum code
  ├── observe GREEN
  ├── run relevant checks
  └── commit checkpoint
```

## Gates

```text
Feature not framed clearly
    → frame_feature blocked

Design consequential or ambiguous without approval
    → design_feature blocked

No isolated workspace or clean baseline
    → implement_slices blocked

Slice test does not show RED for missing behavior
    → do not implement speculative code

Fresh verification missing or blocking findings remain
    → verify_and_review blocked

Push, merge, discard, cleanup, or rollout not authorized
    → deliver_and_handoff records the required human action
```

## File-Based Data Flow

```text
resources/request.md
  ↓
frame_feature/feature_brief.md
frame_feature/feature_context.json
  ↓
design_feature/feature_design.md
design_feature/design_decisions.json
  ↓
plan_vertical_slices/vertical_slices.json
plan_vertical_slices/implementation_plan.md
plan_vertical_slices/workspace_plan.md
  ↓
implement_slices/slice_results.json
implement_slices/change_manifest.json
implement_slices/implementation_summary.md
  ↓
verify_and_review/verification.json
verify_and_review/review_report.md
  ↓
deliver_and_handoff/delivery_summary.md
deliver_and_handoff/pr_body.md
deliver_and_handoff/handoff.md
```

At runtime, files live beneath `runs/<run_id>/<step_id>/`.

## Modification Policy

| Stage | Formal target-repository edits | Allowed changes |
|---|---:|---|
| `frame_feature` | No | Read code and docs |
| `design_feature` | Limited | Domain glossary, ADR, or clearly marked throwaway prototype |
| `plan_vertical_slices` | No | Plan workspace and likely edits |
| `implement_slices` | Yes | Source, tests, config, scripts, docs, and authorized infrastructure changes |
| `verify_and_review` | Corrective only | Fix blocking findings, remove temporary instrumentation |
| `deliver_and_handoff` | Delivery actions only when authorized | PR draft, authorized push or PR creation, preserved worktree |

## Skill Map

| Workflow concern | Matt Pocock | Superpowers |
|---|---|---|
| Repository setup and domain context | `setup-matt-pocock-skills`, `grill-with-docs` | — |
| Problem and design framing | `to-prd`, optional `prototype` | `brainstorming` |
| Work breakdown | `to-issues` | `writing-plans` |
| Workspace isolation | — | `using-git-worktrees` |
| Implementation | `tdd` | `test-driven-development`, `subagent-driven-development` or `executing-plans` |
| Review and proof | `tdd` behavior seams | `requesting-code-review`, `verification-before-completion` |
| Delivery and continuity | `handoff` | `finishing-a-development-branch` |

## Reuse Model

For each new feature:

1. Replace `resources/request.md`.
2. Commit the new input when you want it in trace history.
3. Create a fresh run.
4. Drive each node in order.
5. Steer a node and re-run descendants when a decision changes.
