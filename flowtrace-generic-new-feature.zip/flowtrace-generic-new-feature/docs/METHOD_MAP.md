# Method Map

## Matt Pocock Skills Used

| Skill | Where used | How it influences this trace |
|---|---|---|
| `setup-matt-pocock-skills` | Repository prerequisite | Establishes issue tracker, glossary, and ADR layout when needed. |
| `to-prd` | `frame_feature`, `design_feature` | Synthesizes the problem, user stories, implementation decisions, and testing decisions. |
| `grill-with-docs` | `design_feature` | Challenges terms and design against `CONTEXT.md`, ADRs, and code. |
| `prototype` | Optional inside `design_feature` | Uses throwaway code to answer a specific UI or logic question. |
| `to-issues` | `plan_vertical_slices` | Produces tracer-bullet vertical slices with HITL and AFK markers. |
| `tdd` | `implement_slices`, `verify_and_review` | Builds one behavior at a time through public interfaces. |
| `handoff` | `deliver_and_handoff` | Produces a compact continuation note referencing existing artifacts. |

## Superpowers Skills Used

| Skill | Where used | How it influences this trace |
|---|---|---|
| `brainstorming` | `frame_feature`, `design_feature` | Understands context, explores alternatives, and obtains design approval. |
| `using-git-worktrees` | Planned in `plan_vertical_slices`, executed in `implement_slices` | Prevents accidental feature work directly on the base branch. |
| `writing-plans` | `plan_vertical_slices` | Creates executable tasks with file paths and verification. |
| `subagent-driven-development` or `executing-plans` | `implement_slices` | Drives approved tasks one at a time. |
| `test-driven-development` | `implement_slices` | Enforces RED → GREEN → REFACTOR. |
| `requesting-code-review` | `verify_and_review` | Reviews spec compliance and code quality before delivery. |
| `verification-before-completion` | `verify_and_review` | Requires fresh command output before completion claims. |
| `finishing-a-development-branch` | `deliver_and_handoff` | Presents controlled delivery options and protects worktree state. |

## Simplification Rule

This trace does not create a DAG node for every skill. A skill becomes its own Flowtrace node
only when it produces a separately reviewable artifact consumed later. Operational details and
repeatable sub-loops remain inside the relevant `STEP.md`.
