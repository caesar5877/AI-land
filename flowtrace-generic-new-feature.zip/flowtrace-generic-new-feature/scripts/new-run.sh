#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v flowtrace >/dev/null 2>&1; then
  echo "ERROR: flowtrace CLI was not found on PATH. Run scripts/bootstrap.sh first." >&2
  exit 1
fi

NAME="${1:-generic new feature}"
RUN_ID="$(flowtrace run new --name "$NAME" | tail -n 1)"

echo "Created Flowtrace run: $RUN_ID"
echo "Request file: resources/request.md"
echo "Coding-agent instructions: RUN_AGENT_PROMPT.md"
echo
echo "Inspect state with:"
echo "  flowtrace run show --run $RUN_ID"
