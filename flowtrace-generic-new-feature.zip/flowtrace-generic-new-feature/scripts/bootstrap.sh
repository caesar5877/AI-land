#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v flowtrace >/dev/null 2>&1; then
  echo "ERROR: flowtrace CLI was not found on PATH." >&2
  echo "Install it first, then rerun this script. See docs/USAGE.md." >&2
  exit 1
fi

python3 scripts/check_template.py

# A trace should keep its own git audit trail even if it was extracted inside another repo.
if [[ ! -e "$ROOT/.git" ]]; then
  git init "$ROOT"
fi

if ! git -C "$ROOT" rev-parse --verify HEAD >/dev/null 2>&1; then
  git -C "$ROOT" add .
  if ! git -C "$ROOT" commit -m "Initialize generic new-feature Flowtrace template"; then
    echo "ERROR: git could not create the initial commit." >&2
    echo "Configure user.name and user.email, then rerun:" >&2
    echo "  git -C \"$ROOT\" add ." >&2
    echo "  git -C \"$ROOT\" commit -m 'Initialize generic new-feature Flowtrace template'" >&2
    exit 1
  fi
fi

flowtrace validate
flowtrace lint || true

echo
echo "Trace graph:"
flowtrace show --fmt mermaid

echo
echo "Bootstrap complete."
echo "Next:"
echo "  1. Edit resources/request.md"
echo "  2. Run: bash scripts/new-run.sh \"feature name\""
echo "  3. Give RUN_AGENT_PROMPT.md to your coding agent"
echo "  4. Run: flowtrace serve --open"
