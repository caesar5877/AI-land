---
name: frame_feature
description: Define the feature problem, repository boundary, and completion criteria.
reads:
  - resources/request.md
writes:
  - feature_brief.md
  - feature_context.json
---

# Frame Feature

## Purpose

Turn the incoming request into a precise feature contract before designing or coding.
Use existing context first. Do not invent requirements.

## Method Alignment

- Matt Pocock `to-prd`: synthesize known context, explore the codebase, use domain vocabulary,
  respect ADRs, and identify high-value test seams.
- Matt Pocock `setup-matt-pocock-skills`: use once per repository when domain-doc layout or
  issue-tracker conventions are missing.
- Superpowers `brainstorming`: understand the current project before proposing a design.

## Read

- `resources/request.md`
- The target repository specified in the request.
- Existing `CONTEXT.md`, `CONTEXT-MAP.md`, ADRs, issue body, design docs, and relevant code.
- Similar implemented features and tests when available.

## Actions

1. Separate the user problem from a prematurely chosen implementation.
2. Identify target users or callers and the concrete value delivered.
3. Record must-have behaviors, out-of-scope items, compatibility expectations, non-functional
   requirements, dependencies, delivery boundary, and acceptance criteria.
4. Explore the existing repository enough to identify:
   - relevant modules and public interfaces;
   - existing domain vocabulary;
   - prior art and patterns;
   - current test seams;
   - constraints encoded in ADRs or code.
5. List unresolved questions. Answer repository-discoverable questions by reading the code
   rather than asking the user.
6. Mark decisions requiring human input clearly. Do not hide uncertainty.
7. Do not modify production source files in this step.

## Gate

A feature cannot move to design until the problem, scope, acceptance criteria, target
repository, and approval boundaries are explicit enough to judge a future design.

## Produce

Write `feature_brief.md`:

```markdown
# Feature Brief
## Problem
## Target User or Caller
## Desired Outcome
## Must-Have Behaviors
## Non-Functional Requirements
## Out of Scope
## Compatibility and Rollout
## Repository Context
## Existing Public Interfaces and Test Seams
## Dependencies
## Human Approval Boundaries
## Open Questions
## Acceptance Criteria
```

Write `feature_context.json`:

```json
{
  "target_repository": {
    "path": "...",
    "base_branch": "...",
    "preferred_feature_branch": "...",
    "allowed_changes": ["..."],
    "forbidden_changes": ["..."],
    "human_approval_boundaries": ["..."]
  },
  "feature_title": "...",
  "must_have_behaviors": ["..."],
  "out_of_scope": ["..."],
  "non_functional_requirements": ["..."],
  "acceptance_criteria": ["..."],
  "relevant_modules": ["..."],
  "public_interfaces": ["..."],
  "existing_test_seams": ["..."],
  "domain_docs": ["..."],
  "open_questions": ["..."]
}
```
