---
name: deliver_and_handoff
description: Prepare delivery options, PR-ready summary, and compact continuation handoff.
reads:
  - design_feature/feature_design.md
  - plan_vertical_slices/implementation_plan.md
  - implement_slices/change_manifest.json
  - implement_slices/implementation_summary.md
  - verify_and_review/verification.json
  - verify_and_review/review_report.md
writes:
  - delivery_summary.md
  - pr_body.md
  - handoff.md
---

# Deliver and Handoff

## Purpose

Prepare a clear delivery package after verification. Do not silently merge, push, delete,
or clean up work. Respect repository policy and the user's requested delivery boundary.

## Method Alignment

- Superpowers `finishing-a-development-branch`: verify before presenting structured branch
  completion options; do not discard or clean up work without the appropriate choice.
- Matt Pocock `handoff`: compact continuation context and reference existing artifacts instead
  of duplicating them.

## Read

- Upstream artifacts listed above.
- Target repository branch, worktree state, commit history, and remote status.
- User-requested delivery expectation from `resources/request.md`.

## Actions

1. Confirm verification remains current.
2. Summarize:
   - feature value;
   - approved design;
   - implemented slices;
   - files changed;
   - fresh verification results;
   - compatibility, rollout, and rollback notes;
   - documentation updates;
   - limitations and human actions.
3. Draft a PR body even when the user has not asked the agent to push or open a PR.
4. Determine the next delivery option consistent with the request:
   - create or update PR, when authorized;
   - push branch only, when authorized;
   - keep branch and worktree as-is;
   - merge locally only with explicit instruction;
   - discard only after explicit typed confirmation.
5. Preserve the worktree for PR iteration unless cleanup is explicitly appropriate.
6. Write a compact handoff that references artifacts by path and suggests relevant skills for
   the next session. Do not repeat the entire plan or diff.

## Gate

Do not merge, push, discard, delete a branch, remove a worktree, or execute production rollout
unless the request explicitly authorizes it or a human approves the action.

## Produce

Write `delivery_summary.md`:

```markdown
# Feature Delivery Summary
## Feature Value
## Approved Design
## Implemented Slices
## Repository Files Changed
## Fresh Verification
## Compatibility, Rollout, and Rollback
## Documentation Updates
## Delivery State
## Limitations and Human Actions
```

Write `pr_body.md`:

```markdown
## Summary
- ...

## Design
- ...

## Vertical Slices Implemented
- ...

## Test Plan
- [ ] ...

## Rollout and Rollback
- ...

## Limitations or Follow-Up
- ...
```

Write `handoff.md`:

```markdown
# New Feature Handoff
## Current State
## Key Artifact Paths
## Target Repository Branch and Worktree
## What Was Implemented
## Verification State
## Remaining Human Actions
## Suggested Next Skills
## Notes for the Next Agent
```
