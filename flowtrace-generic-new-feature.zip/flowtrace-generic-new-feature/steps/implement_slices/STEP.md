---
name: implement_slices
description: Modify repository files one vertical slice at a time with RED-GREEN evidence.
reads:
  - plan_vertical_slices/vertical_slices.json
  - plan_vertical_slices/implementation_plan.md
  - plan_vertical_slices/workspace_plan.md
writes:
  - slice_results.json
  - change_manifest.json
  - implementation_summary.md
---

# Implement Slices

## Purpose

Modify the target repository files directly. Implement one approved vertical slice at a time,
using behavior-level tests and a minimal patch for each cycle.

## Method Alignment

- Matt Pocock `tdd`: public-interface behavior tests and tracer-bullet RED → GREEN loops.
- Superpowers `using-git-worktrees`: isolate feature work and verify a clean baseline.
- Superpowers `test-driven-development`: write a failing test, watch it fail, write minimal
  implementation, watch it pass, then refactor while green.
- Superpowers `subagent-driven-development` or `executing-plans`: execute the approved plan
  slice-by-slice. Use fresh subagents only when the environment supports them and they add value.

## Read

- `../plan_vertical_slices/vertical_slices.json`
- `../plan_vertical_slices/implementation_plan.md`
- `../plan_vertical_slices/workspace_plan.md`
- Target application repository.

## Entry Gate

Before formal edits:

1. Confirm the design is approved or approval is not required.
2. Confirm the worktree or native isolated workspace.
3. Run setup and baseline commands.
4. Confirm the baseline is clean or explicitly document known pre-existing failures.
5. Stop before any forbidden change or human-approval boundary.

## Slice Loop

For each slice in dependency order:

1. Re-read the slice behavior and acceptance criteria.
2. Inspect prior art in the repository.
3. Write one behavior-level test through the highest practical public interface.
4. Run it and capture **RED** for the expected missing behavior.
5. Modify the smallest set of repository files required for **GREEN**.
6. Run the focused test and capture **GREEN**.
7. Run the relevant suite, build, lint, typecheck, static checks, config validation, or
   integration checks required by the slice.
8. Refactor only while green. Avoid speculative functionality.
9. Review the diff against the slice acceptance criteria.
10. Commit at the planned checkpoint when repository policy permits.
11. Record actual changed files, commands, results, and limitations.
12. Move to the next slice only after the current slice is verifiable.

## Important Rules

- Do not write all tests first and all implementation second. That is horizontal slicing.
- Do not test private methods merely because they are easier to reach.
- Do not bypass a failing baseline without recording it.
- Do not add future-slice code prematurely.
- When blocked, mark the Flowtrace step `blocked` with a precise reason instead of guessing.
- When a design flaw emerges, return to `design_feature`, revise the design, and re-run
  downstream nodes.

## Configuration, Infrastructure, and External Integration Features

When a unit test is not the right seam, use a repeatable validation harness such as:

- schema validation;
- Terraform plan;
- deployment dry run;
- contract test;
- event replay;
- integration test;
- environment-level smoke test.

Stop before external apply, production modification, destructive migration, or any declared
human-approval boundary.

## Produce

Write `slice_results.json`:

```json
{
  "workspace": {
    "path": "...",
    "branch": "...",
    "baseline_commands": [
      {"command": "...", "exit_code": 0, "summary": "..."}
    ]
  },
  "slices": [
    {
      "id": "slice_01",
      "status": "done|blocked",
      "red": {"command": "...", "observed": true, "exit_code": 1, "summary": "..."},
      "green": {"command": "...", "observed": true, "exit_code": 0, "summary": "..."},
      "relevant_checks": [
        {"command": "...", "exit_code": 0, "summary": "..."}
      ],
      "commit": "...",
      "limitations": []
    }
  ]
}
```

Write `change_manifest.json`:

```json
{
  "target_repository": "...",
  "workspace": "...",
  "branch": "...",
  "files_changed": [
    {
      "path": "...",
      "slice_id": "slice_01",
      "change": "...",
      "reason": "..."
    }
  ],
  "files_created": [],
  "files_removed": [],
  "temporary_files_remaining": [],
  "known_pre_existing_failures": [],
  "human_actions_still_required": []
}
```

Write `implementation_summary.md`:

```markdown
# Implementation Summary
## Workspace and Branch
## Implemented Vertical Slices
## Repository Files Changed
## RED → GREEN Evidence
## Relevant Checks
## Documentation Updates
## Known Pre-Existing Failures
## Limitations and Human Actions
```
