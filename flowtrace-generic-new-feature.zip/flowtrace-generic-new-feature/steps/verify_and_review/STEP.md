---
name: verify_and_review
description: Inspect actual diff and prove feature acceptance criteria with fresh evidence.
reads:
  - frame_feature/feature_brief.md
  - design_feature/feature_design.md
  - plan_vertical_slices/vertical_slices.json
  - implement_slices/slice_results.json
  - implement_slices/change_manifest.json
  - implement_slices/implementation_summary.md
writes:
  - verification.json
  - review_report.md
---

# Verify and Review

## Purpose

Review the actual target-repository diff and produce fresh evidence that the implemented
feature satisfies acceptance criteria without obvious regressions.

## Method Alignment

- Superpowers `requesting-code-review`: review plan compliance and code quality before delivery.
- Superpowers `verification-before-completion`: run fresh proof before claiming success.
- Matt Pocock `tdd`: verify behavior through public interfaces rather than internal shape.

## Read

- Upstream run artifacts listed above.
- The target repository diff, commit history, tests, docs, and project checks.
- Any project-specific review skill or checklist referenced by repository instructions.

## Review Lenses

### 1. Feature and Scope Compliance

- Does each must-have behavior exist?
- Is out-of-scope work absent?
- Are compatibility, rollout, and rollback expectations respected?
- Are acceptance criteria mapped to fresh evidence?

### 2. Code and Architecture Quality

- Is the implementation minimal and understandable?
- Are public interfaces coherent?
- Is complexity hidden behind useful modules rather than leaked to callers?
- Are errors, retries, state transitions, security checks, observability, and cleanup correct?
- Did the implementation introduce avoidable coupling or future hazards?

### 3. Test Quality

- Do tests cover externally observable behavior through appropriate seams?
- Did each slice capture RED before GREEN?
- Would tests survive internal refactoring?
- Are critical paths and complex logic covered?

### 4. Domain-Specific Review

Run any project-specific review checklist for security, tenant isolation, data integrity,
performance, reliability, compliance, accessibility, or operations.

## Fresh Verification

Run the appropriate current commands, not stale output:

- focused feature tests;
- relevant suites;
- full suite when practical;
- build;
- lint, format, and typecheck;
- static analysis;
- config or infrastructure validation;
- end-to-end demo or smoke test;
- migration, rollout, and rollback checks when applicable.

Fix blocking review findings with a RED → GREEN loop, update the manifest, and rerun fresh checks.
If the fix changes the design materially, return to `design_feature` and re-run downstream nodes.

## Gate

Do not claim completion while:
- acceptance criteria lack evidence;
- blocking review findings remain;
- required fresh checks fail;
- temporary instrumentation remains unintentionally;
- human approval boundaries are unresolved.

## Produce

Write `verification.json`:

```json
{
  "acceptance_criteria": [
    {"criterion": "...", "evidence": "...", "passed": true}
  ],
  "commands": [
    {"command": "...", "exit_code": 0, "summary": "..."}
  ],
  "red_green_evidence_valid": true,
  "temporary_instrumentation_removed": true,
  "review": {
    "spec_compliance": "passed|blocked",
    "code_quality": "passed|blocked",
    "domain_specific_review": "passed|not_required|blocked",
    "blocking_findings": []
  },
  "limitations": [],
  "human_actions_still_required": []
}
```

Write `review_report.md`:

```markdown
# Feature Verification and Review
## Acceptance Criteria Evidence
## Fresh Commands and Results
## Feature and Scope Review
## Code and Architecture Review
## Test Quality Review
## Domain-Specific Review
## Blocking Findings Resolved
## Limitations
## Human Actions Still Required
```
