---
name: plan_vertical_slices
description: Convert approved design into executable tracer-bullet slices and workspace plan.
reads:
  - design_feature/feature_design.md
  - design_feature/design_decisions.json
writes:
  - vertical_slices.json
  - implementation_plan.md
  - workspace_plan.md
---

# Plan Vertical Slices

## Purpose

Break the approved design into thin, end-to-end implementation slices that are individually
demoable or verifiable. Avoid layer-by-layer horizontal implementation.

## Method Alignment

- Matt Pocock `to-issues`: tracer-bullet vertical slices, dependency ordering, HITL versus AFK.
- Superpowers `writing-plans`: bite-sized implementation tasks with file paths and verification.
- Superpowers `using-git-worktrees`: plan isolated worktree or native isolated workspace before coding.

## Read

- `../design_feature/feature_design.md`
- `../design_feature/design_decisions.json`
- Relevant source files, tests, build files, and project commands in the target repository.

## Planning Rules

1. Each slice must deliver a narrow but complete behavior through the required layers.
2. Prefer many thin vertical slices over a few thick horizontal slices.
3. Each slice must be independently verifiable and ideally demoable.
4. Label each slice:
   - `AFK`: agent can implement without user interaction;
   - `HITL`: requires a human decision, credential, review, or external action.
5. Define dependencies explicitly.
6. Sequence slices so an early tracer bullet proves the end-to-end path.
7. For each slice, list:
   - behavior and acceptance criteria;
   - likely files to inspect or edit;
   - test seam;
   - RED → GREEN verification command;
   - relevant suite or build checks;
   - human approval boundary;
   - commit checkpoint.
8. Plan an isolated workspace:
   - detect whether isolation already exists;
   - prefer native harness isolation;
   - otherwise use a git worktree;
   - run project setup and baseline checks before edits.
9. Keep implementation details precise enough for an agent to execute, but do not over-plan
   speculative later slices.

## Gate

Do not begin repository edits until:
- the design is approved or does not require approval;
- the first vertical slice is executable;
- an isolated workspace strategy and clean baseline checks are defined.

## Produce

Write `vertical_slices.json`:

```json
{
  "slices": [
    {
      "id": "slice_01",
      "title": "...",
      "type": "AFK|HITL",
      "blocked_by": [],
      "behavior": "...",
      "acceptance_criteria": ["..."],
      "test_seam": "...",
      "likely_files": ["..."],
      "verification_commands": ["..."],
      "commit_checkpoint": "..."
    }
  ]
}
```

Write `implementation_plan.md`:

```markdown
# Implementation Plan
## Approved Design Reference
## Slice Order
## Slice 01 — Tracer Bullet
### Behavior
### Likely Files
### RED
### GREEN
### Relevant Verification
### Commit Checkpoint
### Approval Boundary
## Remaining Slices
## Documentation Updates
## Delivery Checks
```

Write `workspace_plan.md`:

```markdown
# Workspace Plan
## Target Repository
## Base Branch
## Isolation Strategy
## Feature Branch
## Setup Commands
## Baseline Commands
## Human Approval Boundaries
```
