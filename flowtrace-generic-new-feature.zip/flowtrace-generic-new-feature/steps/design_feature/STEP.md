---
name: design_feature
description: Resolve design choices, interfaces, test seams, risks, and optional prototypes.
reads:
  - frame_feature/feature_brief.md
  - frame_feature/feature_context.json
writes:
  - feature_design.md
  - design_decisions.json
---

# Design Feature

## Purpose

Produce an approved, implementation-ready feature design. Challenge the idea against the
existing codebase and domain model before touching production code.

## Method Alignment

- Superpowers `brainstorming`: explore alternatives, present a design, and obtain approval.
- Matt Pocock `grill-with-docs`: sharpen terminology, cross-check code, update glossary
  terms inline, and create ADRs sparingly for hard-to-reverse trade-offs.
- Matt Pocock `prototype`: use throwaway code only when it answers a specific design question.
- Matt Pocock `to-prd`: define implementation and testing decisions without stale file-level detail.

## Read

- `../frame_feature/feature_brief.md`
- `../frame_feature/feature_context.json`
- Target-repository `CONTEXT.md`, `CONTEXT-MAP.md`, relevant ADRs, modules, and tests.

## Actions

1. Describe at least two plausible approaches for a non-trivial feature. State the trade-offs.
2. Select the simplest approach that satisfies must-have behaviors and non-functional requirements.
3. Define:
   - public interface changes;
   - data, event, schema, state, and configuration changes;
   - compatibility and migration behavior;
   - error handling;
   - observability;
   - security and operational considerations;
   - rollout and rollback.
4. Identify the highest practical behavior-level test seams. Prefer public APIs over private
   method tests and internal mocks.
5. Stress-test the design with concrete scenarios and edge cases.
6. When a question cannot be answered confidently on paper, create a clearly marked throwaway
   prototype or spike. Record the question, result, and disposal plan.
7. Update target-repository `CONTEXT.md` only for newly resolved canonical domain vocabulary.
8. Offer an ADR only when the decision is hard to reverse, surprising without context, and
   the result of a genuine trade-off.
9. Stop at any human-approval boundary and record what needs approval.

## Gate

Do not move to implementation planning until design decisions and test seams are explicit.
For consequential or ambiguous designs, obtain human approval before continuing.

## Produce

Write `feature_design.md`:

```markdown
# Feature Design
## Problem and Scope
## Existing System Context
## Considered Approaches
## Selected Approach
## Public Interface Changes
## Data, Event, Schema, or Configuration Changes
## Error Handling and Observability
## Compatibility, Rollout, and Rollback
## Security and Non-Functional Considerations
## Behavior-Level Test Seams
## Prototype or Spike Results
## Documentation and ADR Updates
## Human Approvals
## Risks and Open Questions
```

Write `design_decisions.json`:

```json
{
  "selected_approach": "...",
  "alternatives_considered": [
    {"approach": "...", "tradeoffs": ["..."], "selected": false}
  ],
  "public_interface_changes": ["..."],
  "test_seams": ["..."],
  "compatibility_strategy": "...",
  "rollout_strategy": "...",
  "rollback_strategy": "...",
  "context_docs_updated": ["..."],
  "adrs_created_or_updated": ["..."],
  "prototype_results": ["..."],
  "human_approval_status": "approved|not_required|blocked",
  "open_questions": []
}
```
