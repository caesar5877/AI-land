# Generic New Feature Loop for Flowtrace

A compact six-node Flowtrace template for implementing software features with:

- Matt Pocock: `to-prd`, `grill-with-docs`, optional `prototype`, `to-issues`, `tdd`, and `handoff`
- Superpowers: `brainstorming`, `using-git-worktrees`, `writing-plans`,
  `subagent-driven-development` or `executing-plans`, `test-driven-development`,
  `requesting-code-review`, `verification-before-completion`, and
  `finishing-a-development-branch`

The coding agent formally edits target-repository files during `implement_slices`.

## Architecture

```mermaid
flowchart TD
    A[frame_feature] --> B[design_feature]
    B --> C[plan_vertical_slices]
    C --> D[implement_slices]
    D --> E[verify_and_review]
    E --> F[deliver_and_handoff]
```

Read `docs/ARCHITECTURE.md` for the detailed design.

## Quick Start

```bash
unzip flowtrace-generic-new-feature.zip
cd flowtrace-generic-new-feature
bash scripts/bootstrap.sh
$EDITOR resources/request.md
bash scripts/new-run.sh "feature name"
flowtrace serve --open
```

Then give your coding agent the content of `RUN_AGENT_PROMPT.md`.

## Included Files

```text
flowtrace-generic-new-feature/
├── trace.json
├── README.md
├── RUN_AGENT_PROMPT.md
├── FILE_INVENTORY.json
├── memory.md
├── docs/
│   ├── ARCHITECTURE.md
│   ├── METHOD_MAP.md
│   └── USAGE.md
├── resources/
│   ├── request.md
│   └── request.example.md
├── scripts/
│   ├── bootstrap.sh
│   ├── check_template.py
│   └── new-run.sh
└── steps/
    ├── frame_feature/STEP.md
    ├── design_feature/STEP.md
    ├── plan_vertical_slices/STEP.md
    ├── implement_slices/STEP.md
    ├── verify_and_review/STEP.md
    └── deliver_and_handoff/STEP.md
```

## Source References

- Flowtrace:
  - https://github.com/AIScientists-Dev/Flowtrace
  - https://github.com/AIScientists-Dev/Flowtrace/blob/main/docs/trace/SCHEMA.md
  - https://github.com/AIScientists-Dev/Flowtrace/blob/main/docs/trace/CLI.md
  - https://github.com/AIScientists-Dev/Flowtrace/blob/main/skills/make-trace/SKILL.md
- Matt Pocock:
  - https://github.com/mattpocock/skills
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/to-prd/SKILL.md
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/to-issues/SKILL.md
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/tdd/SKILL.md
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/grill-with-docs/SKILL.md
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/prototype/SKILL.md
  - https://github.com/mattpocock/skills/blob/main/skills/productivity/handoff/SKILL.md
- Superpowers:
  - https://github.com/obra/superpowers
  - https://github.com/obra/superpowers/tree/main/skills
