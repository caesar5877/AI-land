# Generic Bugfix Trace Memory

This optional trace-level memory is deliberately sparse. Add only reusable lessons that
should influence future runs of this trace. Keep repository-specific details in the target
repository's own documentation unless they genuinely apply across projects.

## Portable Lessons

- None yet.

## Trace Improvements

- None yet.
