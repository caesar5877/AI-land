# Generic Bugfix Loop for Flowtrace

A compact six-node Flowtrace template for day-to-day software bugfix work. It combines:

- Matt Pocock's `diagnose` loop:
  `reproduce → minimise → hypothesise → instrument → fix → regression-test`
- Superpowers:
  root-cause investigation before fixes, RED → GREEN → REFACTOR, and fresh verification
  before claiming completion.

The agent **does edit target repository files** during `implement_fix`.

## Architecture

```mermaid
flowchart TD
    A[frame_issue] --> B[build_feedback_loop]
    B --> C[investigate_root_cause]
    C --> D[implement_fix]
    D --> E[verify_and_review]
    E --> F[learn_and_handoff]
```

Read `docs/ARCHITECTURE.md` for the detailed design.

## Quick Start

```bash
unzip flowtrace-generic-bugfix.zip
cd flowtrace-generic-bugfix
bash scripts/bootstrap.sh
$EDITOR resources/request.md
bash scripts/new-run.sh "bugfix name"
flowtrace serve --open
```

Then give your coding agent the content of `RUN_AGENT_PROMPT.md`.

## Included Files

```text
flowtrace-generic-bugfix/
├── trace.json
├── README.md
├── RUN_AGENT_PROMPT.md
├── MIGRATION.md
├── memory.md
├── docs/
│   ├── ARCHITECTURE.md
│   └── USAGE.md
├── resources/
│   ├── request.md
│   └── request.example.md
├── scripts/
│   ├── bootstrap.sh
│   ├── check_template.py
│   └── new-run.sh
└── steps/
    ├── frame_issue/STEP.md
    ├── build_feedback_loop/STEP.md
    ├── investigate_root_cause/STEP.md
    ├── implement_fix/STEP.md
    ├── verify_and_review/STEP.md
    └── learn_and_handoff/STEP.md
```

## Source References

- Flowtrace repository and schema:
  - https://github.com/AIScientists-Dev/Flowtrace
  - https://github.com/AIScientists-Dev/Flowtrace/blob/main/docs/trace/SCHEMA.md
  - https://github.com/AIScientists-Dev/Flowtrace/blob/main/docs/trace/CLI.md
- Matt Pocock diagnose skill:
  - https://github.com/mattpocock/skills/blob/main/skills/engineering/diagnose/SKILL.md
- Superpowers:
  - https://github.com/obra/superpowers/blob/main/skills/systematic-debugging/SKILL.md
  - https://github.com/obra/superpowers/blob/main/skills/test-driven-development/SKILL.md
  - https://github.com/obra/superpowers/blob/main/skills/verification-before-completion/SKILL.md
