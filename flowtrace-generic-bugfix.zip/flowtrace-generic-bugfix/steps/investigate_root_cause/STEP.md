# Investigate Root Cause

## Purpose

Explain where behavior first diverges and why. Confirm the source-level cause before formal
implementation begins.

## Method Alignment

- Matt Pocock `diagnose`: hypothesise, instrument, and use ranked competing explanations.
- Superpowers `systematic-debugging`: investigate root cause, compare patterns, test one
  hypothesis at a time, and trace bad values backward to their source.

## Read

- `../frame_issue/issue.json`
- `../build_feedback_loop/feedback_loop.md`
- `../build_feedback_loop/baseline.json`
- Relevant files in the target repository.

## Investigation Loop

This is an iterative loop inside a single Flowtrace node. Do not create a DAG node for
every hypothesis or probe.

### 1. Inspect

- Read complete errors and warnings.
- Check recent code, dependency, configuration, deployment, and environment changes.
- Inspect component boundaries in order: input, output, propagated configuration, and state.
- Trace a bad value backward until its original source is identified.

### 2. Compare

Find a working reference when one exists: another code path, environment, version,
configuration, or historical implementation. List meaningful differences.

### 3. Maintain a Ranked Hypothesis Backlog

Keep three to five falsifiable hypotheses for a non-obvious issue. Each hypothesis needs:

- evidence supporting it;
- a prediction;
- a falsification condition;
- a minimal experiment.

Keep multiple candidates visible, but activate and test only one at a time.

### 4. Probe One Variable

Prefer debugger or REPL inspection when practical. Otherwise add narrowly targeted logs,
metrics, traces, controlled test changes, or configuration checks. Tag temporary diagnostics
with a unique marker such as `[DEBUG-a4f2]`.

Run the feedback loop and record the result. If falsified, move to the next hypothesis.
Do not stack speculative fixes.

### 5. Confirm the Source-Level Cause

The cause must explain the original symptom and the collected evidence. A retry, null check,
timeout increase, or guard at the crash site is not automatically a root cause.

## Allowed File Changes During Investigation

You may add temporary instrumentation, scratch scripts, or probes. Record every temporary
change. Do not apply the formal fix in this step.

## Stop Conditions

- If root cause is not confirmed, mark the step `blocked`.
- If three or more attempted fixes already failed, pause and record an architecture question
  instead of adding another patch.
- For performance regressions, prefer profiling, measurements, query plans, and bisection.

## Produce

Write `investigation.md`:

```markdown
# Investigation
## Evidence
## Boundary Trace
## Working Comparison
## Ranked Hypotheses
## Probe Log
## Backward Trace
## Root-Cause Reasoning
```

Write `root_cause.json`:

```json
{
  "root_cause": "...",
  "source_location": "...",
  "evidence": ["..."],
  "original_symptom_explained": true,
  "confirming_probe": "...",
  "symptom_level_patches_to_avoid": ["..."],
  "temporary_changes": ["..."],
  "temporary_diagnostic_markers": ["DEBUG-a4f2"],
  "architecture_follow_up": null,
  "root_cause_confirmed": true
}
```
