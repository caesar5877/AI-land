# Implement Fix

## Purpose

Modify the target repository files required to address the confirmed root cause. Keep the
patch minimal, test-backed, and easy to review. This is the step where the agent formally
edits source code, configuration, scripts, documentation, or infrastructure files.

## Method Alignment

- Matt Pocock `diagnose`: fix the confirmed cause and add a regression test.
- Superpowers `test-driven-development`: RED → GREEN → REFACTOR.
- Superpowers `systematic-debugging`: implement at the source, not only at the symptom.

## Read

- `../investigate_root_cause/investigation.md`
- `../investigate_root_cause/root_cause.json`
- The target repository.
- The feedback-loop command from `../build_feedback_loop/feedback_loop.md`.

## Entry Gate

Do not edit production code, configuration, scripts, or infrastructure unless:

- `root_cause_confirmed` is `true`;
- `original_symptom_explained` is `true`;
- the selected fix addresses the source rather than only the visible symptom;
- the requested edits are within the allowed-change boundary from `issue.json`.

## Actions

1. State the smallest correct fix before editing.
2. List the target repository files expected to change.
3. Add or update a regression test when a meaningful automated seam exists.
4. Run the focused test and capture **RED** before the fix. Confirm it fails for the
   expected bug rather than a typo, broken environment, or unrelated failure.
5. Modify the required target repository files.
6. Run the focused test and capture **GREEN**.
7. Run the relevant test suite or validation command.
8. Re-run the original feedback loop once after the fix.
9. Record each changed file and why it changed.
10. Avoid unrelated refactoring, speculative hardening, and “while I am here” changes.

## Configuration or Infrastructure Fixes

When a unit test is not the correct seam, use a repeatable validation loop such as:

- configuration validation;
- Terraform plan;
- deployment dry run;
- replayed request or event;
- integration test;
- environment-level smoke test.

Stop for human approval before any action listed as an approval boundary in `issue.json`.

## No Correct Test Seam

When no meaningful automated seam exists:

- document the limitation;
- use the most reliable repeatable harness available;
- create a separate testability or architecture follow-up;
- do not add a misleading shallow test simply to satisfy a checklist.

## Produce

Write `fix_summary.md`:

```markdown
# Fix Summary
## Confirmed Root Cause
## Selected Fix
## Why This Fix Addresses the Root Cause
## Files Changed
## Regression Test or Validation Harness
## Original Feedback Loop Result
## Deferred Follow-up
```

Write `change_manifest.json`:

```json
{
  "target_repository": "...",
  "change_type": "code|config|test|script|documentation|infrastructure|mixed",
  "files_changed": [
    {
      "path": "...",
      "change": "...",
      "reason": "..."
    }
  ],
  "temporary_files_removed": [],
  "commands_run": ["..."],
  "original_feedback_loop_passed": true,
  "limitations": []
}
```

Write `tdd_evidence.json`:

```json
{
  "test_or_harness_name": "...",
  "focused_command": "...",
  "red": {
    "observed": true,
    "exit_code": 1,
    "summary": "..."
  },
  "green": {
    "observed": true,
    "exit_code": 0,
    "summary": "..."
  },
  "relevant_suite_command": "...",
  "relevant_suite_exit_code": 0,
  "original_feedback_loop_after_fix": {
    "command": "...",
    "symptom_reproduced": false
  },
  "correct_test_seam": true
}
```
