# Build Feedback Loop

## Purpose

Create the fastest credible, repeatable pass-fail signal for the actual symptom. This loop
becomes the engine for investigation, implementation, and final verification.

## Method Alignment

- Matt Pocock `diagnose`: reproduce, minimise, and sharpen the feedback loop.
- Superpowers `systematic-debugging`: reproduce consistently before attempting fixes.

## Read

- `../frame_issue/issue.json`
- The target repository described in `issue.json`.

## Choose the Lightest Credible Loop

Prefer, in roughly this order:

1. Existing failing unit, integration, or end-to-end test.
2. `curl`, HTTP script, CLI invocation, or small replay script.
3. Captured request, event, message, payload, or trace replay.
4. Throwaway harness around the narrow failing code path.
5. Stress, concurrency, property, or fuzz loop for intermittent failures.
6. Differential check: old versus new version, configuration, environment, or dataset.
7. `git bisect run` harness when the regression window is known.
8. Structured human-in-the-loop script only as a last resort.

## Actions

1. Confirm that the loop triggers the same symptom recorded in `issue.json`.
2. Minimize setup while preserving the real failure pattern.
3. Make the assertion specific. “Did not crash” is weaker than asserting the wrong value,
   duplicate event, incorrect status, or missing side effect.
4. Improve determinism. For flaky failures, use repetition, controlled timing, concurrency,
   seeded randomness, or a narrower dataset.
5. Record the exact run command and baseline observations.
6. Temporary scripts may be created in the target repository or the run folder. Clearly
   label them and record whether they should be removed later.

## Blocked Path

When no credible loop can be built, mark this step `blocked`, explain what is missing, and
stop. Do not proceed by guessing.

## Produce

Write `feedback_loop.md`:

```markdown
# Feedback Loop
## Symptom Being Asserted
## Setup
## Run Command
## Expected Failure Signal
## Cleanup
## Limitations
```

Write `baseline.json`:

```json
{
  "loop_type": "test|curl|cli|replay|harness|stress|differential|bisect|hitl",
  "command": "...",
  "asserted_symptom": "...",
  "runs": 10,
  "failures": 10,
  "reproduction_rate": 1.0,
  "credible": true,
  "temporary_files": [],
  "limitations": []
}
```
