# Learn and Handoff

## Purpose

Capture useful learning without forcing every bug into a new skill or a large post-mortem.

## Method Alignment

- Matt Pocock `diagnose`: cleanup and post-mortem after verification.
- Optional Matt Pocock `improve-codebase-architecture`: separate deeper design follow-up.
- Optional reusable-skill writeback: only for broadly portable patterns.

## Read

- `../investigate_root_cause/investigation.md`
- `../investigate_root_cause/root_cause.json`
- `../implement_fix/fix_summary.md`
- `../implement_fix/change_manifest.json`
- `../verify_and_review/verification.json`
- `../verify_and_review/final_report.md`

## Actions

Record:

1. **Fingerprint:** the smallest signal that should make the next engineer recognize this issue.
2. **Root cause:** the source-level explanation.
3. **Dead ends:** plausible paths ruled out and why.
4. **Fix and proof:** changed files and fresh verification commands.
5. **Repository-specific memory candidate:** a detail worth adding to the target repository's
   docs, ADRs, runbook, or local agent instructions.
6. **Portable skill candidate:** only when the method generalizes beyond this repository and
   is not obvious.
7. **Architecture follow-up:** when coupling, hidden state, poor test seams, or repeated failed
   fixes indicate a deeper issue.
8. **Handoff state:** anything the next engineer must know.

Do not automatically edit trace-level `memory.md` unless the learning is genuinely portable
and has been reviewed.

## Produce

Write `learning.md`:

```markdown
# Troubleshooting Learning Note
## Fingerprint
## Root Cause
## Dead Ends to Skip
## Fix and Verification
## Repository-Specific Memory Candidate
## Reusable Skill Candidate
## Architecture Follow-up
## Handoff State
```

Use `None` for sections that do not apply.
