# Verify and Review

## Purpose

Review the actual target-repository diff and produce fresh evidence that the original bug is
fixed without obvious regressions. Do not trust a prior claim merely because files changed.

## Method Alignment

- Superpowers `verification-before-completion`: run fresh proof before claiming success.
- Matt Pocock `diagnose`: clean temporary instrumentation and verify the regression test.

## Read

- `../frame_issue/issue.json`
- `../build_feedback_loop/feedback_loop.md`
- `../investigate_root_cause/root_cause.json`
- `../implement_fix/fix_summary.md`
- `../implement_fix/change_manifest.json`
- `../implement_fix/tdd_evidence.json`
- The actual target-repository diff.

## Actions

1. Re-read the completion criteria.
2. Inspect the diff for:
   - root-cause alignment;
   - unnecessary scope;
   - correctness under the original failure conditions;
   - test or validation quality;
   - naming, coupling, maintainability, and rollback risk.
3. Run the original feedback loop fresh.
4. Run the regression test or validation harness fresh.
5. Run appropriate project checks fresh: relevant suite, full suite when practical, build,
   lint, typecheck, static analysis, configuration validation, or environment-level E2E.
6. Verify RED → GREEN evidence. If proof is missing or stale, safely revert the fix in the
   local target repository, prove the regression fails, restore the fix, and rerun it.
7. Remove temporary logs, traces, flags, scripts, and probes, or clearly mark intentional
   retained diagnostics.
8. Report any checks that could not run.

## Gate

Do not claim “fixed,” “done,” or “passing” until fresh command output supports the claim.

## Produce

Write `verification.json`:

```json
{
  "criteria": [
    {
      "criterion": "...",
      "evidence": "...",
      "passed": true
    }
  ],
  "commands": [
    {
      "command": "...",
      "exit_code": 0,
      "summary": "..."
    }
  ],
  "original_symptom_reproduced": false,
  "red_green_proof_valid": true,
  "temporary_instrumentation_removed": true,
  "diff_review": {
    "scope_is_minimal": true,
    "blocking_findings": []
  },
  "limitations": []
}
```

Write `final_report.md`:

```markdown
# Bugfix Report
## Symptom and Impact
## Confirmed Root Cause
## Repository Files Changed
## Minimal Fix
## Fresh Verification Evidence
## Limitations and Follow-up
```
