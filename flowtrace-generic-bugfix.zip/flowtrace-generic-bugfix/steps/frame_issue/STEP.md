# Frame Issue

## Purpose

Turn `resources/request.md` into a precise investigation contract. Record facts before
forming theories. Do not modify application source code, configuration, deployment files,
or infrastructure in this step.

## Method Alignment

- Matt Pocock `diagnose`: understand the reported failure before building the loop.
- Superpowers `systematic-debugging`: do not propose fixes before root-cause investigation.

## Read

- `resources/request.md`
- Existing evidence referenced by the request, when accessible.

## Actions

1. Separate observed behavior from assumptions and suspected causes.
2. Record expected behavior, impact, affected environment, available evidence, recent
   changes, constraints, target repository path, and completion criteria.
3. Preserve the full error message and stack trace when available.
4. Note missing information explicitly. Do not invent it.
5. Record whether a temporary mitigation is required, but keep mitigation separate from
   the root-cause fix.

## Gate

Do not recommend or apply a fix yet.

## Produce

Write `issue.json` in this step's run folder.

```json
{
  "title": "...",
  "target_repository": {
    "path": "...",
    "working_branch": "...",
    "allowed_changes": ["..."],
    "forbidden_changes": ["..."],
    "human_approval_boundaries": ["..."]
  },
  "observed_symptom": "...",
  "expected_behavior": "...",
  "impact": "...",
  "environment": ["..."],
  "known_reproduction_signal": "...",
  "evidence": ["..."],
  "recent_changes": ["..."],
  "constraints": ["..."],
  "completion_criteria": ["..."],
  "missing_information": ["..."],
  "mitigation_needed": false,
  "fix_proposed": false
}
```

## Completion Check

Mark this step `done` only when another engineer could read `issue.json` and understand
the exact problem without relying on the original chat.
