# Coding Agent Prompt: Drive the Generic Bugfix Trace

You are driving the Flowtrace repository in the current folder and modifying the target
application repository specified in `resources/request.md`.

## Operating Rules

1. Read `trace.json`, `docs/ARCHITECTURE.md`, and `resources/request.md`.
2. Run `flowtrace validate`, then inspect the graph with `flowtrace show --fmt ascii`.
3. Use the latest run or create one with `flowtrace run new --name "<bugfix name>"`.
4. Execute nodes in topological order.
5. Before starting a node:
   - run `flowtrace step <step_id> running --message "<what you are doing>"`;
   - read `steps/<step_id>/STEP.md`;
   - read the upstream run artifacts referenced there.
6. Write each declared artifact into `runs/<run_id>/<step_id>/`.
7. Mark the node done with one `--asset` flag per artifact, for example:

```bash
flowtrace step frame_issue done   --message "Framed the reported symptom and constraints"   --asset issue.json
```

8. When blocked, stop guessing and run:

```bash
flowtrace step <step_id> blocked --message "<specific missing evidence or access>"
```

9. Treat `resources/request.md` as the authority for the target repository path and change
   boundaries. Do not perform forbidden edits or cross a human-approval boundary.
10. Do not formally edit target-repository source code, configuration, scripts, or
    infrastructure before `investigate_root_cause/root_cause.json` confirms the source cause.
    Temporary harnesses and instrumentation are allowed earlier only when recorded.
11. During `implement_fix`, modify the target repository files directly, capture RED → GREEN
    evidence when a meaningful test seam exists, and write `change_manifest.json`.
12. During `verify_and_review`, inspect the actual target-repository diff and run fresh proof.
    Do not claim completion based on stale output or another agent's statement.
13. Close the deliverable after all nodes are done:

```bash
flowtrace deliverable done   --message "Root-caused, file-modified, and freshly verified bugfix"   --asset investigate_root_cause/root_cause.json   --asset implement_fix/fix_summary.md   --asset implement_fix/change_manifest.json   --asset verify_and_review/verification.json   --asset verify_and_review/final_report.md   --asset learn_and_handoff/learning.md
```

14. Finish by summarizing:
    - confirmed root cause;
    - target repository files changed;
    - fresh verification commands and outcomes;
    - limitations;
    - any human approval or follow-up still required.

## Debugging Discipline

Use the compact loop:

```text
Frame → Loop → Investigate → Fix Files → Verify → Learn
```

Maintain several falsifiable candidate hypotheses when the issue is unclear, but test one
variable at a time. Fix the source rather than masking the symptom.
