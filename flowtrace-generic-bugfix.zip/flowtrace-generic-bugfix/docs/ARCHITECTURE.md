# Generic Bugfix Flowtrace Architecture

## Goal

This trace is a compact, generic troubleshooting workflow aligned with Matt Pocock's
`diagnose` loop and Superpowers' evidence-first debugging discipline. It is intended for
routine software-engineering bugfix work without expanding every internal thought into its
own DAG node.

## System Boundary

There are two repositories or folders involved:

```text
Flowtrace trace repository                    Target application repository
~/traces/generic-bugfix/                      /path/to/your/application/
├── trace.json                                ├── src/
├── resources/request.md  ───── points to ──> ├── tests/
├── steps/                                    ├── config/
└── runs/<run_id>/                            └── ...
```

The Flowtrace repository stores the reusable method, run state, and investigation artifacts.
The coding agent modifies the target application repository during `implement_fix`. The
resulting application-repository edits are recorded in
`runs/<run_id>/implement_fix/change_manifest.json`.

This separation allows one reusable troubleshooting trace to work across many projects.

## Six-Node DAG

```mermaid
flowchart TD
    A[frame_issue<br/>Define the exact problem]
    B[build_feedback_loop<br/>Create a repeatable pass-fail signal]
    C[investigate_root_cause<br/>Run ranked, falsifiable experiments]
    D[implement_fix<br/>Edit target repository files]
    E[verify_and_review<br/>Review diff and rerun fresh proof]
    F[learn_and_handoff<br/>Capture durable learning]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
```

## Why Only Six Nodes?

The original worked example decomposes troubleshooting into many educational nodes. This
template keeps only actions with a durable, separately reviewable output. Internal loops stay
inside `STEP.md`:

```text
Investigate root cause
  ├── inspect evidence
  ├── compare working patterns
  ├── rank 3–5 falsifiable hypotheses
  ├── activate one hypothesis
  ├── probe one variable
  └── repeat until confirmed
```

## Gates

```text
No credible feedback loop
    → mark build_feedback_loop blocked
    → stop guessing

No confirmed root cause
    → mark investigate_root_cause blocked
    → do not apply formal repository fix

Confirmed root cause
    → implement_fix may edit target repository files

No fresh verification evidence
    → verify_and_review cannot claim completion
```

## File-Based Data Flow

```text
resources/request.md
  ↓
frame_issue/issue.json
  ↓
build_feedback_loop/feedback_loop.md
build_feedback_loop/baseline.json
  ↓
investigate_root_cause/investigation.md
investigate_root_cause/root_cause.json
  ↓
implement_fix/fix_summary.md
implement_fix/change_manifest.json
implement_fix/tdd_evidence.json
  ↓
verify_and_review/verification.json
verify_and_review/final_report.md
  ↓
learn_and_handoff/learning.md
```

At runtime, these files live beneath `runs/<run_id>/<step_id>/`.

## Modification Policy

| Stage | Formal edits to target repository | Allowed changes |
|---|---:|---|
| `frame_issue` | No | Read-only analysis |
| `build_feedback_loop` | Limited | Temporary harness or replay script |
| `investigate_root_cause` | Limited | Temporary instrumentation and probes |
| `implement_fix` | Yes | Minimal source-level code, config, script, infra, docs, and test edits |
| `verify_and_review` | Cleanup only | Remove temporary diagnostics; correct blocking review findings |
| `learn_and_handoff` | Optional docs only | Reviewed docs, ADR, runbook, or memory follow-up |

## Final Deliverable

The final Flowtrace deliverable contains:

- confirmed root cause;
- repository change manifest;
- fix summary;
- fresh verification evidence;
- concise final report;
- learning and handoff note.
