# Usage Guide

## 1. Install Flowtrace CLI

Install Flowtrace from its upstream repository first. The upstream README currently documents:

```bash
git clone https://github.com/AIScientists-Dev/flowtrace.git
cd flowtrace
./scripts/install.sh
```

Ensure `flowtrace` is available on your `PATH`.

## 2. Unzip This Trace

```bash
unzip flowtrace-generic-bugfix.zip
cd flowtrace-generic-bugfix
```

## 3. Bootstrap the Trace Repository

```bash
bash scripts/bootstrap.sh
```

The script initializes git when needed and runs:

```bash
flowtrace validate
flowtrace lint
flowtrace show --fmt mermaid
```

## 4. Describe the Bug

Edit:

```text
resources/request.md
```

Specify the target application-repository path and the permitted modification boundary.

## 5. Create a Run

```bash
bash scripts/new-run.sh "short bugfix name"
```

## 6. Let a Coding Agent Drive the Trace

Give your coding agent the content of:

```text
RUN_AGENT_PROMPT.md
```

The agent should run one node at a time, write the declared assets into
`runs/<run_id>/<step_id>/`, and update status with `flowtrace step`.

## 7. Open the UI

```bash
flowtrace serve --open
```

## Important Notes

- This package defines the reusable Flowtrace method. It does not embed an autonomous
  background executor.
- Formal target-repository modification begins in `implement_fix`.
- Temporary probes may be added earlier but must be recorded and removed or explicitly kept.
- Human approval boundaries in `resources/request.md` always take precedence.
