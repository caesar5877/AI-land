# Bugfix Request — Example

## Target Repository

- **Repository path:** `/work/events-gateway`
- **Working branch:** `bugfix/kafka-write-role`
- **Allowed file changes:** Application config, Terraform, tests, operational docs.
- **Forbidden changes:** Production deployment and live topic deletion.
- **Required review boundary:** Stop before applying infrastructure changes outside QA.

## Problem Definition

- **Title:** QA event publication fails after Kafka SaaS onboarding.
- **Observed symptom:** The API accepts a request but the producer logs an authorization error and no event appears in the inbox topic.
- **Expected behavior:** The accepted request publishes exactly one event and the QA consumer receives it.
- **Impact and urgency:** QA end-to-end testing is blocked.
- **Environment and version:** QA deployment from the current branch.
- **Known reproduction signal:** Replay the captured request with the documented curl command.
- **Available evidence:** Producer error log, trace ID, topic name, QA deployment configuration.
- **Completion criteria:** Replay succeeds, topic receives one event, consumer processes it, and the QA smoke test passes.

## Investigation Context

- **Recent changes:** Kafka SaaS resources were recently onboarded.
- **Suspected modules or components:** Producer configuration, topic ACL, deployment property mapping.
- **Known-good comparison:** Another QA producer already writes successfully to a different topic.
- **Repository commands:** Terraform validate, focused integration test, QA replay script.
- **Access limitations:** Infrastructure apply requires human approval.
- **Previous attempts:** Confirmed network connectivity.
- **Operational safety notes:** Do not change production ACLs.
