# Bugfix Request

Fill this file before starting a run. Unknown fields may remain blank. Do not guess.
This trace is generic: it can be used for source-code bugs, test failures, build failures,
configuration issues, deployment problems, integration failures, and performance regressions.

## Target Repository

- **Repository path:** Absolute or clearly resolvable local path to the application repository.
- **Working branch:** Existing branch or branch to create.
- **Allowed file changes:** Source code, tests, configuration, scripts, docs, infrastructure files.
- **Forbidden changes:** Files or environments the agent must not modify.
- **Required review boundary:** Any change that must stop for human approval.

## Problem Definition

- **Title:**
- **Observed symptom:** What does the caller, user, test, log, metric, or monitoring system show?
- **Expected behavior:**
- **Impact and urgency:** Who or what is affected? Is there a workaround?
- **Environment and version:** Local, CI, QA, staging, production, commit, release, configuration, feature flag.
- **Known reproduction signal:** Exact steps, command, request, event, payload, timing window, occurrence rate, or failing test.
- **Available evidence:** Full errors, stack traces, logs, trace IDs, screenshots, metrics, captured artifacts.
- **Completion criteria:** What fresh evidence would prove the bug is fixed?

## Investigation Context

- **Recent changes:** Commits, deployments, configuration changes, dependency upgrades, infrastructure changes.
- **Suspected modules or components:**
- **Known-good comparison:** Similar code path, environment, version, configuration, or historical behavior that works.
- **Repository commands:** Build, focused test, full test, lint, typecheck, local run, replay, or validation commands.
- **Access limitations:** Missing credentials, unavailable environment, production-only behavior, human-in-the-loop steps.
- **Previous attempts:** What has already been tried, and what happened?
- **Operational safety notes:** Rollback, data integrity, privacy, security, or production constraints.
