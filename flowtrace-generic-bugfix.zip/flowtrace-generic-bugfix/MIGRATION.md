# Migration from the 17-Step Worked Example

| Existing node(s) | New node | Reason |
|---|---|---|
| `bug_report`, `triage_priority` | `frame_issue` | Intake and triage are one framing decision. |
| `reproduce` | `build_feedback_loop` | Reproduction is retained and strengthened with a fast feedback-loop contract. |
| `gather_evidence`, `pattern_analysis`, `hypothesize`, `test_hypothesis`, `root_cause` | `investigate_root_cause` | These are one iterative scientific investigation loop. |
| `fix_design`, `implement_tdd` | `implement_fix` | The agent now explicitly edits target repository files and captures RED → GREEN evidence. |
| `review_spec`, `review_quality`, `code_review`, `verify_completion` | `verify_and_review` | Fresh proof and diff review remain mandatory without four review ceremonies. |
| `finish_branch` | Outside the generic trace | Push, PR, merge, and branch cleanup depend on each team's integration policy. |
| `writing_skills`, `memory_writeback` | `learn_and_handoff` | Preserve learning, but create reusable skills only when genuinely portable. |

## Optional Future Splits

Keep the six-node version as the default. Split a node only when repeated use proves that a
new node creates a separately inspectable decision and a durable artifact consumed later.

Examples:

- Split `investigate_root_cause` into boundary tracing and confirmation for a large platform
  where independent teams review boundary evidence.
- Split `verify_and_review` into verification and formal review for regulated workflows.
- Add a separate delivery trace for PR creation, rollout, and rollback.
