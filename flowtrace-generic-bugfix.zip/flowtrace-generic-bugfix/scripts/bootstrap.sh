#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v flowtrace >/dev/null 2>&1; then
  echo "ERROR: flowtrace CLI was not found on PATH." >&2
  echo "Install it first, then rerun this script. See docs/USAGE.md." >&2
  exit 1
fi

python3 scripts/check_template.py

if ! git rev-parse --show-toplevel >/dev/null 2>&1; then
  git init
fi

if ! git rev-parse --verify HEAD >/dev/null 2>&1; then
  git add .
  if ! git commit -m "Initialize generic bugfix Flowtrace template"; then
    echo "ERROR: git could not create the initial commit." >&2
    echo "Configure user.name and user.email, then rerun:" >&2
    echo "  git add . && git commit -m 'Initialize generic bugfix Flowtrace template'" >&2
    exit 1
  fi
fi

flowtrace validate
flowtrace lint || true

echo
echo "Trace graph:"
flowtrace show --fmt mermaid

echo
echo "Bootstrap complete."
echo "Next:"
echo "  1. Edit resources/request.md"
echo "  2. Run: bash scripts/new-run.sh \"bugfix name\""
echo "  3. Give RUN_AGENT_PROMPT.md to your coding agent"
echo "  4. Run: flowtrace serve --open"
