#!/usr/bin/env python3
"""Lightweight offline structural check for the generic Flowtrace template."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TRACE = ROOT / "trace.json"
SLUG_RE = re.compile(r"^[a-z][a-z0-9_]{0,62}$")
ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,62}$")
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    if not TRACE.exists():
        fail("trace.json is missing")

    data = json.loads(TRACE.read_text(encoding="utf-8"))

    if not ID_RE.fullmatch(data.get("id", "")):
        fail("trace id must match [a-z][a-z0-9-]{0,62}")
    if not SEMVER_RE.fullmatch(data.get("version", "")):
        fail("version must be semver such as 0.1.0")

    steps = data.get("steps")
    if not isinstance(steps, dict) or not steps:
        fail("steps must be a non-empty object")

    step_dirs = {p.name for p in (ROOT / "steps").iterdir() if p.is_dir()}
    step_ids = set(steps)
    if step_dirs != step_ids:
        fail(f"step folders and trace.json entries differ: folders={sorted(step_dirs)}, json={sorted(step_ids)}")

    for slug, spec in steps.items():
        if not SLUG_RE.fullmatch(slug):
            fail(f"invalid step slug: {slug}")
        if not (ROOT / "steps" / slug / "STEP.md").exists():
            fail(f"missing steps/{slug}/STEP.md")
        if not isinstance(spec.get("from_steps"), list):
            fail(f"{slug}.from_steps must be a list")
        for upstream in spec["from_steps"]:
            if upstream not in steps:
                fail(f"{slug} references missing upstream step {upstream}")
        if not isinstance(spec.get("assets"), list):
            fail(f"{slug}.assets must be a list")

    # DAG cycle check
    temporary: set[str] = set()
    permanent: set[str] = set()

    def visit(node: str) -> None:
        if node in permanent:
            return
        if node in temporary:
            fail(f"cycle detected at step {node}")
        temporary.add(node)
        for parent in steps[node]["from_steps"]:
            visit(parent)
        temporary.remove(node)
        permanent.add(node)

    for step in steps:
        visit(step)

    produced = {
        f"{step_id}/{asset}"
        for step_id, spec in steps.items()
        for asset in spec.get("assets", [])
    }
    for asset in data.get("deliverable", {}).get("assets", []):
        if asset not in produced:
            fail(f"deliverable asset is not declared by a step: {asset}")

    print(f"OK: {len(steps)} steps, DAG valid, folders present, deliverable assets declared.")


if __name__ == "__main__":
    main()
