# Flood Fill Time / 洪水填充时间

## Problem Statement / 问题描述

**English:**
Given a 2D matrix representing terrain and a starting coordinate (row index, column index) where water begins to flood, simulate the flooding process and output a matrix of the same size showing the "time" when each spot gets wet.

Water spreads to adjacent cells (up, down, left, right) at each time step. The starting position gets wet at time 0, adjacent cells get wet at time 1, and so on.

**中文:**
给定一个表示地形的2D矩阵和水开始淹没的起始坐标（行索引，列索引），模拟淹没过程并输出相同大小的矩阵，显示每个位置被淹没的"时间"。

水在每个时间步长向相邻单元格（上、下、左、右）扩散。起始位置在时间0被淹没，相邻单元格在时间1被淹没，依此类推。

## Examples / 示例

### Example 1 / 示例1
```
Input: 
terrain = [[1, 1, 1],
           [1, 1, 1], 
           [1, 1, 1]]
start = (1, 1)  # center position

Output:
[[2, 1, 2],
 [1, 0, 1],
 [2, 1, 2]]

Explanation: Water starts at (1,1) at time 0, spreads to adjacent cells at time 1, then to corners at time 2.
```

### Example 2 / 示例2
```
Input:
terrain = [[1, 1, 1, 1],
           [1, 1, 1, 1]]
start = (0, 0)  # top-left corner

Output:
[[0, 1, 2, 3],
 [1, 2, 3, 4]]

Explanation: Water spreads from top-left corner, taking longer to reach far corners.
```

## Input Format / 输入格式
- `terrain`: 2D matrix representing the terrain (values don't affect flooding, all cells are floodable)
- `start`: Tuple (row, col) representing starting position of water

## Output Format / 输出格式
- 2D matrix of same size showing time when each position gets wet

## Constraints / 约束条件
- 1 <= rows, cols <= 100
- 0 <= start_row < rows
- 0 <= start_col < cols
- All cells are floodable (no obstacles)