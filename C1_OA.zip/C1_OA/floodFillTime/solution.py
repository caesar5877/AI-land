def flood_fill_time(terrain, start):
    """
    Calculate time when each cell gets flooded starting from given position.
    
    Args:
        terrain: 2D matrix representing terrain
        start: Tuple (row, col) of starting flood position
        
    Returns:
        2D matrix showing time when each position gets wet
    """
    # Get matrix dimensions for boundary checking
    rows, cols = len(terrain), len(terrain[0])
    # Initialize result matrix with -1 to mark unvisited cells
    result = [[-1] * cols for _ in range(rows)]
    
    # Import deque for efficient BFS queue operations
    from collections import deque
    # BFS queue stores tuples of (row, col, time)
    queue = deque([(start[0], start[1], 0)])
    # Mark starting position as flooded at time 0
    result[start[0]][start[1]] = 0
    
    # Define 4-directional movement: up, down, left, right
    # Each tuple represents (row_offset, col_offset)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # BFS algorithm to simulate water spreading level by level
    while queue:
        # Dequeue current cell and its flood time
        row, col, time = queue.popleft()
        
        # Explore all 4 adjacent cells
        for dr, dc in directions:
            # Calculate coordinates of adjacent cell
            new_row, new_col = row + dr, col + dc
            
            # Check if adjacent cell is valid and not yet flooded
            # Valid: within matrix bounds
            # Not flooded: result value is still -1
            if (0 <= new_row < rows and 0 <= new_col < cols and 
                result[new_row][new_col] == -1):
                # Mark cell as flooded at next time step
                result[new_row][new_col] = time + 1
                # Add newly flooded cell to queue for further expansion
                queue.append((new_row, new_col, time + 1))
    
    # Return matrix showing flood time for each position
    return result