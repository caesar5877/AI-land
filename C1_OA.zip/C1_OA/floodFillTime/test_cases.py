from solution import flood_fill_time

def test_flood_fill_time():
    test_cases = [
        # Basic functionality
        {
            'input': ([[1, 1, 1], [1, 1, 1], [1, 1, 1]], (1, 1)),
            'expected': [[2, 1, 2], [1, 0, 1], [2, 1, 2]],
            'desc': 'Center start position in 3x3 grid'
        },
        {
            'input': ([[1, 1, 1, 1], [1, 1, 1, 1]], (0, 0)),
            'expected': [[0, 1, 2, 3], [1, 2, 3, 4]],
            'desc': 'Top-left corner start in 2x4 grid'
        },
        {
            'input': ([[1, 1], [1, 1]], (0, 1)),
            'expected': [[1, 0], [2, 1]],
            'desc': 'Top-right corner start in 2x2 grid'
        },
        
        # Edge cases
        {
            'input': ([[1]], (0, 0)),
            'expected': [[0]],
            'desc': 'Single cell matrix'
        },
        {
            'input': ([[1, 1, 1]], (0, 1)),
            'expected': [[1, 0, 1]],
            'desc': 'Single row matrix, center start'
        },
        {
            'input': ([[1], [1], [1]], (1, 0)),
            'expected': [[1], [0], [1]],
            'desc': 'Single column matrix, center start'
        },
        
        # Complex scenarios
        {
            'input': ([[1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1]], (1, 2)),
            'expected': [[3, 2, 1, 2, 3], [2, 1, 0, 1, 2], [3, 2, 1, 2, 3]],
            'desc': 'Center start in 3x5 grid'
        },
        {
            'input': ([[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1]], (3, 2)),
            'expected': [[5, 4, 3], [4, 3, 2], [3, 2, 1], [2, 1, 0]],
            'desc': 'Bottom-right start in 4x3 grid'
        },
        {
            'input': ([[1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1]], (0, 0)),
            'expected': [[0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6]],
            'desc': 'Top-left start in 4x4 grid'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            terrain, start = test['input']
            result = flood_fill_time(terrain, start)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_flood_fill_time()