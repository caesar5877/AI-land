def calculate_score_range(initial_score, changes):
    """
    Calculate final score and return corresponding range string.
    
    Args:
        initial_score (int): Starting score
        changes (list): List of score modifications
        
    Returns:
        str: 'a' for ≤100, 'b' for 101-150, 'c' for 151-200, 'd' for >200
    """
    # Calculate final score by applying all changes to initial score
    # sum() efficiently adds all positive and negative changes
    final_score = initial_score + sum(changes)
    
    # Determine score range and return corresponding letter
    # Use cascading if-elif structure for clear range boundaries
    if final_score <= 100:
        return 'a'  # Range: negative infinity to 100
    elif final_score <= 150:
        return 'b'  # Range: 101 to 150
    elif final_score <= 200:
        return 'c'  # Range: 151 to 200
    else:
        return 'd'  # Range: 201 to positive infinity