from solution import process_operations

def test_binary_search_obstacles():
    """Comprehensive test cases for binary search obstacles problem"""
    
    test_cases = [
        # Basic operations
        {
            "operations": [
                [1, 5],      # Place obstacle at 5
                [2, 3, 4],   # Query center=3, size=4 (spans 1-5)
                [2, 10, 2]   # Query center=10, size=2 (spans 9-11)
            ],
            "expected": ["0", "1"],
            "desc": "Basic obstacle and queries"
        },
        
        # Multiple obstacles
        {
            "operations": [
                [1, 2],      # Place obstacle at 2
                [1, 8],      # Place obstacle at 8
                [2, 5, 6],   # Query center=5, size=6 (spans 2-8)
                [2, 5, 4],   # Query center=5, size=4 (spans 3-7)
                [2, 0, 2]    # Query center=0, size=2 (spans -1-1)
            ],
            "expected": ["0", "1", "1"],
            "desc": "Multiple obstacles with various queries"
        },
        
        # Edge cases
        {
            "operations": [
                [2, 0, 1],   # Query before any obstacles
                [1, 0],      # Place obstacle at 0
                [2, 0, 1],   # Query same position
                [2, 1, 3]    # Query overlapping
            ],
            "expected": ["1", "0", "0"],
            "desc": "Edge cases with zero position"
        },
        
        # Large structure
        {
            "operations": [
                [1, 10],
                [2, 5, 10],  # Query center=5, size=10 (spans 0-10)
                [2, 15, 8]   # Query center=15, size=8 (spans 11-19)
            ],
            "expected": ["0", "1"],
            "desc": "Large structure queries"
        },
        
        # No obstacles
        {
            "operations": [
                [2, 5, 10],
                [2, 0, 5],
                [2, -5, 3]
            ],
            "expected": ["1", "1", "1"],
            "desc": "No obstacles, all queries succeed"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = process_operations(test["operations"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Operations: {test['operations']}")
        print(f"  Result: {result}")
        print(f"  Expected: {expected} [{status}]")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_binary_search_obstacles()