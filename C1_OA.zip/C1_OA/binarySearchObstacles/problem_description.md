# Binary Search Obstacles Problem / 二分搜索障碍物问题

## Problem Statement / 问题描述

### English
Process operations on a number line with obstacles and structure placement queries.

### 中文
在数轴上处理障碍物和结构放置查询操作。

## Operations / 操作

### English
1. `[1, x]`: Place an obstacle at position x
2. `[2, x, size]`: Query if a structure can be built centered at x with length size

### 中文
1. `[1, x]`: 在位置x放置一个障碍物
2. `[2, x, size]`: 查询是否可以在以x为中心、长度为size的位置建造结构

## Structure Definition / 结构定义

### English
- A structure centered at x with length size spans from `x - size // 2` to `x + size // 2`
- The structure cannot overlap with any existing obstacles

### 中文
- 以x为中心、长度为size的结构跨越从`x - size // 2`到`x + size // 2`
- 结构不能与任何现有障碍物重叠

## Query Response / 查询响应

### English
- Return "1" if the structure can be built (no obstacles in range)
- Return "0" if the structure cannot be built (obstacles present)

### 中文
- 如果可以建造结构（范围内无障碍物），返回"1"
- 如果不能建造结构（存在障碍物），返回"0"

## Examples / 示例

### English
- Place obstacle at position 5: `[1, 5]`
- Query structure at center 3, size 4: `[2, 3, 4]`
  - Structure spans from 1 to 5 (3 - 4//2 to 3 + 4//2)
  - Since obstacle at 5 exists, return "0"

### 中文
- 在位置5放置障碍物：`[1, 5]`
- 查询中心为3、大小为4的结构：`[2, 3, 4]`
  - 结构跨越从1到5 (3 - 4//2 到 3 + 4//2)
  - 由于位置5存在障碍物，返回"0"

## Output / 输出

### English
For each query operation, output "1" or "0".

### 中文
对于每个查询操作，输出"1"或"0"。