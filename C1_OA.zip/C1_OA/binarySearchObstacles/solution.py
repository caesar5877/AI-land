def process_operations(operations):
    """
    Process obstacle placement and structure queries.
    
    Args:
        operations: List of operations [1,x] or [2,x,size]
        
    Returns:
        List of results for query operations
    """
    # Use set for O(1) obstacle lookup performance
    obstacles = set()
    # Store results for all query operations
    results = []
    
    # Process each operation sequentially
    for op in operations:
        if op[0] == 1:
            # Operation type 1: Place obstacle at position x
            # Add obstacle position to our tracking set
            obstacles.add(op[1])
        elif op[0] == 2:
            # Operation type 2: Query if structure can be built
            # Extract center position and structure size
            x, size = op[1], op[2]
            
            # Calculate structure boundaries
            # Structure spans from center-half_size to center+half_size
            start = x - size // 2
            end = x + size // 2
            
            # Check if any obstacle exists in the structure range
            # Assume structure can be built initially
            can_build = True
            
            # Iterate through each position in structure range
            for pos in range(start, end + 1):
                # If obstacle found at any position, structure cannot be built
                if pos in obstacles:
                    can_build = False
                    break  # Early exit for efficiency
            
            # Append result: "1" if can build, "0" if cannot
            results.append("1" if can_build else "0")
    
    # Return all query results in order
    return results