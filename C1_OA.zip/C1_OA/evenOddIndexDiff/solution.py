def even_odd_diff(nums):
    """
    Calculate difference between sum of even index elements and odd index elements.
    
    Args:
        nums: List of integers between -100 and +100
        
    Returns:
        int: even_sum - odd_sum
    """
    # Calculate sum of elements at even indices (0, 2, 4, ...)
    # Using range with step=2 starting from index 0
    even_sum = sum(nums[i] for i in range(0, len(nums), 2))
    
    # Calculate sum of elements at odd indices (1, 3, 5, ...)
    # Using range with step=2 starting from index 1
    odd_sum = sum(nums[i] for i in range(1, len(nums), 2))
    
    # Return the difference: even_sum - odd_sum
    return even_sum - odd_sum