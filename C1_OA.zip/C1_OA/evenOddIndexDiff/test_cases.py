from solution import even_odd_diff

def test_even_odd_diff():
    test_cases = [
        # Basic functionality
        {
            'input': [1, 2, 3, 4, 5],
            'expected': 3,
            'desc': 'Even sum: 1+3+5=9, Odd sum: 2+4=6, Diff: 3'
        },
        {
            'input': [10, -5, 8, -3],
            'expected': 26,
            'desc': 'Even sum: 10+8=18, Odd sum: -5+(-3)=-8, Diff: 26'
        },
        {
            'input': [2, 4, 6, 8],
            'expected': -4,
            'desc': 'Even sum: 2+6=8, Odd sum: 4+8=12, Diff: -4'
        },
        
        # Edge cases
        {
            'input': [5],
            'expected': 5,
            'desc': 'Single element at even index'
        },
        {
            'input': [1, 2],
            'expected': -1,
            'desc': 'Two elements: 1-2=-1'
        },
        {
            'input': [0, 0, 0, 0],
            'expected': 0,
            'desc': 'All zeros'
        },
        
        # Complex scenarios
        {
            'input': [-10, 20, -30, 40],
            'expected': -100,
            'desc': 'Negative numbers: (-10)+(-30)=-40, 20+40=60, Diff: -100'
        },
        {
            'input': [100, -100, 50, -50],
            'expected': 300,
            'desc': 'Max values: 100+50=150, (-100)+(-50)=-150, Diff: 300'
        },
        {
            'input': [1, -1, 1, -1, 1],
            'expected': 5,
            'desc': 'Alternating pattern: 1+1+1=3, (-1)+(-1)=-2, Diff: 5'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            result = even_odd_diff(test['input'])
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_even_odd_diff()