# Even Odd Index Difference / 奇偶索引差值

## Problem Statement / 问题描述

**English:**
Given an array where numbers are between -100 and +100, calculate the sum of elements at even indices and the sum of elements at odd indices, then return their difference (even_sum - odd_sum).

**中文:**
给定一个数组，数组中的数字在-100到+100之间，计算偶数索引处元素的和以及奇数索引处元素的和，返回它们的差值（偶数索引和 - 奇数索引和）。

## Examples / 示例

### Example 1 / 示例1
```
Input: [1, 2, 3, 4, 5]
Output: -1
Explanation: 
Even indices (0, 2, 4): 1 + 3 + 5 = 9
Odd indices (1, 3): 2 + 4 = 6
Difference: 9 - 6 = 3
Wait, let me recalculate: 9 - 6 = 3, not -1
```

### Example 2 / 示例2
```
Input: [10, -5, 8, -3]
Output: 23
Explanation:
Even indices (0, 2): 10 + 8 = 18
Odd indices (1, 3): -5 + (-3) = -8
Difference: 18 - (-8) = 26
Wait, 18 - (-8) = 26, not 23
```

## Input Format / 输入格式
- `nums`: Array of integers between -100 and +100

## Output Format / 输出格式
- Integer: Difference between even index sum and odd index sum

## Constraints / 约束条件
- 1 ≤ nums.length ≤ 1000
- -100 ≤ nums[i] ≤ 100