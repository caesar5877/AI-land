def longest_diagonal_pattern(matrix):
    """
    Find the longest diagonal segment matching pattern: 1,2,0,2,0,...
    
    Args:
        matrix: 2D list of integers (0, 1, or 2)
        
    Returns:
        int: Length of longest matching diagonal segment
    """
    # Handle empty matrix edge case
    if not matrix or not matrix[0]:
        return 0
    
    # Get matrix dimensions
    rows, cols = len(matrix), len(matrix[0])
    # Track maximum pattern length found
    max_length = 0
    
    def check_pattern(r, c, dr, dc):
        # Count consecutive elements matching the pattern
        length = 0
        
        # Continue while within matrix bounds
        while 0 <= r < rows and 0 <= c < cols:
            # Determine expected value based on position in pattern
            # Pattern: 1, 2, 0, 2, 0, 2, 0, ...
            # Position 0: expect 1
            # Position 1, 3, 5, ...: expect 2 (odd positions after 0)
            # Position 2, 4, 6, ...: expect 0 (even positions after 0)
            expected = 1 if length == 0 else (2 if length % 2 == 1 else 0)
            
            # Check if current element matches expected pattern value
            if matrix[r][c] == expected:
                # Pattern continues, increment length and move to next position
                length += 1
                r, c = r + dr, c + dc
            else:
                # Pattern broken, stop checking
                break
                
        # Return length of matching pattern segment
        return length
    
    # Check all possible starting positions in matrix
    for r in range(rows):
        for c in range(cols):
            # Check main diagonal direction (down-right ↘)
            max_length = max(max_length, check_pattern(r, c, 1, 1))
            # Check anti-diagonal direction (down-left ↙)
            max_length = max(max_length, check_pattern(r, c, 1, -1))
    
    # Return the longest pattern segment found
    return max_length