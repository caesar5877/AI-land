# Diagonal Pattern Matching Problem / 对角线模式匹配问题

## Problem Statement / 问题描述

### English
Given a matrix of integers containing only 0, 1, or 2, find the longest diagonal segment that matches a specific pattern.

### 中文
给定一个只包含0、1、2的整数矩阵，找到匹配特定模式的最长对角线段。

## Pattern Definition / 模式定义

### English
The pattern starts with 1, followed by alternating 2 and 0:
- Pattern: 1, 2, 0, 2, 0, 2, 0, ...
- First element must be 1
- Then alternates between 2 and 0 infinitely

### 中文
模式仡1开始，然后2和0交替出现：
- 模式：1, 2, 0, 2, 0, 2, 0, ...
- 第一个元素必须是1
- 然后2和0无限交替

## Diagonal Definition / 对角线定义

### English
A diagonal can be:
1. Main diagonal (top-left to bottom-right)
2. Anti-diagonal (top-right to bottom-left)
3. Any parallel diagonal to the above

### 中文
对角线可以是：
1. 主对角线（左上到右下）
2. 反对角线（右上到左下）
3. 与上述对角线平行的任意对角线

## Requirements / 要求

### English
- Search all possible diagonals in the matrix
- Find the longest contiguous segment matching the pattern
- Return the length of the longest matching segment

### 中文
- 搜索矩阵中所有可能的对角线
- 找到匹配模式的最长连续段
- 返回最长匹配段的长度

## Examples / 示例
```
Matrix:
[1, 2, 0]
[0, 1, 2] 
[2, 0, 0]

Main diagonal: [1, 1, 0] - no match
Anti-diagonal: [0, 1, 2] - no match  
Other diagonals need to be checked...
```

## Output / 输出

### English
Return the length of the longest diagonal segment matching the pattern.

### 中文
返回匹配模式的最长对角线段的长度。