from solution import longest_diagonal_pattern

def test_diagonal_pattern():
    """Comprehensive test cases for diagonal pattern matching"""
    
    test_cases = [
        # Basic cases
        {
            "matrix": [[1]],
            "expected": 1,
            "desc": "Single element - pattern start"
        },
        
        {
            "matrix": [[0]],
            "expected": 0,
            "desc": "Single element - no pattern"
        },
        
        # Simple patterns
        {
            "matrix": [
                [1, 0],
                [0, 2]
            ],
            "expected": 2,
            "desc": "Simple 2-length pattern on main diagonal"
        },
        
        {
            "matrix": [
                [1, 0, 0],
                [0, 2, 0],
                [0, 0, 0]
            ],
            "expected": 3,
            "desc": "3-length pattern on main diagonal"
        },
        
        # Anti-diagonal pattern
        {
            "matrix": [
                [0, 0, 1],
                [0, 2, 0],
                [0, 0, 0]
            ],
            "expected": 3,
            "desc": "3-length pattern on anti-diagonal"
        },
        
        # Longer pattern
        {
            "matrix": [
                [1, 0, 0, 0, 0],
                [0, 2, 0, 0, 0],
                [0, 0, 0, 0, 0],
                [0, 0, 0, 2, 0],
                [0, 0, 0, 0, 0]
            ],
            "expected": 5,
            "desc": "5-length pattern: 1,2,0,2,0"
        },
        
        # Multiple patterns
        {
            "matrix": [
                [1, 0, 1, 0],
                [0, 2, 2, 0],
                [0, 0, 0, 0],
                [0, 0, 0, 2]
            ],
            "expected": 4,
            "desc": "Multiple patterns, longest is 4"
        },
        
        # No valid pattern
        {
            "matrix": [
                [2, 1, 0],
                [0, 0, 1],
                [1, 0, 2]
            ],
            "expected": 1,
            "desc": "No valid pattern, only single 1s"
        },
        
        # Empty matrix
        {
            "matrix": [],
            "expected": 0,
            "desc": "Empty matrix"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = longest_diagonal_pattern(test["matrix"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        
        if status == "FAIL":
            print(f"  Matrix: {test['matrix']}")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_diagonal_pattern()