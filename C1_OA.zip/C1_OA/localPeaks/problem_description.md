# Local Peaks Sum / 局部峰值和

## Problem Statement / 问题描述

**English:**
Given a list of integers, find the sum of elements that are greater than their adjacent elements. For the first and last elements, only compare with their single adjacent element.

**中文:**
给定一个整数列表，找到大于其相邻元素的元素之和。对于第一个和最后一个元素，只与它们唯一的相邻元素比较。

## Examples / 示例

### Example 1 / 示例1
```
Input: [1, 3, 2, 4, 1]
Output: 7
Explanation: 
- Index 0: 1 < 3, not a peak
- Index 1: 3 > 1 and 3 > 2, peak (add 3)
- Index 2: 2 < 3 and 2 < 4, not a peak
- Index 3: 4 > 2 and 4 > 1, peak (add 4)
- Index 4: 1 < 4, not a peak
Sum = 3 + 4 = 7
```

### Example 2 / 示例2
```
Input: [5, 1, 3]
Output: 8
Explanation:
- Index 0: 5 > 1, peak (add 5)
- Index 1: 1 < 5 and 1 < 3, not a peak
- Index 2: 3 > 1, peak (add 3)
Sum = 5 + 3 = 8
```

### Example 3 / 示例3
```
Input: [1, 2, 3, 4, 5]
Output: 5
Explanation: Only last element 5 > 4, so sum = 5
```

## Input Format / 输入格式
- `nums`: List of integers

## Output Format / 输出格式
- Integer: Sum of local peak elements

## Constraints / 约束条件
- 1 ≤ nums.length ≤ 1000
- -1000 ≤ nums[i] ≤ 1000