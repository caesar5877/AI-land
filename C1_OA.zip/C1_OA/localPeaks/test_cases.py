from solution import sum_local_peaks

def test_sum_local_peaks():
    test_cases = [
        # Basic functionality
        {
            'input': [1, 3, 2, 4, 1],
            'expected': 7,
            'desc': 'Multiple peaks: 3 and 4'
        },
        {
            'input': [5, 1, 3],
            'expected': 8,
            'desc': 'First and last elements as peaks'
        },
        {
            'input': [1, 2, 3, 4, 5],
            'expected': 5,
            'desc': 'Ascending sequence, only last element'
        },
        
        # Edge cases
        {
            'input': [5],
            'expected': 5,
            'desc': 'Single element'
        },
        {
            'input': [1, 2],
            'expected': 2,
            'desc': 'Two elements, second is peak'
        },
        {
            'input': [3, 1],
            'expected': 3,
            'desc': 'Two elements, first is peak'
        },
        
        # Complex scenarios
        {
            'input': [5, 4, 3, 2, 1],
            'expected': 5,
            'desc': 'Descending sequence, only first element'
        },
        {
            'input': [1, 5, 1, 5, 1],
            'expected': 10,
            'desc': 'Alternating pattern with two peaks'
        },
        {
            'input': [2, 2, 2, 2],
            'expected': 0,
            'desc': 'All equal elements, no peaks'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            result = sum_local_peaks(test['input'])
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_sum_local_peaks()