def sum_local_peaks(nums):
    """
    Find the sum of elements that are greater than their adjacent elements.
    
    Args:
        nums: List of integers
        
    Returns:
        int: Sum of local peak elements
    """
    if not nums:
        return 0
    
    if len(nums) == 1:
        return nums[0]
    
    total = 0
    
    # Check first element (only compare with right neighbor)
    if nums[0] > nums[1]:
        total += nums[0]
    
    # Check middle elements (compare with both neighbors)
    for i in range(1, len(nums) - 1):
        if nums[i] > nums[i-1] and nums[i] > nums[i+1]:
            total += nums[i]
    
    # Check last element (only compare with left neighbor)
    if nums[-1] > nums[-2]:
        total += nums[-1]
    
    return total