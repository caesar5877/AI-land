from solution import most_frequent_digital_root

def test_most_frequent_digital_root():
    test_cases = [
        # Basic functionality
        {
            'input': [456, 123, 789],
            'expected': 6,
            'desc': 'All numbers have digital root 6'
        },
        {
            'input': [12, 34, 56, 78],
            'expected': 3,
            'desc': 'All different roots, return first encountered'
        },
        {
            'input': [11, 22, 33, 44],
            'expected': 2,
            'desc': 'Roots: 2, 4, 6, 8 - return first'
        },
        
        # Edge cases
        {
            'input': [9],
            'expected': 9,
            'desc': 'Single digit number'
        },
        {
            'input': [10, 100, 1000],
            'expected': 1,
            'desc': 'All have digital root 1'
        },
        {
            'input': [99, 999, 9999],
            'expected': 9,
            'desc': 'All have digital root 9'
        },
        
        # Complex scenarios
        {
            'input': [123, 456, 789, 147, 258, 369],
            'expected': 6,
            'desc': 'Mixed numbers, 6 appears twice'
        },
        {
            'input': [1, 2, 3, 4, 5, 6, 7, 8, 9],
            'expected': 1,
            'desc': 'All single digits, return first'
        },
        {
            'input': [19, 28, 37, 46, 55],
            'expected': 1,
            'desc': 'Roots: 1, 1, 1, 1, 1 - all same'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            result = most_frequent_digital_root(test['input'])
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_most_frequent_digital_root()