# Digital Root Frequency / 数字根频率

## Problem Statement / 问题描述

**English:**
Given a list of numbers, calculate the digital root of each number and return the digital root that appears most frequently.

Digital root is calculated by repeatedly summing the digits of a number until only one digit remains.

**中文:**
给定一个数字列表，计算每个数字的数字根，返回出现频次最高的数字根。

数字根通过反复将数字的各位数相加直到只剩一位数字来计算。

## Examples / 示例

### Example 1 / 示例1
```
Input: [456, 123, 789]
Output: 6

Explanation:
- 456 → 4+5+6=15 → 1+5=6
- 123 → 1+2+3=6  
- 789 → 7+8+9=24 → 2+4=6
Digital root 6 appears 3 times (most frequent)
```

### Example 2 / 示例2
```
Input: [12, 34, 56, 78]
Output: 3

Explanation:
- 12 → 1+2=3
- 34 → 3+4=7
- 56 → 5+6=11 → 1+1=2
- 78 → 7+8=15 → 1+5=6
All appear once, return the first one: 3
```

## Input Format / 输入格式
- `nums`: List of positive integers

## Output Format / 输出格式
- Integer: Most frequent digital root (1-9)

## Constraints / 约束条件
- 1 ≤ nums.length ≤ 1000
- 1 ≤ nums[i] ≤ 10^6