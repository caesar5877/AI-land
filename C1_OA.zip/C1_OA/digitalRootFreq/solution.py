def most_frequent_digital_root(nums):
    """
    Find the most frequent digital root from a list of numbers.
    
    Args:
        nums: List of positive integers
        
    Returns:
        int: Most frequent digital root (1-9)
    """
    def digital_root(n):
        """Calculate digital root by repeatedly summing digits"""
        while n >= 10:
            n = sum(int(digit) for digit in str(n))
        return n
    
    # Count frequency of each digital root
    freq = {}
    for num in nums:
        root = digital_root(num)
        freq[root] = freq.get(root, 0) + 1
    
    # Find most frequent digital root
    return max(freq, key=freq.get)