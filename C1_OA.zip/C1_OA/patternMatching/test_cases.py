from solution import find_pattern_matches

def test_find_pattern_matches():
    test_cases = [
        # Basic functionality
        {
            'input': ([4, 4, 5, 5, 1], [1, 0, -1]),
            'expected': [[4, 5, 5, 1]],
            'desc': 'Example case: 4<5=5>1 matches [1,0,-1]'
        },
        {
            'input': ([1, 2, 3, 2, 1], [1, 1]),
            'expected': [[1, 2, 3]],
            'desc': 'Increasing pattern: 1<2<3 matches [1,1]'
        },
        {
            'input': ([5, 4, 3, 2, 1], [-1, -1]),
            'expected': [[5, 4, 3], [4, 3, 2], [3, 2, 1]],
            'desc': 'Decreasing pattern: multiple matches'
        },
        
        # Edge cases
        {
            'input': ([1, 1, 1], [0]),
            'expected': [[1, 1], [1, 1]],
            'desc': 'Equal pattern: consecutive equal elements'
        },
        {
            'input': ([1, 2, 1, 2], [1, -1]),
            'expected': [[1, 2, 1]],
            'desc': 'Up-down pattern: 1<2>1 matches [1,-1]'
        },
        {
            'input': ([1, 2, 3, 4], [1, 1, 1]),
            'expected': [[1, 2, 3, 4]],
            'desc': 'Long increasing pattern'
        },
        
        # Complex scenarios
        {
            'input': ([3, 1, 4, 1, 5], [1, -1]),
            'expected': [[1, 4, 1]],
            'desc': 'Single match in middle'
        },
        {
            'input': ([2, 2, 3, 3, 1, 1], [0, 1, 0, -1, 0]),
            'expected': [[2, 2, 3, 3, 1, 1]],
            'desc': 'Complex pattern: 2=2<3=3>1=1 matches [0,1,0,-1,0]'
        },
        {
            'input': ([1, 2, 3], [-1]),
            'expected': [],
            'desc': 'No matches found'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            nums, pattern = test['input']
            result = find_pattern_matches(nums, pattern)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_find_pattern_matches()