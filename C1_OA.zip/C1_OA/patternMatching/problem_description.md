# Pattern Matching / 模式匹配

## Problem Statement / 问题描述

**English:**
Given an array of integers and another array representing a pattern, find all subarrays from the integer array that match the pattern.

A pattern is an integer array formed by -1, 0, and 1 only:
- 1 means the current number is greater than its previous number
- 0 means the current number equals the previous number  
- -1 means the current number is less than the previous number

**中文:**
给定一个整数数组和另一个表示模式的数组，找出整数数组中所有匹配该模式的子数组。

模式是仅由-1、0和1组成的整数数组：
- 1表示当前数字大于前一个数字
- 0表示当前数字等于前一个数字
- -1表示当前数字小于前一个数字

## Examples / 示例

### Example 1 / 示例1
```
Input: 
nums = [4, 4, 5, 5, 1]
pattern = [1, 0, -1]

Output: [[4, 5, 5, 1]]

Explanation:
Subarray [4, 5, 5, 1] matches pattern [1, 0, -1]:
- 5 > 4 (matches 1)
- 5 = 5 (matches 0) 
- 1 < 5 (matches -1)
```

### Example 2 / 示例2
```
Input:
nums = [1, 2, 3, 2, 1]
pattern = [1, 1]

Output: [[1, 2, 3]]

Explanation:
Subarray [1, 2, 3] matches pattern [1, 1]:
- 2 > 1 (matches 1)
- 3 > 2 (matches 1)
```

## Input Format / 输入格式
- `nums`: Array of integers
- `pattern`: Array of -1, 0, 1 representing comparison pattern

## Output Format / 输出格式
- List of subarrays that match the pattern

## Constraints / 约束条件
- 1 ≤ nums.length ≤ 1000
- 1 ≤ pattern.length < nums.length
- pattern[i] ∈ {-1, 0, 1}