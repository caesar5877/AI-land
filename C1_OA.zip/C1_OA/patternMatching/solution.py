def find_pattern_matches(nums, pattern):
    """
    Find all subarrays that match the given comparison pattern.
    
    Args:
        nums: List of integers
        pattern: List of -1, 0, 1 representing comparison pattern
        
    Returns:
        List[List[int]]: All subarrays matching the pattern
    """
    # Store all matching subarrays
    result = []
    pattern_len = len(pattern)
    
    # Check each possible starting position for pattern matching
    # Need pattern_len+1 elements to check pattern_len comparisons
    for i in range(len(nums) - pattern_len):
        # Assume current position matches until proven otherwise
        matches = True
        
        # Check each comparison in the pattern
        for j in range(pattern_len):
            # Get consecutive elements to compare
            curr = nums[i + j + 1]  # Current element
            prev = nums[i + j]      # Previous element
            
            # Determine actual relationship between elements
            if curr > prev:
                actual = 1   # Increasing
            elif curr == prev:
                actual = 0   # Equal
            else:
                actual = -1  # Decreasing
            
            # Check if actual relationship matches expected pattern
            if actual != pattern[j]:
                matches = False
                break  # No need to check further
        
        # If entire pattern matches, add subarray to result
        if matches:
            # Subarray includes pattern_len+1 elements
            subarray = nums[i:i + pattern_len + 1]
            result.append(subarray)
    
    # Return all matching subarrays
    return result