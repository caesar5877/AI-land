def card_game_rounds(deck_a, deck_b):
    """
    Calculate the number of rounds in a card game between two players.
    
    Args:
        deck_a: List of cards for player A
        deck_b: List of cards for player B
        
    Returns:
        int: Number of rounds played
    """
    # Create copies to avoid modifying original decks
    a, b = deck_a[:], deck_b[:]
    # Counter for total rounds played
    rounds = 0
    
    # Continue playing while both players have cards
    while a and b:
        # Each player draws their top card (first in list)
        card_a, card_b = a.pop(0), b.pop(0)
        # Increment round counter
        rounds += 1
        
        # Determine round winner and redistribute cards
        if card_a >= card_b:  # Player A wins (including ties)
            # Winner gets both cards: their card first, then opponent's
            a.extend([card_a, card_b])
        else:  # Player B wins
            # Winner gets both cards: their card first, then opponent's
            b.extend([card_b, card_a])
    
    # Return total number of rounds until one player runs out of cards
    return rounds