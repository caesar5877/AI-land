def find_path(pairs):
    """
    Find the order of visiting integers to form a valid path.
    
    Args:
        pairs: List of integer pairs representing connections
        
    Returns:
        list: Valid visiting order, or empty list if no path exists
    """
    if not pairs:
        return []
    
    # Build adjacency graph
    graph = {}
    all_nodes = set()
    
    for a, b in pairs:
        if a not in graph:
            graph[a] = []
        if b not in graph:
            graph[b] = []
        graph[a].append(b)
        graph[b].append(a)
        all_nodes.add(a)
        all_nodes.add(b)
    
    # Try DFS from each node to find Hamiltonian path
    def dfs(node, visited, path):
        if len(path) == len(all_nodes):
            return path[:]
        
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                path.append(neighbor)
                result = dfs(neighbor, visited, path)
                if result:
                    return result
                path.pop()
                visited.remove(neighbor)
        return None
    
    # Try starting from each node
    for start_node in all_nodes:
        visited = {start_node}
        path = [start_node]
        result = dfs(start_node, visited, path)
        if result:
            return result
    
    return []