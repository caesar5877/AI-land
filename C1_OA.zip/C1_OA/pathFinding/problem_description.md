# Path Finding / 路径查找

## Problem Statement / 问题描述

**English:**
Given a list of pairs of integers, find the order of visiting the integers to form a valid path. Each pair represents a connection between two integers. The result should be a sequence that visits all integers exactly once, following the connections.

**中文:**
给定一个整数对列表，找到访问这些整数的顺序以形成有效路径。每个对表示两个整数之间的连接。结果应该是一个序列，按照连接关系恰好访问每个整数一次。

## Examples / 示例

### Example 1 / 示例1
```
Input: [[3, 5], [1, 4], [4, 2], [1, 5]]
Output: [3, 5, 1, 4, 2] or [2, 4, 1, 5, 3]
Explanation: Following connections: 3-5-1-4-2 forms a valid path
```

### Example 2 / 示例2
```
Input: [[1, 2], [2, 3], [3, 4]]
Output: [1, 2, 3, 4] or [4, 3, 2, 1]
Explanation: Linear path from 1 to 4 or reversed
```

### Example 3 / 示例3
```
Input: [[1, 3], [2, 4]]
Output: []
Explanation: No valid path exists (disconnected components)
```

## Input Format / 输入格式
- `pairs`: List of integer pairs representing connections

## Output Format / 输出格式
- List of integers: Valid visiting order, or empty list if no path exists

## Constraints / 约束条件
- 1 ≤ pairs.length ≤ 100
- Each pair contains two distinct integers
- 1 ≤ integers ≤ 1000