from solution import find_path

def test_find_path():
    test_cases = [
        # Basic functionality
        {
            'input': [[3, 5], [1, 4], [4, 2], [1, 5]],
            'expected': [3, 5, 1, 4, 2],
            'desc': 'Connected path example from problem'
        },
        {
            'input': [[1, 2], [2, 3], [3, 4]],
            'expected': [1, 2, 3, 4],
            'desc': 'Linear path'
        },
        {
            'input': [[1, 2], [2, 3], [1, 3]],
            'expected': [1, 2, 3],
            'desc': 'Triangle - valid Hamiltonian path'
        },
        
        # Edge cases
        {
            'input': [[1, 2]],
            'expected': [1, 2],
            'desc': 'Single pair'
        },
        {
            'input': [],
            'expected': [],
            'desc': 'Empty input'
        },
        {
            'input': [[1, 3], [2, 4]],
            'expected': [],
            'desc': 'Disconnected components'
        },
        
        # Complex scenarios
        {
            'input': [[1, 2], [2, 3], [3, 4], [4, 1]],
            'expected': [1, 2, 3, 4],
            'desc': 'Square cycle - valid Hamiltonian path'
        },
        {
            'input': [[1, 2], [2, 3], [3, 1], [1, 4]],
            'expected': [2, 3, 1, 4],
            'desc': 'Triangle with tail - valid Hamiltonian path'
        },
        {
            'input': [[5, 1], [1, 3], [3, 2], [2, 4]],
            'expected': [5, 1, 3, 2, 4],
            'desc': 'Chain path'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            result = find_path(test['input'])
            expected = test['expected']
            
            # Check if result matches expected or its reverse
            is_valid = (result == expected or 
                       result == expected[::-1] or
                       (not result and not expected))
            
            if is_valid:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {expected} or reversed")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_find_path()