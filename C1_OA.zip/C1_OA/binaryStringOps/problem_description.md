# Binary String Operations / 二进制字符串操作

## Problem Statement / 问题描述

**English:**
Given a binary string of 0s and 1s, and an operation array with two types of operations:
- `L`: Find the 0 with the smallest index, replace it with 1
- `C{index}`: Change the character at the specified index to 1

Return the finalized result as a string.

**中文:**
给定一个由0和1组成的二进制字符串，以及包含两种操作类型的操作数组：
- `L`：找到索引最小的0，将其替换为1
- `C{index}`：将指定索引处的字符更改为1

返回最终结果字符串。

## Examples / 示例

### Example 1 / 示例1
```
Input: 
str = "000000"
ops = ["L", "C3", "C4", "L"]

Output: "110110"

Explanation:
- Initial: "000000"
- L: Change leftmost 0 at index 0 → "100000"
- C3: Change index 3 to 1 → "100100"
- C4: Change index 4 to 1 → "100110"
- L: Change leftmost 0 at index 1 → "110110"
```

### Example 2 / 示例2
```
Input:
str = "0101"
ops = ["L", "L"]

Output: "1111"

Explanation:
- Initial: "0101"
- L: Change leftmost 0 at index 0 → "1101"
- L: Change leftmost 0 at index 2 → "1111"
```

## Input Format / 输入格式
- `str`: Binary string containing only '0' and '1'
- `ops`: Array of operation strings ("L" or "C{index}")

## Output Format / 输出格式
- String: Final binary string after all operations

## Constraints / 约束条件
- 1 ≤ str.length ≤ 1000
- 1 ≤ ops.length ≤ 1000
- All C operations have valid indices