def binary_string_operations(s, ops):
    """
    Apply operations to binary string: L (leftmost 0 to 1) or C{index} (index to 1).
    
    Args:
        s: Binary string of 0s and 1s
        ops: List of operation strings
        
    Returns:
        str: Final binary string after all operations
    """
    # Convert string to list for easier manipulation
    chars = list(s)
    
    # Process each operation
    for op in ops:
        if op == 'L':
            # Find leftmost 0 and change to 1
            for i in range(len(chars)):
                if chars[i] == '0':
                    chars[i] = '1'
                    break
        else:
            # Extract index from C{index} format
            index = int(op[1:])
            # Change character at index to 1
            chars[index] = '1'
    
    # Convert back to string
    return ''.join(chars)