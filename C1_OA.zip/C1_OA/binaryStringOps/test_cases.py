from solution import binary_string_operations

def test_binary_string_operations():
    test_cases = [
        # Basic functionality
        {
            'input': ("000000", ["L", "C3", "C4", "L"]),
            'expected': "110110",
            'desc': 'Example case: L, C3, C4, L operations'
        },
        {
            'input': ("0101", ["L", "L"]),
            'expected': "1111",
            'desc': 'Two L operations on alternating pattern'
        },
        {
            'input': ("1111", ["L", "C0"]),
            'expected': "1111",
            'desc': 'Operations on all 1s string'
        },
        
        # Edge cases
        {
            'input': ("0", ["L"]),
            'expected': "1",
            'desc': 'Single character with L operation'
        },
        {
            'input': ("1", ["C0"]),
            'expected': "1",
            'desc': 'Single character with C operation'
        },
        {
            'input': ("00", ["C1", "C0"]),
            'expected': "11",
            'desc': 'Only C operations'
        },
        
        # Complex scenarios
        {
            'input': ("0000", ["L", "L", "L", "L"]),
            'expected': "1111",
            'desc': 'All L operations on all 0s'
        },
        {
            'input': ("101010", ["C1", "C3", "C5"]),
            'expected': "111111",
            'desc': 'C operations on odd indices'
        },
        {
            'input': ("000", ["C2", "L", "C0"]),
            'expected': "101",
            'desc': 'Mixed operations: C2→001, L→101, C0→101'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            s, ops = test['input']
            result = binary_string_operations(s, ops)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_binary_string_operations()