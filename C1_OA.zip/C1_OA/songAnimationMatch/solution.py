def solution(songs, animations):
    """
    Match animations to songs based on divisor relationship.
    
    Args:
        songs: List of strings in format "name:length"
        animations: List of strings in format "name:length"
        
    Returns:
        List of strings in format "name:times" for matched animations
    """
    # Pre-parse animations to avoid repeated string operations
    # Convert each animation string to (name, length) tuple for efficiency
    parsed_animations = []
    for anim in animations:
        name, length = anim.split(':')
        parsed_animations.append((name, int(length)))
    
    # Store results for each song in order
    result = []
    
    # Process each song to find its matching animation
    for song in songs:
        # Extract song name and length from formatted string
        song_name, song_length = song.split(':')
        song_length = int(song_length)
        
        # Find first animation whose length divides song length evenly
        # Use modulo operator to check if division is exact (no remainder)
        for anim_name, anim_length in parsed_animations:
            if song_length % anim_length == 0:
                # Calculate how many times animation needs to play
                times = song_length // anim_length
                # Format result as "animationName:playCount"
                result.append(f"{anim_name}:{times}")
                # Break after finding first valid match (lowest index priority)
                break
    
    # Return list of matched animations in same order as input songs
    return result