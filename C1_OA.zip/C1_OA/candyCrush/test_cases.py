from solution import candy_crush

def test_candy_crush():
    test_cases = [
        # Basic functionality
        {
            'input': [[1,3,5,5,2],[3,4,3,3,1],[3,2,4,5,2],[2,4,4,5,5],[1,4,4,1,1]],
            'expected': [[1,3,0,0,0],[3,4,0,5,2],[3,2,0,3,1],[2,4,0,5,2],[1,4,3,1,1]],
            'desc': 'Example 2: Multiple eliminations with gravity'
        },
        {
            'input': [[1,1,1],[2,2,2],[3,3,3]],
            'expected': [[0,0,0],[0,0,0],[0,0,0]],
            'desc': 'All rows eliminated'
        },
        {
            'input': [[1],[1],[1]],
            'expected': [[0],[0],[0]],
            'desc': 'Single column elimination'
        },
        
        # Edge cases
        {
            'input': [[1,2,3],[4,5,6],[7,8,9]],
            'expected': [[1,2,3],[4,5,6],[7,8,9]],
            'desc': 'No eliminations possible'
        },
        {
            'input': [[1,1,2],[1,2,2],[2,2,1]],
            'expected': [[1,1,2],[1,2,2],[2,2,1]],
            'desc': 'No valid eliminations (no 3+ groups)'
        },
        {
            'input': [[1,1,1,2,2],[2,2,2,1,1],[3,3,3,3,3]],
            'expected': [[0,0,0,0,0],[0,0,0,2,2],[0,0,0,1,1]],
            'desc': 'Multiple horizontal eliminations with gravity'
        },
        
        # Complex scenarios
        {
            'input': [[1,2,1],[1,2,1],[1,2,1]],
            'expected': [[0,0,0],[0,0,0],[0,0,0]],
            'desc': 'Vertical elimination of all columns'
        },
        {
            'input': [[1,1,1,1],[2,3,4,5],[6,7,8,9]],
            'expected': [[0,0,0,0],[2,3,4,5],[6,7,8,9]],
            'desc': 'Four in a row elimination'
        },
        {
            'input': [[1,2,3,4,5],[1,2,3,4,5],[1,2,3,4,5]],
            'expected': [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]],
            'desc': 'All columns eliminated'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            # Create deep copy to avoid modifying test input
            board_copy = [row[:] for row in test['input']]
            result = candy_crush(board_copy)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_candy_crush()