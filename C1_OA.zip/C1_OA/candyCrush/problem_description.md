# Candy Crush / 糖果粉碎

## Problem Statement / 问题描述

**English:**
Implement a basic elimination algorithm for Candy Crush. Given an m x n integer array board representing the grid of candy where board[i][j] represents the type of candy. A value of board[i][j] == 0 represents that the cell is empty.

The given board represents the state of the game following the player's move. You need to restore the board to a stable state by crushing candies according to the following rules:

1. If three or more candies of the same type are adjacent vertically or horizontally, crush them all at the same time - these positions become empty.
2. After crushing all candies simultaneously, if an empty space on the board has candies on top of itself, then these candies will drop until they hit a candy or bottom at the same time.
3. After the above steps, there may exist more candies that can be crushed. If so, repeat the above steps.
4. If there does not exist more candies that can be crushed (i.e., the board is stable), then return the current board.

**中文:**
实现糖果粉碎的基本消除算法。给定一个 m x n 整数数组 board 表示糖果网格，其中 board[i][j] 表示糖果的类型。值 board[i][j] == 0 表示该单元格为空。

给定的棋盘表示玩家移动后的游戏状态。您需要根据以下规则粉碎糖果，将棋盘恢复到稳定状态：

1. 如果三个或更多相同类型的糖果垂直或水平相邻，则同时粉碎它们 - 这些位置变为空。
2. 同时粉碎所有糖果后，如果棋盘上的空白空间上方有糖果，则这些糖果会下降，直到撞到糖果或底部。
3. 执行上述步骤后，可能存在更多可以粉碎的糖果。如果是这样，重复上述步骤。
4. 如果不存在更多可以粉碎的糖果（即棋盘稳定），则返回当前棋盘。

## Examples / 示例

### Example 1 / 示例1
```
Input: board = [[110,5,112,113,114],[210,211,5,213,214],[310,311,3,313,314],[410,411,412,5,414],[5,1,512,3,3],[610,4,1,613,614],[710,1,2,713,714],[810,1,2,1,1],[1,1,2,2,2],[4,1,4,4,1014]]
Output: [[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[110,0,0,0,114],[210,0,0,0,214],[310,0,0,113,314],[410,0,0,213,414],[610,211,112,313,614],[710,311,412,613,714],[810,411,512,713,1014]]
```

### Example 2 / 示例2
```
Input: board = [[1,3,5,5,2],[3,4,3,3,1],[3,2,4,5,2],[2,4,4,5,5],[1,4,4,1,1]]
Output: [[1,3,0,0,0],[3,4,0,5,2],[3,2,0,3,1],[2,4,0,5,2],[1,4,3,1,1]]
```

## Input Format / 输入格式
- `board`: m x n integer matrix where each cell contains candy type (positive integer) or 0 (empty)

## Output Format / 输出格式
- Return the stable board after all possible eliminations and gravity applications

## Constraints / 约束条件
- m == board.length
- n == board[i].length  
- 3 <= m, n <= 50
- 1 <= board[i][j] <= 2000