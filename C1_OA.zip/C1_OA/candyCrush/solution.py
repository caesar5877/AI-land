def candy_crush(board):
    """
    Crush candies until board becomes stable.
    
    Args:
        board: 2D list of integers representing candy types (0 = empty)
        
    Returns:
        2D list: Stable board after all eliminations and gravity
    """
    # Get board dimensions for boundary checks
    rows, cols = len(board), len(board[0])
    
    def mark_crushable():
        # Use set to store unique positions to crush
        to_crush = set()
        
        # Check horizontal groups of 3 or more consecutive candies
        for r in range(rows):
            count = 1  # Count of consecutive same candies
            for c in range(1, cols):
                # If current candy matches previous and is not empty
                if board[r][c] != 0 and board[r][c] == board[r][c-1]:
                    count += 1  # Extend current group
                else:
                    # Group ended, check if it's crushable (3+)
                    if count >= 3:
                        # Mark entire previous group for crushing
                        for k in range(c - count, c):
                            to_crush.add((r, k))
                    count = 1  # Reset count for new group
            
            # Check final group at end of row
            if count >= 3:
                for k in range(cols - count, cols):
                    to_crush.add((r, k))
        
        # Check vertical groups of 3 or more consecutive candies
        for c in range(cols):
            count = 1  # Count of consecutive same candies
            for r in range(1, rows):
                # If current candy matches above and is not empty
                if board[r][c] != 0 and board[r][c] == board[r-1][c]:
                    count += 1  # Extend current group
                else:
                    # Group ended, check if it's crushable (3+)
                    if count >= 3:
                        # Mark entire previous group for crushing
                        for k in range(r - count, r):
                            to_crush.add((k, c))
                    count = 1  # Reset count for new group
            
            # Check final group at bottom of column
            if count >= 3:
                for k in range(rows - count, rows):
                    to_crush.add((k, c))
        
        # Return all positions marked for crushing
        return to_crush
    
    def apply_gravity():
        # Process each column independently for gravity effect
        for c in range(cols):
            # Collect all non-empty candies from bottom to top
            candies = []
            for r in range(rows - 1, -1, -1):  # Bottom to top
                if board[r][c] != 0:
                    candies.append(board[r][c])
            
            # Refill column: place candies at bottom, empty spaces at top
            for r in range(rows):
                if r < len(candies):
                    # Place collected candies starting from bottom
                    board[rows - 1 - r][c] = candies[r]
                else:
                    # Fill remaining positions with empty spaces
                    board[rows - 1 - r][c] = 0
    
    # Main game loop: repeat until board becomes stable
    while True:
        # Find all positions that should be crushed
        to_crush = mark_crushable()
        
        # If no positions to crush, board is stable
        if not to_crush:
            break
        
        # Simultaneously crush all marked positions
        for r, c in to_crush:
            board[r][c] = 0  # Set to empty
        
        # Apply gravity to drop remaining candies
        apply_gravity()
    
    # Return final stable board state
    return board