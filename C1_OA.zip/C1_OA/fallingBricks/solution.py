def min_obstacles_to_remove(matrix):
    """
    Find minimum obstacles to remove so brick block can fall to bottom.
    
    Args:
        matrix: 2D list with '&' (brick), '_' (empty), '*' (obstacle)
        
    Returns:
        int: Minimum obstacles to remove
    """
    # Handle empty matrix edge case
    if not matrix or not matrix[0]:
        return 0
    
    # Get matrix dimensions
    rows, cols = len(matrix), len(matrix[0])
    
    # Locate all brick positions in the matrix
    brick_positions = []
    for r in range(rows):
        for c in range(cols):
            if matrix[r][c] == '&':
                brick_positions.append((r, c))
    
    # If no bricks found, no obstacles need to be removed
    if not brick_positions:
        return 0
    
    # Find the lowest row containing any brick
    # This determines how far the block can potentially fall
    max_brick_row = max(pos[0] for pos in brick_positions)
    
    # If bricks are already at the bottom row, no movement needed
    if max_brick_row == rows - 1:
        return 0
    
    # Calculate maximum possible fall distance
    # Block must fall to the very bottom of the matrix
    max_fall = rows - 1 - max_brick_row
    
    # Use set to avoid counting same obstacle multiple times
    obstacles_needed = set()
    
    # Check where each brick would land after falling to bottom
    for r, c in brick_positions:
        # Calculate new position after falling maximum distance
        new_r = r + max_fall
        
        # If new position contains obstacle, mark for removal
        if matrix[new_r][c] == '*':
            obstacles_needed.add((new_r, c))
    
    # Return count of obstacles that need to be removed
    return len(obstacles_needed)