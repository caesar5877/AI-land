from solution import min_obstacles_to_remove

def test_falling_bricks():
    """Comprehensive test cases for falling bricks problem"""
    
    test_cases = [
        # Basic example from problem
        {
            "matrix": [
                ['&', '&', '&', '&'],
                ['&', '&', '_', '_'],
                ['*', '_', '*', '_']
            ],
            "expected": 1,
            "desc": "Example case - remove bottom-left obstacle"
        },
        
        # No obstacles
        {
            "matrix": [
                ['&', '&'],
                ['_', '_'],
                ['_', '_']
            ],
            "expected": 0,
            "desc": "No obstacles to remove"
        },
        
        # Multiple obstacles in path
        {
            "matrix": [
                ['&', '_'],
                ['*', '_'],
                ['*', '_'],
                ['*', '_']
            ],
            "expected": 1,
            "desc": "Brick falls to bottom, only bottom obstacle matters"
        },
        
        # Choose best column
        {
            "matrix": [
                ['&', '&'],
                ['*', '_'],
                ['*', '*'],
                ['*', '_']
            ],
            "expected": 1,
            "desc": "Choose column with fewer obstacles"
        },
        
        # No bricks
        {
            "matrix": [
                ['_', '*'],
                ['*', '_']
            ],
            "expected": 0,
            "desc": "No bricks in matrix"
        },
        
        # Bricks already at bottom
        {
            "matrix": [
                ['_', '_'],
                ['&', '&']
            ],
            "expected": 0,
            "desc": "Bricks already at bottom"
        },
        
        # Single brick
        {
            "matrix": [
                ['&'],
                ['*'],
                ['*']
            ],
            "expected": 1,
            "desc": "Single brick falls to bottom, only bottom obstacle matters"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = min_obstacles_to_remove(test["matrix"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Matrix:")
        for row in test["matrix"]:
            print(f"    {row}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_falling_bricks()