# Falling Bricks Problem / 下落砖块问题

## Problem Statement / 问题描述

### English
Given a matrix with 3 types of elements, find the minimum number of obstacles to remove so that a connected brick block can fall to the bottom.

### 中文
给定一个包含3种元素的矩阵，找到需要移除的最少障碍物数量，使得连接的砖块可以下落到底部。

## Elements / 元素

### English
- `&`: Brick (forms a connected block)
- `_`: Empty space
- `*`: Obstacle

### 中文
- `&`: 砖块（形成连接块）
- `_`: 空间
- `*`: 障碍物

## Rules / 规则

### English
- Bricks form a connected block that falls downward due to gravity
- The brick block must reach the bottom row of the matrix
- The brick block always stays within matrix boundaries when falling
- The brick block can always reach the bottom by removing obstacles in its path
- Find minimum obstacles to remove to clear the fall path
- The brick block falls as a unit and maintains its shape

### 中文
- 砖块形成一个连接块，由于重力作用向下下落
- 砖块必须到达矩阵的底行
- 砖块下落时始终保持在矩阵边界内
- 通过移除路径中的障碍物，砖块总是可以到达底部
- 找到清除下落路径所需的最少障碍物移除数量
- 砖块作为一个整体下落并保持其形状

## Example / 示例
```
[&, &, &, &]
[&, &, _, _]
[*, _, *, _]
```

### English
The brick block occupies columns 0-1. To reach bottom, it needs column 0 or 1 clear.
Removing the obstacle at (2,0) allows the block to fall.
Answer: 1

### 中文
砖块占据第0-1列。要到达底部，需要第0列或第1列清空。
移除(2,0)处的障碍物允许块下落。
答案：1

## Output / 输出

### English
Return the minimum number of obstacles that need to be removed. The brick can always reach the bottom, so the answer is always a non-negative integer (could be 0 if path is already clear).

### 中文
返回需要移除的最少障碍物数量。砖块总是可以到达底部，所以答案总是一个非负整数（如果路径已经清空，可能为0）。