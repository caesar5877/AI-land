def count_case_diff(s):
    """
    Count uppercase and lowercase characters in a string and return their difference.
    
    Args:
        s (str): Input string
        
    Returns:
        int: (uppercase count) - (lowercase count)
    """
    # Count uppercase letters using generator expression for efficiency
    # isupper() returns True for uppercase alphabetic characters
    upper = sum(1 for c in s if c.isupper())
    
    # Count lowercase letters using generator expression for efficiency
    # islower() returns True for lowercase alphabetic characters
    lower = sum(1 for c in s if c.islower())
    
    # Return difference: positive if more uppercase, negative if more lowercase
    return upper - lower