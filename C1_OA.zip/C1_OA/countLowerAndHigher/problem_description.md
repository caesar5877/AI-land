# Count Case Difference Problem / 大小写字符差值问题

## Problem Statement / 问题描述

### English
Given a string, count the number of uppercase characters and lowercase characters, then return the difference between them.

### 中文
统计一个字符串的大写字符个数和小写字符个数，返回两者的差值。

## Requirements / 要求

### English
- Count uppercase letters in the string
- Count lowercase letters in the string  
- Return: (uppercase count) - (lowercase count)
- Non-letter characters (digits, spaces, symbols) should be ignored

### 中文
- 统计字符串中的大写字母个数
- 统计字符串中的小写字母个数
- 返回：(大写字母个数) - (小写字母个数)
- 忽略非字母字符（数字、空格、符号）

## Examples / 示例
- "Hello World" → 2 uppercase, 8 lowercase → 2 - 8 = -6
- "ABC" → 3 uppercase, 0 lowercase → 3 - 0 = 3
- "abc" → 0 uppercase, 3 lowercase → 0 - 3 = -3
- "AaBbCc" → 3 uppercase, 3 lowercase → 3 - 3 = 0