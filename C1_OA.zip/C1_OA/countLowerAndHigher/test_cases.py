from solution import count_case_diff

def test_count_case_diff():
    """Comprehensive test cases for count_case_diff function"""
    
    test_cases = [
        # Basic cases
        ("", 0),                    # Empty string
        ("ABC", 3),                 # All uppercase
        ("abc", -3),                # All lowercase
        ("AaBbCc", 0),              # Equal upper/lower
        
        # Mixed with non-letters
        ("Hello World", -6),        # Mixed with space (H,W vs ello,orld)
        ("123", 0),                 # Only digits
        ("!@#$%", 0),               # Only symbols
        ("A1b2C3", 1),              # Mixed with numbers (A,C vs b)
        
        # Edge cases
        ("a", -1),                  # Single lowercase
        ("Z", 1),                   # Single uppercase
        ("PyThOn", 0),              # Mixed case (P,T,O vs y,h,n)
        ("Hello123World!", -6),     # Complex mixed (H,W vs ello,orld)
        ("UPPER lower", 0),         # Equal counts with space
        ("aA", 0),                  # Minimal equal case
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 50)
    
    passed = 0
    total = len(test_cases)
    
    for i, (input_str, expected) in enumerate(test_cases, 1):
        result = count_case_diff(input_str)
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i:2d}: '{input_str}' -> {result:2d} (expected: {expected:2d}) [{status}]")
    
    print("-" * 50)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_count_case_diff()