def max_robot_distance(rows, cols, robot_pos, laser_positions):
    """
    Find the maximum distance a robot can travel in any single direction.
    
    Args:
        rows (int): Number of rows in matrix
        cols (int): Number of columns in matrix
        robot_pos (list): Robot position [row, col]
        laser_positions (list): List of laser positions [[row, col], ...]
        
    Returns:
        int: Maximum distance robot can travel in any direction
    """
    # Extract robot's current position
    robot_r, robot_c = robot_pos
    
    # Pre-compute sets of laser-covered rows and columns for O(1) lookup
    # Lasers block entire rows and columns they're positioned in
    laser_rows = set()
    laser_cols = set()
    for laser_r, laser_c in laser_positions:
        laser_rows.add(laser_r)
        laser_cols.add(laser_c)
    
    # Track maximum distance achievable in any direction
    max_dist = 0
    
    # Check upward movement: from current row towards row 0
    dist = 0
    for r in range(robot_r - 1, -1, -1):  # Move up row by row
        if r in laser_rows:  # Stop if laser blocks this row
            break
        dist += 1  # Count each valid step
    max_dist = max(max_dist, dist)
    
    # Check downward movement: from current row towards last row
    dist = 0
    for r in range(robot_r + 1, rows):  # Move down row by row
        if r in laser_rows:  # Stop if laser blocks this row
            break
        dist += 1  # Count each valid step
    max_dist = max(max_dist, dist)
    
    # Check leftward movement: from current column towards column 0
    dist = 0
    for c in range(robot_c - 1, -1, -1):  # Move left column by column
        if c in laser_cols:  # Stop if laser blocks this column
            break
        dist += 1  # Count each valid step
    max_dist = max(max_dist, dist)
    
    # Check rightward movement: from current column towards last column
    dist = 0
    for c in range(robot_c + 1, cols):  # Move right column by column
        if c in laser_cols:  # Stop if laser blocks this column
            break
        dist += 1  # Count each valid step
    max_dist = max(max_dist, dist)
    
    # Return the maximum distance achievable in any single direction
    return max_dist