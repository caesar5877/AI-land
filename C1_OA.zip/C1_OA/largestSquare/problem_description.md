# Largest Square in Heights Problem / 高度中最大正方形问题

## Problem Statement / 问题描述

### English
Given an array of heights representing a histogram, find the area of the largest square that can fit within the histogram.

### 中文
给定一个表示直方图的高度数组，找到可以在直方图内放置的最大正方形的面积。

## Input / 输入

### English
- Array of integers representing heights at continuous horizontal coordinates
- Index i corresponds to position i on the x-axis
- heights[i] represents the height at position i

### 中文
- 整数数组，表示连续水平坐标上的高度
- 索引i对应x轴上的位置i
- heights[i]表示位置i处的高度

## Task / 任务

### English
Find the largest square that can fit completely within the area defined by these heights.

### 中文
找到可以完全放置在这些高度定义的区域内的最大正方形。

## Example / 示例

### English
Input: [1,2,3,2,1]
- Position 0: height 1
- Position 1: height 2  
- Position 2: height 3
- Position 3: height 2
- Position 4: height 1

The largest square has side length 2, giving area = 2×2 = 4.
This square can fit in positions 1-2 with height 2.

### 中文
输入：[1,2,3,2,1]
- 位置0：高度1
- 位置1：高度2
- 位置2：高度3
- 位置3：高度2
- 位置4：高度1

最大正方形的边长为2，面积 = 2×2 = 4。
这个正方形可以放置在位置1-2，高度为2。

## Output / 输出

### English
Return the area of the largest square that fits within the histogram.

### 中文
返回可以放置在直方图内的最大正方形的面积。