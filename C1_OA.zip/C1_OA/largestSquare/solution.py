def largest_square_area(heights):
    """
    Find the area of the largest square that fits in the histogram.
    
    Args:
        heights: List of integers representing heights
        
    Returns:
        int: Area of the largest square
    """
    # Handle empty input edge case
    if not heights:
        return 0
    
    # Track maximum square area found
    max_area = 0
    n = len(heights)
    
    # Try all possible starting positions
    for i in range(n):
        # Track minimum height in current range
        min_height = heights[i]
        
        # Extend range from starting position to end
        for j in range(i, n):
            # Update minimum height in current range [i, j]
            min_height = min(min_height, heights[j])
            
            # Calculate width of current range
            width = j - i + 1
            
            # Square side length is limited by both height and width
            # Take minimum to ensure square fits within constraints
            side = min(min_height, width)
            
            # Update maximum area if current square is larger
            max_area = max(max_area, side * side)
    
    # Return area of largest square found
    return max_area