from solution import largest_square_area

def test_largest_square():
    """Comprehensive test cases for largest square problem"""
    
    test_cases = [
        # Example from problem
        {
            "heights": [1, 2, 3, 2, 1],
            "expected": 4,
            "desc": "Example case - square of side 2"
        },
        
        # Single element
        {
            "heights": [5],
            "expected": 1,
            "desc": "Single element - square of side 1"
        },
        
        # Increasing heights
        {
            "heights": [1, 2, 3, 4, 5],
            "expected": 9,
            "desc": "Increasing heights - square of side 3"
        },
        
        # Decreasing heights
        {
            "heights": [5, 4, 3, 2, 1],
            "expected": 9,
            "desc": "Decreasing heights - square of side 3"
        },
        
        # All same height
        {
            "heights": [3, 3, 3, 3],
            "expected": 9,
            "desc": "All same height - square of side 3"
        },
        
        # Large square possible
        {
            "heights": [6, 6, 6, 6, 6],
            "expected": 25,
            "desc": "Large square - side 5"
        },
        
        # Small heights
        {
            "heights": [1, 1, 1, 1, 1],
            "expected": 1,
            "desc": "All height 1 - square of side 1"
        },
        
        # Mixed heights
        {
            "heights": [2, 1, 5, 6, 2, 3],
            "expected": 4,
            "desc": "Mixed heights - best square area 4"
        },
        
        # Empty array
        {
            "heights": [],
            "expected": 0,
            "desc": "Empty array"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = largest_square_area(test["heights"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Heights: {test['heights']}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_largest_square()