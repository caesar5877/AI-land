from solution import max_balance_length

def test_max_balance_length():
    test_cases = [
        # Basic functionality
        {
            'input': ([2, 4, 3, 1, 6], 3),
            'expected': 3,
            'desc': 'Subsequence [2, 4, 3] sum=9 divisible by 3'
        },
        {
            'input': ([1, 2, 3, 4, 5], 5),
            'expected': 5,
            'desc': 'Entire array sum=15 divisible by 5'
        },
        {
            'input': ([6, 3, 9], 3),
            'expected': 3,
            'desc': 'All elements divisible by 3, entire array'
        },
        
        # Edge cases
        {
            'input': ([5], 5),
            'expected': 1,
            'desc': 'Single element divisible by k'
        },
        {
            'input': ([7], 5),
            'expected': 0,
            'desc': 'Single element not divisible by k'
        },
        {
            'input': ([1, 1, 1], 2),
            'expected': 2,
            'desc': 'Two consecutive 1s sum to 2'
        },
        
        # Complex scenarios
        {
            'input': ([4, 2, 6, 8], 4),
            'expected': 4,
            'desc': 'Entire array sum divisible by 4'
        },
        {
            'input': ([1, 3, 5, 7], 4),
            'expected': 4,
            'desc': 'Entire array sum=16 divisible by 4'
        },
        {
            'input': ([10, 15, 20], 7),
            'expected': 2,
            'desc': 'Subsequence [10, 15] sum=25, [15, 20] sum=35 divisible by 7'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            nums, k = test['input']
            result = max_balance_length(nums, k)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_max_balance_length()