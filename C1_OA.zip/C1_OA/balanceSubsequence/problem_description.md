# Balance Subsequence / 平衡子序列

## Problem Statement / 问题描述

**English:**
Given a list of positive integers and a positive integer k, find the maximum length of a continuous subsequence whose sum is divisible by k. A continuous subsequence is called 'balance' if its sum can be divided by k.

**中文:**
给定一个正整数列表和一个正整数k，如果一段连续子序列的和可以被k整除，这段子序列称为'balance'，返回balance子序列的最长长度。

## Examples / 示例

### Example 1 / 示例1
```
Input: nums = [2, 4, 3, 1, 6], k = 3
Output: 4
Explanation: Subsequence [4, 3, 1, 6] has sum 14, but [2, 4, 3] has sum 9 which is divisible by 3.
Actually [4, 3, 1, 6] sum is 14, not divisible by 3.
The longest balance subsequence is [2, 4, 3] with length 3, or [3, 1, 6] with sum 10 (not divisible by 3).
Let me recalculate: [2, 4, 3] sum = 9 (divisible by 3), length = 3.
```

### Example 2 / 示例2
```
Input: nums = [1, 2, 3, 4, 5], k = 5
Output: 2
Explanation: [2, 3] has sum 5 which is divisible by 5, length = 2.
Also [5] has sum 5 which is divisible by 5, length = 1.
Maximum length is 2.
```

## Input Format / 输入格式
- `nums`: List of positive integers
- `k`: Positive integer divisor

## Output Format / 输出格式
- Integer: Maximum length of balance subsequence

## Constraints / 约束条件
- 1 ≤ nums.length ≤ 1000
- 1 ≤ nums[i] ≤ 1000
- 1 ≤ k ≤ 1000