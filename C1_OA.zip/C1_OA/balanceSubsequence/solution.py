def max_balance_length(nums, k):
    """
    Find maximum length of continuous subsequence whose sum is divisible by k.
    
    Args:
        nums: List of positive integers
        k: Positive integer divisor
        
    Returns:
        int: Maximum length of balance subsequence
    """
    # Map to store first occurrence of each remainder
    remainder_map = {0: -1}  # Initialize with remainder 0 at index -1
    prefix_sum = 0
    max_length = 0
    
    # Process each element to build prefix sums
    for i, num in enumerate(nums):
        prefix_sum += num
        remainder = prefix_sum % k
        
        if remainder in remainder_map:
            # Found same remainder before - subarray between indices is divisible by k
            length = i - remainder_map[remainder]
            max_length = max(max_length, length)
        else:
            # First occurrence of this remainder
            remainder_map[remainder] = i
    
    return max_length