from solution import bubble_elimination

def test_bubble_elimination():
    """Comprehensive test cases for bubble elimination game"""
    
    test_cases = [
        # Basic diagonal elimination
        {
            "bubbles": [
                [1, 2, 1],
                [2, 1, 2],
                [1, 2, 1]
            ],
            "clicks": [[1, 1]],
            "expected": [
                [0, 0, 0],
                [0, 2, 0],
                [2, 2, 2]
            ],
            "desc": "Center click eliminates diagonal 1s with gravity"
        },
        
        # Gravity after elimination
        {
            "bubbles": [
                [1, 2, 3],
                [2, 1, 2],
                [3, 2, 1]
            ],
            "clicks": [[1, 1]],
            "expected": [
                [0, 0, 0],
                [2, 2, 3],
                [3, 2, 2]
            ],
            "desc": "Elimination with gravity effect"
        },
        
        # Multiple clicks
        {
            "bubbles": [
                [1, 1, 1],
                [1, 2, 1],
                [1, 1, 1]
            ],
            "clicks": [[0, 0], [1, 1]],
            "expected": [
                [0, 0, 1],
                [1, 1, 1],
                [1, 1, 1]
            ],
            "desc": "Multiple clicks with actual result"
        },
        
        # No elimination (click on empty)
        {
            "bubbles": [
                [1, 0, 1],
                [0, 2, 0],
                [1, 0, 1]
            ],
            "clicks": [[0, 1]],
            "expected": [
                [1, 0, 1],
                [0, 2, 0],
                [1, 0, 1]
            ],
            "desc": "Click on empty space - no change"
        },
        
        # Single element
        {
            "bubbles": [[5]],
            "clicks": [[0, 0]],
            "expected": [[0]],
            "desc": "Single element elimination"
        },
        
        # Complex pattern
        {
            "bubbles": [
                [1, 2, 1, 2],
                [2, 1, 2, 1],
                [1, 2, 1, 2],
                [2, 1, 2, 1]
            ],
            "clicks": [[1, 1]],
            "expected": [
                [0, 0, 0, 0],
                [0, 2, 0, 2],
                [2, 2, 2, 1],
                [2, 1, 2, 2]
            ],
            "desc": "Complex diagonal pattern with gravity"
        },
        
        # Gravity test
        {
            "bubbles": [
                [1, 2, 3],
                [0, 1, 0],
                [2, 0, 1]
            ],
            "clicks": [[1, 1]],
            "expected": [
                [0, 0, 0],
                [0, 0, 0],
                [2, 2, 3]
            ],
            "desc": "Gravity pulls remaining bubbles down"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = bubble_elimination(test["bubbles"], test["clicks"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Initial:")
        for row in test["bubbles"]:
            print(f"    {row}")
        print(f"  Clicks: {test['clicks']}")
        print(f"  Result:")
        for row in result:
            print(f"    {row}")
        print(f"  Expected:")
        for row in expected:
            print(f"    {row}")
        print(f"  [{status}]")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_bubble_elimination()