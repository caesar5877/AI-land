def bubble_elimination(bubbles, clicks):
    """
    Process bubble elimination with diagonal propagation and gravity.
    
    Args:
        bubbles: 2D matrix of colors (positive integers) and empty spaces (0)
        clicks: List of click positions [[r, c], ...]
        
    Returns:
        Final matrix after all clicks and gravity
    """
    # Create deep copy to avoid modifying original matrix
    matrix = [row[:] for row in bubbles]
    rows, cols = len(matrix), len(matrix[0])
    
    def eliminate(r, c, color):
        # Start with the clicked bubble itself
        to_eliminate = [(r, c)]
        
        # Check all four diagonal directions from clicked position
        # Directions: up-left, up-right, down-left, down-right
        for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
            # Start from adjacent position in current direction
            nr, nc = r + dr, c + dc
            
            # Continue in this direction while bubbles match color
            while 0 <= nr < rows and 0 <= nc < cols and matrix[nr][nc] == color:
                # Add matching bubble to elimination list
                to_eliminate.append((nr, nc))
                # Move to next position in same direction
                nr, nc = nr + dr, nc + dc
        
        # Remove all bubbles marked for elimination
        for er, ec in to_eliminate:
            matrix[er][ec] = 0  # Set to empty space
    
    def apply_gravity():
        # Process each column independently
        for c in range(cols):
            # Collect all non-empty bubbles from bottom to top
            column = []
            for r in range(rows - 1, -1, -1):  # Bottom to top
                if matrix[r][c] != 0:
                    column.append(matrix[r][c])
            
            # Refill column: non-empty bubbles sink to bottom
            for r in range(rows):
                if r < len(column):
                    # Place collected bubbles at bottom
                    matrix[rows - 1 - r][c] = column[r]
                else:
                    # Fill remaining top positions with empty spaces
                    matrix[rows - 1 - r][c] = 0
    
    # Process each click in sequence
    for r, c in clicks:
        # Only process clicks on non-empty bubbles
        if matrix[r][c] > 0:
            # Eliminate bubbles of same color in diagonal lines
            eliminate(r, c, matrix[r][c])
            # Apply gravity after each elimination
            apply_gravity()
    
    # Return final state after all clicks processed
    return matrix