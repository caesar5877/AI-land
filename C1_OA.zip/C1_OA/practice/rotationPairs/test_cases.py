from solution import count_rotation_pairs

def run_tests():
    test_cases = [
        {
            'input': [31, 13],
            'expected': 1,
            'desc': 'Basic rotation pair'
        },
        {
            'input': [456, 564, 645],
            'expected': 3,
            'desc': 'Three numbers forming rotation group'
        },
        {
            'input': [123, 231, 312, 456],
            'expected': 3,
            'desc': 'Mixed rotation group and non-matching number'
        },
        {
            'input': [],
            'expected': 0,
            'desc': 'Empty list'
        },
        {
            'input': [123],
            'expected': 0,
            'desc': 'Single number'
        },
        {
            'input': [123, 456, 789],
            'expected': 0,
            'desc': 'No rotation pairs'
        },
        {
            'input': [111, 111],
            'expected': 1,
            'desc': 'Identical numbers'
        },
        {
            'input': [12, 21, 34, 43],
            'expected': 2,
            'desc': 'Two separate rotation pairs'
        },
        {
            'input': [1234, 2341, 3412, 4123, 5678],
            'expected': 6,
            'desc': 'Four numbers in rotation group plus one non-matching'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = count_rotation_pairs(test['input'])
        status = "PASS" if result == test['expected'] else "FAIL"
        print(f"Test {i}: {status}")
        print(f"  Description: {test['desc']}")
        print(f"  Input: {test['input']}")
        print(f"  Expected: {test['expected']}, Got: {result}")
        
        if result == test['expected']:
            passed += 1
        print()
    
    print(f"Results: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    run_tests()