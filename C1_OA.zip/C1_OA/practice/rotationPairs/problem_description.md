# Rotation Pairs / 旋转配对

## Problem Statement / 问题描述

**English:**
Given a list of numbers, find the number of pairs of items that can be the same number by rotating one of the items.
- Rotation means moving digits from the end to the beginning
- A pair consists of two different indices in the list
- Count each valid pair only once

**中文:**
给定一个数字列表，找出通过旋转其中一个数字可以变成相同数字的配对数量。
- 旋转意味着将数字从末尾移动到开头
- 一对由列表中两个不同的索引组成
- 每个有效配对只计算一次

## Requirements / 要求

- Input: List of integers / 输入：整数列表
- Output: Number of valid rotation pairs / 输出：有效旋转配对的数量
- Each pair should be counted only once / 每对只计算一次
- Numbers are treated as strings for rotation / 数字作为字符串处理旋转

## Examples / 示例

### Example 1 / 示例1
```
Input: [31, 13]
Output: 1

Explanation / 解释:
- 31 and 13: rotate 13 by 1 position → "13" → "31" ✓
- Valid pair: (31, 13)
```

### Example 2 / 示例2
```
Input: [456, 564, 645]
Output: 3

Explanation / 解释:
- 456 and 564: rotate 564 by 1 position → "564" → "456" ✓
- 456 and 645: rotate 645 by 2 positions → "645" → "456" ✓  
- 564 and 645: rotate 645 by 1 position → "645" → "564" ✓
- Valid pairs: (456, 564), (456, 645), (564, 645)
```

### Example 3 / 示例3
```
Input: [123, 231, 312, 456]
Output: 3

Explanation / 解释:
- 123, 231, 312 form a rotation group
- Pairs: (123, 231), (123, 312), (231, 312)
- 456 doesn't match with any other number
```

## Rotation Logic / 旋转逻辑

**String Rotation:** / 字符串旋转：
- "123" → rotate by 1 → "312"
- "123" → rotate by 2 → "231"
- "456" → rotate by 1 → "645"
- "456" → rotate by 2 → "564"

**Check Method:** / 检查方法：
- For each pair of numbers, check if one can be rotated to match the other
- Use string concatenation: if s2 is in s1+s1, then s2 is a rotation of s1

## Edge Cases / 边界情况

- Empty list → 0
- Single number → 0
- Numbers with leading zeros
- Same numbers at different indices
- Numbers of different lengths

## Algorithm Approach / 算法思路

1. Convert all numbers to strings / 将所有数字转换为字符串
2. For each pair of indices (i, j) where i < j / 对于每对索引 (i, j) 其中 i < j：
   - Check if str[j] is a rotation of str[i] / 检查 str[j] 是否是 str[i] 的旋转
   - Use the property: s2 is rotation of s1 if s2 in s1+s1 and len(s1)==len(s2)
3. Count valid pairs / 计算有效配对数

**Time Complexity:** O(n² × m) where n is list length, m is average string length
**Space Complexity:** O(m) for string operations