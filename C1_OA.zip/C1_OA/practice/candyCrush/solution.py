def candy_crush(board):
    """
    Crush candies until board becomes stable.
    
    Args:
        board: 2D list of integers representing candy types (0 = empty)
        
    Returns:
        2D list: Stable board after all eliminations and gravity
    """
    # TODO: Implement the solution
    pass