from solution import count_suffix_pairs

def test_suffix_pairs():
    """Comprehensive test cases for suffix pairs counting"""
    
    test_cases = [
        # Basic cases
        {
            "words": ["abc", "bc", "c"],
            "expected": 3,
            "desc": "Chain of suffixes: abc->bc->c"
        },
        
        {
            "words": ["hello", "lo", "world"],
            "expected": 1,
            "desc": "Single suffix pair: hello ends with lo"
        },
        
        # Equal strings
        {
            "words": ["test", "test", "test"],
            "expected": 3,
            "desc": "All equal strings: 3 pairs from 3 identical strings"
        },
        
        # No valid pairs
        {
            "words": ["abc", "def", "ghi"],
            "expected": 0,
            "desc": "No suffix relationships"
        },
        
        # Mixed cases
        {
            "words": ["programming", "ing", "gram", "ming"],
            "expected": 3,
            "desc": "Multiple suffix relationships: programming-ing, programming-ming, ing-ming"
        },
        
        # Single character suffixes
        {
            "words": ["a", "ba", "cba", "dcba"],
            "expected": 6,
            "desc": "Chain: a->ba->cba->dcba, all pairs valid"
        },
        
        # Empty and single element
        {
            "words": [],
            "expected": 0,
            "desc": "Empty array"
        },
        
        {
            "words": ["single"],
            "expected": 0,
            "desc": "Single element - no pairs possible"
        },
        
        # Complex case
        {
            "words": ["abcd", "cd", "bcd", "d", "xyz"],
            "expected": 6,
            "desc": "Multiple overlapping suffix relationships: 6 valid pairs"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = count_suffix_pairs(test["words"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Words: {test['words']}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        
        if status == "FAIL":
            # Show which pairs were found for debugging
            words = test["words"]
            pairs = []
            for j in range(len(words)):
                for k in range(j + 1, len(words)):
                    if words[j].endswith(words[k]) or words[k].endswith(words[j]):
                        pairs.append((j, k, f"{words[j]}-{words[k]}"))
            print(f"  Found pairs: {pairs}")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_suffix_pairs()