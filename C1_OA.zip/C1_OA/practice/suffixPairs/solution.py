def count_suffix_pairs(words):
    """
    Count pairs where one string is a suffix of another.
    
    Args:
        words: List of strings
        
    Returns:
        int: Number of valid pairs
    """
    # TODO: Implement your solution here
    pass