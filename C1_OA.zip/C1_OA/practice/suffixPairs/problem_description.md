# Suffix Pairs Problem / 后缀对问题

## Problem Statement / 问题描述

### English
Given an array of strings, find the number of pairs where one string is a suffix of another (or they are equal).

### 中文
给定一个字符串数组，找到一个字符串是另一个字符串的后缀（或它们相等）的对数。

## Definition / 定义

### English
A pair (i, j) is valid if:
- words[i] is a suffix of words[j], OR
- words[j] is a suffix of words[i]

Note: A string is considered a suffix of itself (equal strings count as valid pairs).

### 中文
一个对(i, j)是有效的，如果：
- words[i]是words[j]的后缀，或者
- words[j]是words[i]的后缀

注意：一个字符串被认为是它自己的后缀（相等的字符串算作有效对）。

## Requirements / 要求

### English
- Count all valid pairs (i, j) where i ≠ j
- A string ending with another string means one is a suffix of the other
- Equal strings are valid pairs

### 中文
- 统计所有有效对(i, j)，其中i ≠ j
- 一个字符串以另一个字符串结尾意味着一个是另一个的后缀
- 相等的字符串是有效对

## Examples / 示例
- words = ["abc", "bc", "c"] 
  - "bc" is suffix of "abc" → pair (0,1)
  - "c" is suffix of "abc" → pair (0,2) 
  - "c" is suffix of "bc" → pair (1,2)
  - Total: 3 pairs

- words = ["hello", "lo", "world"]
  - "lo" is suffix of "hello" → pair (0,1)
  - Total: 1 pair

## Output / 输出

### English
Return the total number of valid pairs.

### 中文
返回有效对的总数。