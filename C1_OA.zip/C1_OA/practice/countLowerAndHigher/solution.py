def count_case_diff(s):
    """
    Count uppercase and lowercase characters in a string and return their difference.
    
    Args:
        s (str): Input string
        
    Returns:
        int: (uppercase count) - (lowercase count)
    """
    lower, upper = 0, 0

    for c in s:
        if c.islower():
            lower += 1
        elif c.isupper():
            upper += 1
    
    return upper - lower