# Robot Laser Movement / 机器人激光移动

## Problem Statement / 问题描述

**English:**
Given a matrix, robot's location, and laser locations, find the longest distance the robot can travel in any single direction.
- Lasers cover their entire row and column
- Robot can move up, down, left, right until hitting matrix border or laser-covered area
- Return the maximum distance possible in any single direction

**中文:**
给定一个矩阵、机器人位置和激光位置，找出机器人在任意单一方向上能移动的最长距离。
- 激光覆盖其整行和整列
- 机器人可以向上、下、左、右移动，直到碰到矩阵边界或激光覆盖区域
- 返回任意单一方向上的最大可能距离

## Requirements / 要求

- Input: Matrix dimensions, robot position, laser positions / 输入：矩阵尺寸、机器人位置、激光位置
- Output: Maximum distance in any single direction / 输出：任意单一方向的最大距离
- Robot moves in straight lines only / 机器人只能直线移动
- Laser coverage blocks movement / 激光覆盖阻止移动

## Examples / 示例

### Example 1 / 示例1
```
Matrix: 5x8 (rows x cols)
Robot: [2, 3] (row 2, col 3)
Laser: [4, 7] (bottom-right area)

Laser Coverage / 激光覆盖:
- Row 4: entire row covered / 第4行：整行覆盖
- Col 7: entire column covered / 第7列：整列覆盖

Visual / 视觉效果:
  0 1 2 3 4 5 6 7
0 . . . . . . . L
1 . . . . . . . L  
2 . . . R . . . L  (R = Robot)
3 . . . . . . . L
4 L L L L L L L L  (L = Laser covered)

Movement Analysis / 移动分析:
- Up: can move 2 steps (to row 0) / 向上：可移动2步（到第0行）
- Down: can move 1 step (blocked by laser row 4) / 向下：可移动1步（被激光第4行阻挡）
- Left: can move 3 steps (to col 0) / 向左：可移动3步（到第0列）
- Right: can move 3 steps (blocked by laser col 7) / 向右：可移动3步（被激光第7列阻挡）

Maximum: 3 steps
```

### Example 2 / 示例2
```
Matrix: 4x4
Robot: [1, 1]
Laser: [2, 2]

Laser Coverage / 激光覆盖:
- Row 2: entire row covered
- Col 2: entire column covered

Visual / 视觉效果:
  0 1 2 3
0 . . L .
1 . R L .  (R = Robot)
2 L L L L
3 . . L .

Movement Analysis / 移动分析:
- Up: 1 step (to row 0)
- Down: 0 steps (blocked by laser row 2)
- Left: 1 step (to col 0)  
- Right: 0 steps (blocked by laser col 2)

Maximum: 1 step
```

## Laser Coverage Rules / 激光覆盖规则

- Each laser at position [r, c] covers / 每个激光在位置[r, c]覆盖：
  - Entire row r / 整行r
  - Entire column c / 整列c
- Multiple lasers can overlap coverage / 多个激光可以重叠覆盖
- Robot cannot enter laser-covered cells / 机器人不能进入激光覆盖的格子

## Edge Cases / 边界情况

- Robot at matrix border / 机器人在矩阵边界
- Robot in laser-covered area (invalid) / 机器人在激光覆盖区域（无效）
- No lasers / 没有激光
- Multiple lasers / 多个激光

## Algorithm Approach / 算法思路

1. Create laser coverage map / 创建激光覆盖图：
   - Mark all rows and columns covered by lasers / 标记所有被激光覆盖的行和列

2. For each direction from robot position / 对机器人位置的每个方向：
   - Count steps until hitting matrix border or laser coverage / 计算步数直到碰到矩阵边界或激光覆盖
   - Track maximum distance / 跟踪最大距离

3. Return maximum distance found / 返回找到的最大距离

**Time Complexity:** O(L + max(rows, cols)) where L is number of lasers
**Space Complexity:** O(rows + cols) for coverage tracking