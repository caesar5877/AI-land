def max_robot_distance(rows, cols, robot_pos, laser_positions):
    """
    Find the maximum distance a robot can travel in any single direction.
    
    Args:
        rows (int): Number of rows in matrix
        cols (int): Number of columns in matrix
        robot_pos (list): Robot position [row, col]
        laser_positions (list): List of laser positions [[row, col], ...]
        
    Returns:
        int: Maximum distance robot can travel in any direction
    """
    # TODO: Implement your solution here
    pass