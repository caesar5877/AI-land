from solution import max_robot_distance

def run_tests():
    test_cases = [
        {
            'input': (5, 8, [2, 3], [[4, 7]]),
            'expected': 3,
            'desc': 'Basic example with laser at bottom-right'
        },
        {
            'input': (4, 4, [1, 1], [[2, 2]]),
            'expected': 1,
            'desc': 'Small matrix with central laser'
        },
        {
            'input': (3, 3, [1, 1], []),
            'expected': 1,
            'desc': 'No lasers, robot in center'
        },
        {
            'input': (5, 5, [0, 0], [[2, 2]]),
            'expected': 1,
            'desc': 'Robot at top-left corner, blocked by laser coverage'
        },
        {
            'input': (5, 5, [4, 4], [[2, 2]]),
            'expected': 1,
            'desc': 'Robot at bottom-right corner, blocked by laser coverage'
        },
        {
            'input': (6, 6, [2, 2], [[1, 3], [4, 1]]),
            'expected': 1,
            'desc': 'Multiple lasers blocking movement'
        },
        {
            'input': (3, 3, [1, 1], [[0, 0], [1, 2], [2, 1]]),
            'expected': 0,
            'desc': 'Robot surrounded by laser coverage'
        },
        {
            'input': (1, 5, [0, 2], []),
            'expected': 2,
            'desc': 'Single row matrix'
        },
        {
            'input': (5, 1, [2, 0], []),
            'expected': 2,
            'desc': 'Single column matrix'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        rows, cols, robot_pos, laser_positions = test['input']
        result = max_robot_distance(rows, cols, robot_pos, laser_positions)
        status = "PASS" if result == test['expected'] else "FAIL"
        print(f"Test {i}: {status}")
        print(f"  Description: {test['desc']}")
        print(f"  Input: rows={rows}, cols={cols}, robot={robot_pos}, lasers={laser_positions}")
        print(f"  Expected: {test['expected']}, Got: {result}")
        
        if result == test['expected']:
            passed += 1
        print()
    
    print(f"Results: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    run_tests()