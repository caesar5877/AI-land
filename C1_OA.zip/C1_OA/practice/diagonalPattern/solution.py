def longest_diagonal_pattern(matrix):
    """
    Find the longest diagonal segment matching pattern: 1,2,0,2,0,...
    
    Args:
        matrix: 2D list of integers (0, 1, or 2)
        
    Returns:
        int: Length of longest matching diagonal segment
    """
    # TODO: Implement your solution here
    pass