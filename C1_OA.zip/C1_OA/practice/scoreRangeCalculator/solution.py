def calculate_score_range(initial_score, changes):
    """
    Calculate final score and return corresponding range string.
    
    Args:
        initial_score (int): Starting score
        changes (list): List of score modifications
        
    Returns:
        str: 'a' for ≤100, 'b' for 101-150, 'c' for 151-200, 'd' for >200
    """
    # TODO: Implement the solution
    pass