# Score Range Calculator / 分数范围计算器

## Problem Statement / 问题描述

**English:**
You're given an initial score and an integer array of score changes. First, calculate the final score after applying all changes. Then, based on the score range, return a corresponding string:
- 'a' if the score is ≤100
- 'b' for 101–150  
- 'c' for 151–200
- 'd' for >200

**中文:**
给定一个初始分数和一个整数数组表示分数变化。首先，应用所有变化后计算最终分数。然后，根据分数范围返回对应的字符串：
- 分数 ≤100 返回 'a'
- 101–150 返回 'b'
- 151–200 返回 'c'
- >200 返回 'd'

## Examples / 示例

### Example 1 / 示例1
```
Input: initial_score = 100, changes = [+100, -10]
Step 1: Calculate final score: 100 + 100 - 10 = 190
Step 2: 190 is in range 151-200, so return 'c'
Output: 'c'
```

### Example 2 / 示例2
```
Input: initial_score = 50, changes = [+20, +15]
Step 1: Calculate final score: 50 + 20 + 15 = 85
Step 2: 85 is ≤100, so return 'a'
Output: 'a'
```

### Example 3 / 示例3
```
Input: initial_score = 150, changes = [+100]
Step 1: Calculate final score: 150 + 100 = 250
Step 2: 250 is >200, so return 'd'
Output: 'd'
```

## Input Format / 输入格式
- `initial_score`: Integer representing the starting score
- `changes`: List of integers representing score modifications

## Output Format / 输出格式
- String: 'a', 'b', 'c', or 'd' based on final score range

## Constraints / 约束条件
- Initial score can be any integer
- Changes array can contain positive or negative integers
- Final score can be negative