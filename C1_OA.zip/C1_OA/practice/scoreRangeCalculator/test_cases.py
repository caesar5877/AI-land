from solution import calculate_score_range

def test_calculate_score_range():
    test_cases = [
        # Basic functionality
        {
            'input': (100, [100, -10]),
            'expected': 'c',
            'desc': 'Basic case: 100 + 100 - 10 = 190 (range c)'
        },
        {
            'input': (50, [20, 15]),
            'expected': 'a',
            'desc': 'Range a: 50 + 20 + 15 = 85 (≤100)'
        },
        {
            'input': (150, [100]),
            'expected': 'd',
            'desc': 'Range d: 150 + 100 = 250 (>200)'
        },
        
        # Edge cases
        {
            'input': (100, []),
            'expected': 'a',
            'desc': 'Empty changes: 100 (≤100)'
        },
        {
            'input': (101, [0]),
            'expected': 'b',
            'desc': 'Boundary case: 101 (range b)'
        },
        {
            'input': (150, [1]),
            'expected': 'c',
            'desc': 'Boundary case: 151 (range c)'
        },
        {
            'input': (200, [1]),
            'expected': 'd',
            'desc': 'Boundary case: 201 (range d)'
        },
        
        # Complex scenarios
        {
            'input': (200, [-50, 1]),
            'expected': 'c',
            'desc': 'Mixed changes: 200 - 50 + 1 = 151 (range c)'
        },
        {
            'input': (0, [-50]),
            'expected': 'a',
            'desc': 'Negative result: 0 - 50 = -50 (≤100)'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            result = calculate_score_range(*test['input'])
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}, Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_calculate_score_range()