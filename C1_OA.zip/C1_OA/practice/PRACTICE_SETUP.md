# Practice Setup Guide / 练习设置指南

## Disable Auto-Completion for Practice / 禁用练习时的自动补全

### Method 1: VS Code Workspace Settings (Automatic) / 方法1：VS Code工作区设置（自动）
The practice directory already has `.vscode/settings.json` configured to disable:
- Amazon Q auto-suggestions
- Inline completions  
- Quick suggestions
- Trigger character suggestions

### Method 2: Manual Toggle / 方法2：手动切换
**VS Code:**
- Command Palette (`Ctrl+Shift+P`) → "Amazon Q: Pause Auto-Suggestions"
- Or Settings → Search "Amazon Q" → Uncheck auto-suggestions

**JetBrains IDEs:**
- `Alt+C` / `Option+C` to toggle inline suggestions
- File → Settings → Tools → Amazon Q → Disable inline suggestions

### Method 3: Keyboard Shortcut / 方法3：键盘快捷键
- `Alt+C` or `Option+C` - Toggle Amazon Q inline completions
- `Ctrl+Space` - Manually trigger suggestions when needed

## Practice Mode Benefits / 练习模式优势
✅ No auto-completion interference  
✅ Pure problem-solving experience  
✅ Better learning retention  
✅ Real coding interview simulation  

## Re-enable When Done / 完成后重新启用
Simply toggle the settings back or use the keyboard shortcut to re-enable auto-completion.

Happy practicing! / 练习愉快！