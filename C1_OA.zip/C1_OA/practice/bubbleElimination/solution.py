def bubble_elimination(bubbles, clicks):
    """
    Process bubble elimination with diagonal propagation and gravity.
    
    Args:
        bubbles: 2D matrix of colors (positive integers) and empty spaces (0)
        clicks: List of click positions [[r, c], ...]
        
    Returns:
        Final matrix after all clicks and gravity
    """
    # TODO: Implement your solution here
    pass