def min_obstacles_to_remove(matrix):
    """
    Find minimum obstacles to remove so brick block can fall to bottom.
    
    Args:
        matrix: 2D list with '&' (brick), '_' (empty), '*' (obstacle)
        
    Returns:
        int: Minimum obstacles to remove
    """
    # TODO: Implement your solution here
    pass