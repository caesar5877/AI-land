# Square Pattern Generator / 方形图案生成器

## Problem Statement / 问题描述

**English:**
Given an integer n, return a square pattern of length n using asterisks (*) and spaces.
- For n > 2: Create a hollow square (border only)
- For n ≤ 2: Create a filled square
- Return as a list of strings

**中文:**
给定整数n，使用星号(*)和空格返回长度为n的方形图案。
- 当n > 2时：创建空心方形（仅边框）
- 当n ≤ 2时：创建实心方形
- 返回字符串列表

## Requirements / 要求

- Input: Integer n (side length) / 输入：整数n（边长）
- Output: List of strings representing the square / 输出：表示方形的字符串列表
- Each string represents one row / 每个字符串代表一行

## Examples / 示例

### Example 1 / 示例1
```
Input: n = 4
Output: ["****", "*  *", "*  *", "****"]

Visual / 视觉效果:
****
*  *
*  *
****
```

### Example 2 / 示例2
```
Input: n = 2
Output: ["**", "**"]

Visual / 视觉效果:
**
**
```

### Example 3 / 示例3
```
Input: n = 3
Output: ["***", "* *", "***"]

Visual / 视觉效果:
***
* *
***
```

### Example 4 / 示例4
```
Input: n = 1
Output: ["*"]

Visual / 视觉效果:
*
```

## Pattern Rules / 图案规则

**For n = 1:** Single asterisk / 单个星号
**For n = 2:** Filled 2x2 square / 填充的2x2方形
**For n ≥ 3:** Hollow square / 空心方形
- First and last rows: all asterisks / 第一行和最后一行：全是星号
- Middle rows: asterisk + spaces + asterisk / 中间行：星号 + 空格 + 星号

## Edge Cases / 边界情况

- n = 0: Empty list / 空列表
- n = 1: Single asterisk / 单个星号
- n = 2: Filled square / 实心方形
- Large n: Hollow square pattern / 大n值：空心方形图案

## Algorithm Approach / 算法思路

1. Handle edge cases (n ≤ 0) / 处理边界情况 (n ≤ 0)
2. For n = 1: Return single asterisk / n = 1时：返回单个星号
3. For n = 2: Return filled square / n = 2时：返回实心方形
4. For n ≥ 3: Create hollow square / n ≥ 3时：创建空心方形
   - First row: n asterisks / 第一行：n个星号
   - Middle rows: asterisk + (n-2) spaces + asterisk / 中间行：星号 + (n-2)个空格 + 星号
   - Last row: n asterisks / 最后一行：n个星号