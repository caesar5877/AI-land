def generate_square(n):
    """
    Generate a square pattern of length n using asterisks and spaces.
    
    Args:
        n (int): Side length of the square
        
    Returns:
        list[str]: List of strings representing the square pattern
    """
    # TODO: Implement your solution here
    pass