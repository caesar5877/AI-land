from solution import generate_square

def run_tests():
    test_cases = [
        {
            'input': 4,
            'expected': ["****", "*  *", "*  *", "****"],
            'desc': 'Basic hollow square n=4'
        },
        {
            'input': 2,
            'expected': ["**", "**"],
            'desc': 'Filled square n=2'
        },
        {
            'input': 1,
            'expected': ["*"],
            'desc': 'Single asterisk n=1'
        },
        {
            'input': 3,
            'expected': ["***", "* *", "***"],
            'desc': 'Small hollow square n=3'
        },
        {
            'input': 0,
            'expected': [],
            'desc': 'Edge case n=0'
        },
        {
            'input': 5,
            'expected': ["*****", "*   *", "*   *", "*   *", "*****"],
            'desc': 'Larger hollow square n=5'
        },
        {
            'input': -1,
            'expected': [],
            'desc': 'Negative input'
        },
        {
            'input': 6,
            'expected': ["******", "*    *", "*    *", "*    *", "*    *", "******"],
            'desc': 'Even larger hollow square n=6'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = generate_square(test['input'])
        status = "PASS" if result == test['expected'] else "FAIL"
        print(f"Test {i}: {status}")
        print(f"  Description: {test['desc']}")
        print(f"  Input: {test['input']}")
        print(f"  Expected: {test['expected']}")
        print(f"  Got: {result}")
        
        if result == test['expected']:
            passed += 1
        print()
    
    print(f"Results: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    run_tests()