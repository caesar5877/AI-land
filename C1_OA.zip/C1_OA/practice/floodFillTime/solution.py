def flood_fill_time(terrain, start):
    """
    Calculate time when each cell gets flooded starting from given position.
    
    Args:
        terrain: 2D matrix representing terrain
        start: Tuple (row, col) of starting flood position
        
    Returns:
        2D matrix showing time when each position gets wet
    """
    # TODO: Implement the solution
    pass