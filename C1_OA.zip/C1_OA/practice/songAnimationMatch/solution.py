def solution(songs, animations):
    """
    Match animations to songs based on divisor relationship.
    
    Args:
        songs: List of strings in format "name:length"
        animations: List of strings in format "name:length"
        
    Returns:
        List of strings in format "name:times" for matched animations
    """
    # TODO: Implement the solution
    pass