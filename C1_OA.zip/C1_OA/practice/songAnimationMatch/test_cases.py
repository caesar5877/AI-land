from solution import solution

def test_solution():
    test_cases = [
        # Basic functionality
        {
            'input': (["notion:180", "voyage:185", "sample:180"], ["circles:360", "squares:180", "lines:37"]),
            'expected': ["squares:1", "lines:5", "squares:1"],
            'desc': 'Example case: mixed divisor relationships'
        },
        {
            'input': (["song1:60", "song2:120"], ["anim1:30", "anim2:60"]),
            'expected': ["anim1:2", "anim1:4"],
            'desc': 'First animation fits both songs'
        },
        {
            'input': (["track:100"], ["short:25", "long:50"]),
            'expected': ["short:4"],
            'desc': 'Multiple animations fit, choose first'
        },
        
        # Edge cases
        {
            'input': (["single:1"], ["unit:1"]),
            'expected': ["unit:1"],
            'desc': 'Minimum length case'
        },
        {
            'input': (["long:1000"], ["div:1"]),
            'expected': ["div:1000"],
            'desc': 'Large multiplier case'
        },
        {
            'input': (["exact:50"], ["match:50"]),
            'expected': ["match:1"],
            'desc': 'Exact length match'
        },
        
        # Complex scenarios
        {
            'input': (["a:12", "b:18", "c:24"], ["x:6", "y:9", "z:4"]),
            'expected': ["x:2", "x:3", "x:4"],
            'desc': 'First animation matches all songs'
        },
        {
            'input': (["test:36"], ["bad:7", "good:6", "better:4"]),
            'expected': ["good:6"],
            'desc': 'Skip non-divisors, find first valid'
        },
        {
            'input': (["prime:17"], ["one:1", "seventeen:17"]),
            'expected': ["one:17"],
            'desc': 'Prime number song length'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            songs, animations = test['input']
            result = solution(songs, animations)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_solution()