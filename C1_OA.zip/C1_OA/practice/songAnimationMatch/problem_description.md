# Song Animation Match / 歌曲动画匹配

## Problem Statement / 问题描述

**English:**
You are given an array of songs, where each song is represented as a string in the format: `<songName>:<songLength>`. You are also given an array of animations, where each animation is represented in the format: `<animationName>:<animationLength>`.

Your task is to select an appropriate animation for each song. An animation can only be matched to a song if its length is an integer divisor of the song's length. If multiple animations can fit a song, select the one with the lowest index within the animations array.

Return an array of animations for songs, ordered in the same way as the corresponding songs. Each element must be a string in the format: `<animationName>:<timesToBePlayed>`, where timesToBePlayed is the number of times the animation must be played to match the song's length.

**中文:**
给定一个歌曲数组，每首歌曲表示为字符串格式：`<歌曲名>:<歌曲长度>`。还给定一个动画数组，每个动画表示为格式：`<动画名>:<动画长度>`。

您的任务是为每首歌曲选择合适的动画。只有当动画长度是歌曲长度的整数除数时，动画才能与歌曲匹配。如果多个动画适合一首歌曲，选择动画数组中索引最低的那个。

返回歌曲的动画数组，按相应歌曲的相同顺序排列。每个元素必须是格式为：`<动画名>:<播放次数>`的字符串，其中播放次数是动画必须播放以匹配歌曲长度的次数。

## Examples / 示例

### Example 1 / 示例1
```
Input:
songs = ["notion:180", "voyage:185", "sample:180"]
animations = ["circles:360", "squares:180", "lines:37"]

Output:
["squares:1", "lines:5", "squares:1"]

Explanation:
- "notion:180" → "squares:180" (180 ÷ 180 = 1 time)
- "voyage:185" → "lines:37" (185 ÷ 37 = 5 times)  
- "sample:180" → "squares:180" (180 ÷ 180 = 1 time)
```

## Input Format / 输入格式
- `songs`: Array of strings in format `"<songName>:<songLength>"`
- `animations`: Array of strings in format `"<animationName>:<animationLength>"`

## Output Format / 输出格式
- Array of strings in format `"<animationName>:<timesToBePlayed>"`

## Constraints / 约束条件
- 1 ≤ songs.length ≤ 1000
- 1 ≤ animations.length ≤ 1000
- Song and animation lengths are positive integers
- It is guaranteed that an appropriate animation exists for all songs
- Time complexity should not exceed O(songs.length × animations.length)