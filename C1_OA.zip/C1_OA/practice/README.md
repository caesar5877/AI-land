# Practice Playground / 练习场

Welcome to your coding practice playground! Here you can implement solutions and test them against comprehensive test cases.

欢迎来到编程练习场！在这里你可以实现解决方案并通过综合测试用例进行验证。

## How to Practice / 如何练习

### Step 1: Choose a Problem / 选择问题
Navigate to any problem directory:
```bash
cd practice/[problem_name]/
```

### Step 2: Read the Problem / 阅读问题
```bash
# View problem description
cat problem_description.md
```

### Step 3: Implement Solution / 实现解决方案
Edit `solution.py` and replace the `pass` statement with your implementation.

编辑 `solution.py` 文件，用你的实现替换 `pass` 语句。

### Step 4: Test Your Solution / 测试解决方案
```bash
python test_cases.py
```

## Available Problems / 可用问题

| Problem | Difficulty | Topics |
|---------|------------|---------|
| [balanceSubsequence](./balanceSubsequence/) | Medium | Array, Math |
| [binarySearchObstacles](./binarySearchObstacles/) | Medium | Binary Search, Data Structures |
| [branchFileTracker](./branchFileTracker/) | Easy | Hash Table, String Processing |
| [bubbleElimination](./bubbleElimination/) | Hard | Matrix, DFS, Simulation |
| [candyCrush](./candyCrush/) | Medium | Matrix, Simulation, Game Logic |
| [cardGame](./cardGame/) | Medium | Simulation, Queue |
| [commandHistoryCount](./commandHistoryCount/) | Medium | String Processing, Recursion |
| [countLowerAndHigher](./countLowerAndHigher/) | Easy | String Processing |
| [countSevensAndDivisible](./countSevensAndDivisible/) | Easy | String Processing, Math |
| [diagonalPattern](./diagonalPattern/) | Medium | Matrix, Pattern Matching |
| [fallingBricks](./fallingBricks/) | Hard | Matrix, Physics Simulation |
| [floodFillTime](./floodFillTime/) | Medium | BFS, Matrix, Simulation |
| [footballRanking](./footballRanking/) | Medium | Sorting, Data Processing |
| [largestSquare](./largestSquare/) | Medium | Array, Dynamic Programming |
| [localPeaks](./localPeaks/) | Easy | Array, Math |
| [pathFinding](./pathFinding/) | Medium | Graph, DFS, Hamiltonian Path |
| [robotLaserMovement](./robotLaserMovement/) | Medium | Matrix, Simulation |
| [robotLaserMovement](./robotLaserMovement/) | Medium | Matrix, Simulation |
| [rotationPairs](./rotationPairs/) | Medium | String Processing, Combinatorics |
| [scoreRangeCalculator](./scoreRangeCalculator/) | Easy | Math, Conditional Logic |
| [songAnimationMatch](./songAnimationMatch/) | Easy | String Processing, Math |
| [squarePattern](./squarePattern/) | Easy | String Processing, Pattern Generation |
| [suffixPairs](./suffixPairs/) | Easy | String Processing, Hash Table |

## Practice Tips / 练习建议

### For Beginners / 初学者
Start with Easy problems:
- [countLowerAndHigher](./countLowerAndHigher/)
- [countSevensAndDivisible](./countSevensAndDivisible/)
- [localPeaks](./localPeaks/)
- [scoreRangeCalculator](./scoreRangeCalculator/)
- [songAnimationMatch](./songAnimationMatch/)
- [squarePattern](./squarePattern/)
- [suffixPairs](./suffixPairs/)

### For Intermediate / 中级
Try Medium problems:
- [balanceSubsequence](./balanceSubsequence/)
- [binarySearchObstacles](./binarySearchObstacles/)
- [candyCrush](./candyCrush/)
- [commandHistoryCount](./commandHistoryCount/)
- [floodFillTime](./floodFillTime/)
- [footballRanking](./footballRanking/)
- [rotationPairs](./rotationPairs/)

### For Advanced / 高级
Challenge yourself with Hard problems:
- [bubbleElimination](./bubbleElimination/)
- [fallingBricks](./fallingBricks/)

## Example Workflow / 示例工作流程

```bash
# 1. Choose a problem
cd practice/squarePattern/

# 2. Read the problem
cat problem_description.md

# 3. Edit solution
# Open solution.py in your editor and implement the function

# 4. Test your solution
python test_cases.py

# 5. Debug if needed
# Check failed test cases and fix your implementation

# 6. Celebrate when all tests pass! 🎉
```

## Test Case Format / 测试用例格式

Each test case includes:
- **input**: The input parameters / 输入参数
- **expected**: Expected output / 期望输出  
- **desc**: Description of the test case / 测试用例描述

## Getting Help / 获取帮助

If you're stuck:
1. Read the problem description carefully / 仔细阅读问题描述
2. Look at the test cases for examples / 查看测试用例中的示例
3. Start with simple cases first / 先从简单情况开始
4. Check the original solutions in the parent directories / 查看父目录中的原始解决方案

Happy coding! / 编程愉快！