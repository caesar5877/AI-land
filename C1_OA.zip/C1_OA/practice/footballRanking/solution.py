def get_champion_and_runner_up(wins, draws, goals_for, goals_against):
    """
    Determine champion and runner-up teams based on points and goal difference.
    
    Args:
        wins: List of win counts for each team
        draws: List of draw counts for each team
        goals_for: List of goals scored by each team
        goals_against: List of goals conceded by each team
        
    Returns:
        tuple: (champion_index, runner_up_index)
    """
    N = len(wins)
    rank = []
    for i in range(N):
        point = wins[i] * 3 + draws[i]
        net_goal = goals_for[i] - goals_against[i]
        rank.append((point, net_goal, i))
        
    rank = sorted(rank, key= lambda x: (x[0], x[1]), reverse = True)
    # rank = sorted(rank, reverse = True)
    return tuple([team[2] for team in rank[:2]])