def count_sevens_and_divisible(nums):
    """
    Count integers that contain at least two '7' digits and are divisible by 3.
    
    Args:
        nums (list[int]): List of integers to check
        
    Returns:
        int: Count of integers satisfying both conditions
    """
    # TODO: Implement your solution here
    pass