# Coding Problems Collection / 编程问题集合

This repository contains a collection of coding problems with complete solutions, test cases, and bilingual documentation.

本仓库包含一系列编程问题的完整解决方案、测试用例和双语文档。

## Table of Contents / 目录

| Problem | English Title | 中文标题 | Difficulty | Topics |
|---------|---------------|----------|------------|---------|
| [arrayOperations](./arrayOperations/) | Array Operations | 数组操作 | Medium | Array, Hash Table |
| [balanceSubsequence](./balanceSubsequence/) | Balance Subsequence | 平衡子序列 | Medium | Array, Math |
| [binarySearchObstacles](./binarySearchObstacles/) | Binary Search Obstacles | 二分搜索障碍物 | Medium | Binary Search, Data Structures |
| [binaryStringOps](./binaryStringOps/) | Binary String Operations | 二进制字符串操作 | Easy | String Processing |
| [branchFileTracker](./branchFileTracker/) | Branch File Tracker | 分支文件跟踪 | Easy | Hash Table, String Processing |
| [bubbleElimination](./bubbleElimination/) | Bubble Elimination Game | 气泡点击消除游戏 | Hard | Matrix, DFS, Simulation |
| [candyCrush](./candyCrush/) | Candy Crush | 糖果粉碎 | Medium | Matrix, Simulation, Game Logic |
| [cardGame](./cardGame/) | Card Game Simulation | 卡牌对战游戏 | Medium | Simulation, Queue |
| [commandHistoryCount](./commandHistoryCount/) | Command History Count | 命令历史计数 | Medium | String Processing, Recursion |
| [countLowerAndHigher](./countLowerAndHigher/) | Count Case Difference | 大小写字符差值 | Easy | String Processing |
| [countSevensAndDivisible](./countSevensAndDivisible/) | Count Sevens and Divisible | 计算包含七且可被三整除的数字 | Easy | String Processing, Math |
| [diagonalPattern](./diagonalPattern/) | Diagonal Pattern Matching | 对角线模式匹配 | Medium | Matrix, Pattern Matching |
| [digitalRootFreq](./digitalRootFreq/) | Digital Root Frequency | 数字根频率 | Easy | Math, Hash Table |
| [evenOddIndexDiff](./evenOddIndexDiff/) | Even Odd Index Difference | 奇偶索引差值 | Easy | Array, Math |
| [fallingBricks](./fallingBricks/) | Falling Bricks | 下落砖块 | Hard | Matrix, Physics Simulation |
| [floodFillTime](./floodFillTime/) | Flood Fill Time | 洪水填充时间 | Medium | BFS, Matrix, Simulation |
| [footballRanking](./footballRanking/) | Football League Ranking | 足球联赛排名 | Medium | Sorting, Data Processing |
| [largestSquare](./largestSquare/) | Largest Square in Heights | 高度中最大正方形 | Medium | Array, Dynamic Programming |
| [localPeaks](./localPeaks/) | Local Peaks Sum | 局部峰值和 | Easy | Array, Math |
| [matrixNeighborAvg](./matrixNeighborAvg/) | Matrix Neighbor Average | 矩阵邻居平均值 | Medium | Matrix, Math |
| [pathFinding](./pathFinding/) | Path Finding | 路径查找 | Medium | Graph, DFS, Hamiltonian Path |
| [patternMatching](./patternMatching/) | Pattern Matching | 模式匹配 | Medium | Array, Pattern Matching |
| [robotLaserMovement](./robotLaserMovement/) | Robot Laser Movement | 机器人激光移动 | Medium | Matrix, Simulation |
| [rotationPairs](./rotationPairs/) | Rotation Pairs | 旋转配对 | Medium | String Processing, Combinatorics |
| [scoreRangeCalculator](./scoreRangeCalculator/) | Score Range Calculator | 分数范围计算器 | Easy | Math, Conditional Logic |
| [songAnimationMatch](./songAnimationMatch/) | Song Animation Match | 歌曲动画匹配 | Easy | String Processing, Math |
| [stringMerge](./stringMerge/) | String Merge | 字符串合并 | Easy | String Processing |
| [squarePattern](./squarePattern/) | Square Pattern Generator | 方形图案生成器 | Easy | String Processing, Pattern Generation |
| [suffixPairs](./suffixPairs/) | Suffix Pairs | 后缀对 | Easy | String Processing, Hash Table |

## Problem Structure / 问题结构

Each problem directory contains / 每个问题目录包含：

- `problem_description.md` - Bilingual problem statement / 双语问题描述
- `solution.py` - Minimal, efficient solution / 最小化高效解决方案
- `test_cases.py` - Comprehensive test suite / 综合测试套件

## Practice Directory / 练习目录

The `practice/` directory contains template versions of all problems for hands-on coding practice:

`practice/`目录包含所有问题的模板版本，用于动手编程练习：

- **Template Solutions** - Function signatures with TODO comments / 带TODO注释的函数签名
- **Same Test Cases** - Identical test suites for validation / 相同的测试套件用于验证
- **Same Documentation** - Complete problem descriptions / 完整的问题描述
- **Difficulty Recommendations** - Organized by skill level / 按技能水平组织

```bash
# Practice a specific problem
cd practice/[problemName]
# Implement your solution in solution.py
# Run tests to verify
python test_cases.py
```

## Quick Start / 快速开始

```bash
# Navigate to any problem directory
cd [problemName]

# Run the solution with test cases
python test_cases.py

# View the problem description
cat problem_description.md
```
