def generate_square(n):
    """
    Generate a square pattern of length n using asterisks and spaces.
    
    Args:
        n (int): Side length of the square
        
    Returns:
        list[str]: List of strings representing the square pattern
    """
    # Handle edge cases for invalid or small sizes
    if n <= 0:
        return []  # No square for non-positive size
    if n == 1:
        return ["*"]  # Single asterisk for 1x1 square
    if n == 2:
        return ["**", "**"]  # Filled 2x2 square
    
    # Build square pattern for n >= 3
    result = []
    
    # Top border: full row of asterisks
    result.append("*" * n)
    
    # Middle rows: asterisks on sides, spaces in between
    for _ in range(n - 2):  # n-2 middle rows
        # Left asterisk + (n-2) spaces + right asterisk
        result.append("*" + " " * (n - 2) + "*")
    
    # Bottom border: full row of asterisks
    result.append("*" * n)
    
    # Return list of strings representing square pattern
    return result