# Matrix Neighbor Average / 矩阵邻居平均值

## Problem Statement / 问题描述

**English:**
Given a matrix and a radius, for each cell [i,j], calculate the average of all neighbors within the radius range, then calculate the average of this neighbor average and the original cell value, and place this new average at position (i,j). Return the new matrix.

**中文:**
给定一个矩阵和一个半径，对于每一个[i,j]，在半径范围内所有邻居相加取平均数，最后再算这个平均数和[i,j]的平均数，并且把这个新的平均数放在(i,j)这个位置上。返回新的矩阵。

## Examples / 示例

### Example 1 / 示例1
```
Input: 
matrix = [[1, 2, 3],
          [4, 5, 6], 
          [7, 8, 9]]
radius = 1

Output: 
[[3.0, 3.5, 4.0],
 [4.5, 5.0, 5.5],
 [6.0, 6.5, 7.0]]

Explanation:
For [1,1] (value=5): neighbors within radius 1 are all 8 cells
Neighbor avg = (1+2+3+4+6+7+8+9)/8 = 5.0
Final avg = (5.0 + 5)/2 = 5.0
```

### Example 2 / 示例2
```
Input:
matrix = [[1, 2],
          [3, 4]]
radius = 1

Output:
[[2.0, 2.5],
 [2.5, 3.0]]

Explanation:
For [0,0] (value=1): neighbors are [2,3,4]
Neighbor avg = (2+3+4)/3 = 3.0
Final avg = (3.0 + 1)/2 = 2.0
```

## Input Format / 输入格式
- `matrix`: 2D array of numbers
- `radius`: Integer radius for neighbor selection

## Output Format / 输出格式
- 2D array of floats: New matrix with averaged values

## Constraints / 约束条件
- 1 ≤ matrix dimensions ≤ 100
- 1 ≤ radius ≤ 10
- Matrix contains positive numbers