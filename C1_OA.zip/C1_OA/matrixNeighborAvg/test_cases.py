from solution import matrix_neighbor_average

def test_matrix_neighbor_average():
    test_cases = [
        # Basic functionality
        {
            'input': ([[1, 2, 3], [4, 5, 6], [7, 8, 9]], 1),
            'expected': [[2.333333333333333, 2.9, 3.6666666666666665], [4.3, 5.0, 5.7], [6.333333333333334, 7.1, 7.666666666666666]],
            'desc': '3x3 matrix with radius 1'
        },
        {
            'input': ([[1, 2], [3, 4]], 1),
            'expected': [[2.0, 2.333333333333333], [2.666666666666667, 3.0]],
            'desc': '2x2 matrix with radius 1'
        },
        {
            'input': ([[5]], 1),
            'expected': [[5.0]],
            'desc': 'Single cell matrix'
        },
        
        # Edge cases
        {
            'input': ([[1, 2]], 1),
            'expected': [[1.5, 1.5]],
            'desc': 'Single row matrix'
        },
        {
            'input': ([[1], [2]], 1),
            'expected': [[1.5], [1.5]],
            'desc': 'Single column matrix'
        },
        {
            'input': ([[1, 2, 3]], 2),
            'expected': [[1.75, 2.0, 2.25]],
            'desc': 'Radius larger than matrix dimension'
        },
        
        # Complex scenarios
        {
            'input': ([[1, 1, 1], [1, 1, 1], [1, 1, 1]], 1),
            'expected': [[1.0, 1.0, 1.0], [1.0, 1.0, 1.0], [1.0, 1.0, 1.0]],
            'desc': 'All same values'
        },
        {
            'input': ([[0, 1, 0], [1, 0, 1], [0, 1, 0]], 1),
            'expected': [[0.3333333333333333, 0.7, 0.3333333333333333], [0.7, 0.25, 0.7], [0.3333333333333333, 0.7, 0.3333333333333333]],
            'desc': 'Checkerboard pattern'
        },
        {
            'input': ([[10, 20], [30, 40]], 2),
            'expected': [[20.0, 23.333333333333336], [26.666666666666664, 30.0]],
            'desc': 'Large radius covers all neighbors'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    def arrays_equal(a, b, tolerance=1e-9):
        if len(a) != len(b):
            return False
        for i in range(len(a)):
            if len(a[i]) != len(b[i]):
                return False
            for j in range(len(a[i])):
                if abs(a[i][j] - b[i][j]) > tolerance:
                    return False
        return True
    
    for i, test in enumerate(test_cases, 1):
        try:
            matrix, radius = test['input']
            result = matrix_neighbor_average(matrix, radius)
            
            if arrays_equal(result, test['expected']):
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_matrix_neighbor_average()