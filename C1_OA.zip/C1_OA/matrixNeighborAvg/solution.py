def matrix_neighbor_average(matrix, radius):
    """
    Calculate new matrix with neighbor-averaged values.
    
    Args:
        matrix: 2D array of numbers
        radius: Integer radius for neighbor selection
        
    Returns:
        List[List[float]]: New matrix with averaged values
    """
    rows, cols = len(matrix), len(matrix[0])
    result = [[0.0] * cols for _ in range(rows)]
    
    for i in range(rows):
        for j in range(cols):
            # Collect neighbors within radius
            neighbors = []
            
            for di in range(-radius, radius + 1):
                for dj in range(-radius, radius + 1):
                    ni, nj = i + di, j + dj
                    
                    # Skip the cell itself and check bounds
                    if (di == 0 and dj == 0) or ni < 0 or ni >= rows or nj < 0 or nj >= cols:
                        continue
                    
                    neighbors.append(matrix[ni][nj])
            
            # Calculate neighbor average
            if neighbors:
                neighbor_avg = sum(neighbors) / len(neighbors)
            else:
                neighbor_avg = matrix[i][j]  # No neighbors, use self
            
            # Calculate final average: (neighbor_avg + original_value) / 2
            result[i][j] = (neighbor_avg + matrix[i][j]) / 2
    
    return result