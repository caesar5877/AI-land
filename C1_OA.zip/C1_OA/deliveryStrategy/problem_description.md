# Delivery Strategy / 配送策略

## Problem Statement / 问题描述

**English:**
Design a delivery strategy using drones and walking. Given charging stations at specific positions and a drone with limited range, find the minimum walking distance to deliver a package to a target position.

**中文:**
设计一个使用无人机和步行的配送策略。给定特定位置的充电站和有限航程的无人机，找到将包裹送到目标位置的最小步行距离。

## Rules / 规则

**English:**
- Start at position 0
- Drone max travel distance without charging is 10 units
- Can use drone from any charging station
- Must walk to charging stations to deploy drone
- Drone can fly to next charging station or target (within range)
- Calculate total walking distance needed

**中文:**
- 从位置0开始
- 无人机不充电最大飞行距离为10单位
- 可以从任何充电站使用无人机
- 必须步行到充电站部署无人机
- 无人机可以飞到下一个充电站或目标（在航程内）
- 计算所需的总步行距离

## Examples / 示例

### Example 1 / 示例1
```
Input: stations = [3, 5, 7, 15], target = 20, drone_range = 10
Output: 6
Explanation: 
- Walk 3 units to station at position 3
- Drone flies 3→7 (4 units), then 7→17 (10 units, max range)
- Walk 3 units from 17 to target at 20
- Total walking: 3 + 3 = 6
```

### Example 2 / 示例2
```
Input: stations = [5, 10], target = 15, drone_range = 10
Output: 10
Explanation:
- Walk 5 units to station at position 5
- Drone flies 5→15 (10 units, exactly max range)
- Total walking: 5
```

## Input Format / 输入格式
- `stations`: List of charging station positions (sorted)
- `target`: Target delivery position
- `drone_range`: Maximum drone travel distance without charging

## Output Format / 输出格式
- Integer: Minimum total walking distance

## Constraints / 约束条件
- 1 ≤ stations.length ≤ 100
- 0 < stations[i] < target ≤ 1000
- 1 ≤ drone_range ≤ 100
- Stations are sorted in ascending order