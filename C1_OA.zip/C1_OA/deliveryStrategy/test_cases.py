from solution import min_walking_distance

def test_min_walking_distance():
    test_cases = [
        # Basic functionality
        {
            'input': ([3, 5, 7, 15], 20, 10),
            'expected': 6,
            'desc': 'Example from problem: walk to 3, drone 3→7→17, walk 17→20'
        },
        {
            'input': ([5, 10], 15, 10),
            'expected': 5,
            'desc': 'Direct drone delivery from station 5 to target 15'
        },
        {
            'input': ([2, 4, 6], 8, 5),
            'expected': 2,
            'desc': 'Walk to station 2, drone flies 2→7, walk 7→8'
        },
        
        # Edge cases
        {
            'input': ([5], 10, 10),
            'expected': 5,
            'desc': 'Single station, drone can reach target directly'
        },
        {
            'input': ([20], 15, 10),
            'expected': 15,
            'desc': 'Station beyond target, walk directly'
        },
        {
            'input': ([2, 4], 20, 3),
            'expected': 20,
            'desc': 'Drone range too small, walk entire distance'
        },
        
        # Complex scenarios
        {
            'input': ([1, 3, 5, 7, 9], 12, 4),
            'expected': 3,
            'desc': 'Multiple hops: walk to 1, drone 1→5, walk to 5, drone 5→9, walk 9→12'
        },
        {
            'input': ([10, 20, 30], 35, 15),
            'expected': 10,
            'desc': 'Walk to 10, drone 10→25, walk 25→35'
        },
        {
            'input': ([5, 15, 25], 30, 20),
            'expected': 5,
            'desc': 'Walk to 5, drone can reach 25, walk 25→30'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            stations, target, drone_range = test['input']
            result = min_walking_distance(stations, target, drone_range)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_min_walking_distance()