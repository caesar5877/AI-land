def min_walking_distance(stations, target, drone_range):
    """
    Find minimum walking distance for drone delivery strategy.
    
    Args:
        stations: List of charging station positions (sorted)
        target: Target delivery position
        drone_range: Maximum drone travel distance without charging
        
    Returns:
        int: Minimum total walking distance
    """
    current_pos = 0
    total_walk = 0
    
    while current_pos < target:
        # Find the best station to walk to that maximizes our reach
        best_station = None
        max_reach = current_pos
        
        for station in stations:
            if station <= current_pos:
                continue
            if station > target:
                break
                
            # Calculate how far we can reach from this station
            reach_from_station = min(station + drone_range, target)
            
            # If this station gives us better reach, consider it
            if reach_from_station > max_reach:
                best_station = station
                max_reach = reach_from_station
        
        if best_station is None or max_reach <= current_pos:
            # No beneficial station found, walk remaining distance
            total_walk += target - current_pos
            break
        
        # Walk to the best station
        total_walk += best_station - current_pos
        
        # Update position to where drone can reach
        current_pos = max_reach
        
        # If drone reached target, we're done
        if current_pos >= target:
            break
        
        # If drone didn't reach target, we need to walk from drone's end position
        # Find where drone actually landed (farthest station within range or target)
        drone_end = best_station
        for station in stations:
            if station > best_station and station <= best_station + drone_range:
                drone_end = station
        
        # If drone couldn't reach any station, it goes as far as possible
        if drone_end == best_station:
            drone_end = min(best_station + drone_range, target)
        
        current_pos = drone_end
    
    return total_walk