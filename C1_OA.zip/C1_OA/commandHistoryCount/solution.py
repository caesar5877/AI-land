def count_commands(commands):
    """
    Count occurrences of mv, ls, cp commands after expanding history references.
    
    Args:
        commands (list[str]): List of command strings with possible history references
        
    Returns:
        dict: Dictionary with counts of mv, ls, cp commands
    """
    def resolve(item, visited):
        # Check for circular reference to prevent infinite recursion
        if item in visited:
            return None  # Circular reference detected
            
        # If not a history reference, return as-is
        if not item.startswith('!'):
            return item
            
        try:
            # Extract index from history reference (e.g., "!3" -> index 2)
            idx = int(item[1:]) - 1  # Convert to 0-based index
            
            # Validate index is within bounds
            if 0 <= idx < len(commands):
                # Mark current item as visited to detect cycles
                visited.add(item)
                # Recursively resolve the referenced command
                result = resolve(commands[idx], visited)
                # Remove from visited set after resolution
                visited.remove(item)
                return result
        except ValueError:
            # Invalid number format in history reference
            pass
            
        # Return None for invalid references
        return None
    
    # Initialize counters for target commands
    counts = {"mv": 0, "ls": 0, "cp": 0}
    
    # Process each command in the list
    for cmd in commands:
        # Resolve history references to get actual command
        resolved = resolve(cmd, set())
        # If resolved command is one we're tracking, increment counter
        if resolved in counts:
            counts[resolved] += 1
            
    # Return final counts
    return counts