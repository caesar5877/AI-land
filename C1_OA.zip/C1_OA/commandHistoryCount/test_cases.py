from solution import count_commands

def run_tests():
    test_cases = [
        {
            'input': ["mv", "ls", "cp", "!1", "!1", "!4", "cp"],
            'expected': {"mv": 4, "ls": 1, "cp": 2},
            'desc': 'Basic example with nested history references'
        },
        {
            'input': ["ls", "!1", "cp", "!2"],
            'expected': {"mv": 0, "ls": 3, "cp": 1},
            'desc': 'Simple history references'
        },
        {
            'input': [],
            'expected': {"mv": 0, "ls": 0, "cp": 0},
            'desc': 'Empty list'
        },
        {
            'input': ["mv", "ls", "cp"],
            'expected': {"mv": 1, "ls": 1, "cp": 1},
            'desc': 'No history references'
        },
        {
            'input': ["!1", "!1", "!1"],
            'expected': {"mv": 0, "ls": 0, "cp": 0},
            'desc': 'Circular reference to self'
        },
        {
            'input': ["mv", "!5", "ls"],
            'expected': {"mv": 1, "ls": 1, "cp": 0},
            'desc': 'Invalid history reference (out of bounds)'
        },
        {
            'input': ["grep", "awk", "sed", "!1"],
            'expected': {"mv": 0, "ls": 0, "cp": 0},
            'desc': 'Commands other than mv, ls, cp'
        },
        {
            'input': ["cp", "!1", "!2", "mv", "!4"],
            'expected': {"mv": 2, "ls": 0, "cp": 3},
            'desc': 'Mixed commands with history references'
        },
        {
            'input': ["!2", "!1"],
            'expected': {"mv": 0, "ls": 0, "cp": 0},
            'desc': 'Circular reference between items'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = count_commands(test['input'])
        status = "PASS" if result == test['expected'] else "FAIL"
        print(f"Test {i}: {status}")
        print(f"  Description: {test['desc']}")
        print(f"  Input: {test['input']}")
        print(f"  Expected: {test['expected']}")
        print(f"  Got: {result}")
        
        if result == test['expected']:
            passed += 1
        print()
    
    print(f"Results: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    run_tests()