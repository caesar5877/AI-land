# Command History Count / 命令历史计数

## Problem Statement / 问题描述

**English:**
Given a list of command items, count the occurrences of specific commands (mv, ls, cp) after expanding history references.
- Items starting with "!" are history references that get replaced
- "!n" refers to the nth item in the list (1-indexed)
- History references can be nested (e.g., !4 → !1 → mv)
- Count final occurrences of mv, ls, and cp commands

**中文:**
给定一个命令项列表，在展开历史引用后计算特定命令（mv、ls、cp）的出现次数。
- 以"!"开头的项是历史引用，需要被替换
- "!n"指向列表中第n个项（从1开始索引）
- 历史引用可以嵌套（例如：!4 → !1 → mv）
- 计算mv、ls、cp命令的最终出现次数

## Requirements / 要求

- Input: List of command strings / 输入：命令字符串列表
- Output: Dictionary with counts of mv, ls, cp / 输出：包含mv、ls、cp计数的字典
- Handle nested history references / 处理嵌套历史引用
- 1-indexed history references / 历史引用从1开始索引

## Examples / 示例

### Example 1 / 示例1
```
Input: ["mv", "ls", "cp", "!1", "!1", "!4", "cp"]
Output: {"mv": 4, "ls": 1, "cp": 2}

Step-by-step expansion / 逐步展开:
1. "mv" → mv (count: mv=1)
2. "ls" → ls (count: ls=1) 
3. "cp" → cp (count: cp=1)
4. "!1" → "mv" (refers to 1st item) (count: mv=2)
5. "!1" → "mv" (refers to 1st item) (count: mv=3)
6. "!4" → "!1" → "mv" (refers to 4th item which is "!1", then to "mv") (count: mv=4)
7. "cp" → cp (count: cp=2)

Final: mv=4, ls=1, cp=2
```

### Example 2 / 示例2
```
Input: ["ls", "!1", "cp", "!2"]
Output: {"mv": 0, "ls": 2, "cp": 1}

Step-by-step expansion / 逐步展开:
1. "ls" → ls (count: ls=1)
2. "!1" → "ls" (refers to 1st item) (count: ls=2)
3. "cp" → cp (count: cp=1)
4. "!2" → "!1" → "ls" (refers to 2nd item which is "!1", then to "ls") (count: ls=3)

Wait, let me recalculate:
1. "ls" → ls (count: ls=1)
2. "!1" → "ls" (count: ls=2)  
3. "cp" → cp (count: cp=1)
4. "!2" → "!1" → "ls" (but !2 refers to "!1", so it becomes "ls") (count: ls=3)

Actually: mv=0, ls=3, cp=1
```

## History Reference Rules / 历史引用规则

- "!n" refers to the nth command in the original list (1-indexed) / "!n"指向原始列表中第n个命令（从1开始）
- References can be nested and must be fully resolved / 引用可以嵌套，必须完全解析
- Invalid references (out of bounds) should be handled gracefully / 无效引用（越界）应优雅处理

## Edge Cases / 边界情况

- Empty list / 空列表
- Invalid history references (!0, !100) / 无效历史引用
- Circular references / 循环引用
- Commands other than mv, ls, cp / mv、ls、cp以外的命令

## Algorithm Approach / 算法思路

1. For each item in the list / 对列表中的每个项：
   - If it starts with "!", resolve the reference recursively / 如果以"!"开头，递归解析引用
   - Keep track of visited references to avoid infinite loops / 跟踪已访问的引用以避免无限循环
   - Count resolved commands if they are mv, ls, or cp / 如果解析的命令是mv、ls或cp则计数

2. Return counts as dictionary / 返回计数字典

**Time Complexity:** O(n × d) where n is list length, d is max reference depth
**Space Complexity:** O(d) for recursion stack