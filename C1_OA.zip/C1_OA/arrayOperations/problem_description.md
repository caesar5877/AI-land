# Array Operations / 数组操作

## Problem Statement / 问题描述

**English:**
Given two arrays `a` and `b`, and a series of operations with two types:
- Type 0: `[0, i, x]` - Execute `b[i] += x`
- Type 1: `[1, x]` - Find all pairs (i, j) where `a[i] + b[j] = x`

Return an array recording the count found for each Type 1 operation.

**中文:**
给定两个数组a和b以及一系列操作（包含以下两种）：
- 操作类型0: 输入为[0, i, x]，需要执行的操作为b[i] += x
- 操作类型1: 输入为[1, x]，需要执行的操作为找到所有使得a[i]+b[j]=x的i、j对

函数需要返回一个数组，其中记录每次执行操作1时找到的count。

## Examples / 示例

### Example 1 / 示例1
```
Input: 
a = [1, 2, 3]
b = [4, 5, 6]
operations = [[1, 7], [0, 1, 2], [1, 7]]

Output: [2, 3]

Explanation:
- [1, 7]: Find a[i]+b[j]=7 → (1,6), (3,4) → count=2
- [0, 1, 2]: b[1] += 2 → b becomes [4, 7, 6]  
- [1, 7]: Find a[i]+b[j]=7 → (1,6), (2,5), (3,4) → count=3
```

### Example 2 / 示例2
```
Input:
a = [1, 1]
b = [1, 1] 
operations = [[1, 2]]

Output: [4]

Explanation:
- [1, 2]: All combinations 1+1=2 → (0,0), (0,1), (1,0), (1,1) → count=4
```

## Input Format / 输入格式
- `a`: Array of integers
- `b`: Array of integers  
- `operations`: Array of operations [type, ...params]

## Output Format / 输出格式
- Array of integers: Count for each Type 1 operation

## Constraints / 约束条件
- 1 ≤ a.length, b.length ≤ 1000
- 1 ≤ operations.length ≤ 1000
- -1000 ≤ array elements ≤ 1000