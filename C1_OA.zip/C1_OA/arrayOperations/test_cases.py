from solution import array_operations

def test_array_operations():
    test_cases = [
        # Basic functionality
        {
            'input': ([1, 2, 3], [4, 5, 6], [[1, 7], [0, 1, 2], [1, 7]]),
            'expected': [3, 2],
            'desc': 'Example case: (1,6),(2,5),(3,4)=3, then b[1]+=2, (1,6),(3,4)=2'
        },
        {
            'input': ([1, 1], [1, 1], [[1, 2]]),
            'expected': [4],
            'desc': 'All pairs sum to target'
        },
        {
            'input': ([1, 2], [3, 4], [[1, 10]]),
            'expected': [0],
            'desc': 'No pairs sum to target'
        },
        
        # Edge cases
        {
            'input': ([5], [5], [[1, 10]]),
            'expected': [1],
            'desc': 'Single elements that sum to target'
        },
        {
            'input': ([1, 2], [3, 4], [[0, 0, 5], [1, 6]]),
            'expected': [1],
            'desc': 'Modify then count: b[0]+=5, then find sum=6'
        },
        {
            'input': ([0], [0], [[1, 0]]),
            'expected': [1],
            'desc': 'Zero sum case'
        },
        
        # Complex scenarios
        {
            'input': ([1, 2, 3], [1, 2, 3], [[1, 4], [0, 0, 1], [1, 4], [0, 1, 1], [1, 4]]),
            'expected': [3, 3, 3],
            'desc': 'Multiple modifications: (1,3),(2,2),(3,1)=3 each time'
        },
        {
            'input': ([-1, 0, 1], [-1, 0, 1], [[1, 0]]),
            'expected': [3],
            'desc': 'Negative numbers: (-1,1), (0,0), (1,-1) = 3 pairs'
        },
        {
            'input': ([1, 2], [3, 4], [[0, 0, -1], [0, 1, -2], [1, 2]]),
            'expected': [0],
            'desc': 'Negative modifications: b becomes [2,2], no sum=2 with a=[1,2]'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            a, b, ops = test['input']
            result = array_operations(a, b, ops)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_array_operations()