def array_operations(a, b, operations):
    """
    Process array operations: modify b or count pairs with target sum.
    
    Args:
        a: First array of integers
        b: Second array of integers (will be modified)
        operations: List of operations [type, ...params]
        
    Returns:
        List[int]: Count results for each Type 1 operation
    """
    # Make a copy of b to avoid modifying original
    b_copy = b[:]
    result = []
    
    for op in operations:
        if op[0] == 0:
            # Type 0: b[i] += x
            _, i, x = op
            b_copy[i] += x
        else:
            # Type 1: count pairs where a[i] + b[j] = x
            _, target = op
            count = 0
            
            for i in range(len(a)):
                for j in range(len(b_copy)):
                    if a[i] + b_copy[j] == target:
                        count += 1
            
            result.append(count)
    
    return result