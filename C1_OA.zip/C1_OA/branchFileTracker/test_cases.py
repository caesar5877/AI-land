from solution import find_branch_with_most_files

def test_branch_file_tracker():
    """Comprehensive test cases for branch file tracker problem"""
    
    test_cases = [
        # Basic case
        {
            "input": [
                "switch branch1",
                "push file1",
                "push file2",
                "switch branch2", 
                "push file1"
            ],
            "expected": "branch1",
            "desc": "Basic case - branch1 has 2 files, branch2 has 1"
        },
        
        # Duplicate files in same branch
        {
            "input": [
                "switch main",
                "push file1",
                "push file1",
                "push file2",
                "switch dev",
                "push file3"
            ],
            "expected": "main",
            "desc": "Duplicate files - main has 2 unique files, dev has 1"
        },
        
        # Multiple branches
        {
            "input": [
                "switch branch1",
                "push a.txt",
                "switch branch2", 
                "push b.txt",
                "push c.txt",
                "switch branch3",
                "push d.txt",
                "push e.txt",
                "push f.txt"
            ],
            "expected": "branch3",
            "desc": "Multiple branches - branch3 has most files (3)"
        },
        
        # Same files across branches
        {
            "input": [
                "switch main",
                "push shared.txt",
                "push main_only.txt",
                "switch feature",
                "push shared.txt",
                "push feature1.txt",
                "push feature2.txt",
                "push feature3.txt"
            ],
            "expected": "feature",
            "desc": "Shared files - feature has 4 unique files"
        },
        
        # Single branch
        {
            "input": [
                "switch solo",
                "push file1",
                "push file2",
                "push file3"
            ],
            "expected": "solo",
            "desc": "Single branch with multiple files"
        },
        
        # Empty pushes after switch
        {
            "input": [
                "switch branch1",
                "push file1",
                "switch branch2"
            ],
            "expected": "branch1", 
            "desc": "Branch2 has no files, branch1 has 1"
        },
        
        # Complex scenario
        {
            "input": [
                "switch master",
                "push readme.md",
                "push main.py",
                "switch develop",
                "push test.py",
                "push readme.md",
                "push config.json",
                "push utils.py",
                "switch hotfix",
                "push patch.py"
            ],
            "expected": "develop",
            "desc": "Complex scenario - develop has 4 unique files"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = find_branch_with_most_files(test["input"])
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Commands: {test['input']}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        print()
    
    print("-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_branch_file_tracker()