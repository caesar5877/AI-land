# Branch File Tracker Problem / 分支文件跟踪问题

## Problem Statement / 问题描述

### English
Given a text (list of strings/lines) representing git-like commands, find the branch name with the most unique files.

### 中文
给定一个文本（字符串/行的列表）表示git类似命令，找到具有最多唯一文件的分支名称。

## Requirements / 要求

### English
- Parse commands: "switch [branch_name]" and "push [file_name]"
- Track unique files per branch using a dictionary {branch_name: set of unique file names}
- Return the branch name with the most unique files
- Guarantee: no tie in the result

### 中文
- 解析命令："switch [branch_name]"和"push [file_name]"
- 使用字典跟踪每个分支的唯一文件 {branch_name: set of unique file names}
- 返回具有最多唯一文件的分支名称
- 保证：结果中无平局

## Commands / 命令

### English
- `switch branch_name`: Switch to the specified branch
- `push file_name`: Add file to current branch

### 中文
- `switch branch_name`: 切换到指定分支
- `push file_name`: 将文件添加到当前分支

## Examples / 示例
```
Input:
[
    "switch branch1",
    "push file1", 
    "push file2",
    "switch branch2",
    "push file1",
    "push file2"
]

Processing:
- switch branch1 → current_branch = "branch1"
- push file1 → branch1 files = {file1}
- push file2 → branch1 files = {file1, file2}
- switch branch2 → current_branch = "branch2"  
- push file1 → branch2 files = {file1}
- push file2 → branch2 files = {file1, file2}

Result: Both branches have 2 files, but problem guarantees no tie
```

## Output / 输出

### English
Return the branch name (string) with the most unique files.

### 中文
返回具有最多唯一文件的分支名称（字符串）。