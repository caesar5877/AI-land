def find_branch_with_most_files(commands):
    """
    Find the branch name with the most unique files.
    
    Args:
        commands: List of strings containing "switch branch_name" or "push file_name"
        
    Returns:
        str: Branch name with the most unique files
    """
    # Dictionary to track files per branch using sets for uniqueness
    branches = {}
    # Track which branch we're currently on
    current_branch = None
    
    # Process each command sequentially
    for command in commands:
        # Split command into parts for parsing
        parts = command.split()
        
        if parts[0] == "switch":
            # Switch to specified branch
            current_branch = parts[1]
            # Initialize branch with empty set if first time seeing it
            if current_branch not in branches:
                branches[current_branch] = set()
                
        elif parts[0] == "push" and current_branch:
            # Push file to current branch (only if we're on a branch)
            # Use set to automatically handle duplicate files
            branches[current_branch].add(parts[1])
    
    # Find branch with maximum number of unique files
    # Use len() of each branch's file set as comparison key
    return max(branches.keys(), key=lambda branch: len(branches[branch]))