def get_champion_and_runner_up(wins, draws, goals_for, goals_against):
    """
    Determine champion and runner-up teams based on points and goal difference.
    
    Args:
        wins: List of win counts for each team
        draws: List of draw counts for each team
        goals_for: List of goals scored by each team
        goals_against: List of goals conceded by each team
        
    Returns:
        tuple: (champion_index, runner_up_index)
    """
    # Create list to store team statistics
    teams = []
    
    # Calculate points and goal difference for each team
    for i in range(len(wins)):
        # Calculate total points: 3 points per win, 1 point per draw
        points = wins[i] * 3 + draws[i]
        
        # Calculate goal difference: goals scored minus goals conceded
        goal_diff = goals_for[i] - goals_against[i]
        
        # Store tuple: (points, goal_difference, team_index)
        teams.append((points, goal_diff, i))
    
    # Sort teams by ranking criteria:
    # Primary: highest points (negative for descending order)
    # Secondary: highest goal difference (negative for descending order)
    teams.sort(key=lambda x: (-x[0], -x[1]))
    
    # Return indices of champion (1st place) and runner-up (2nd place)
    return teams[0][2], teams[1][2]