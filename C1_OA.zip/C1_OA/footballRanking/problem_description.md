# Football League Ranking Problem / 足球联赛排名问题

## Problem Statement / 问题描述

### English
Given 4 arrays representing team statistics, determine the champion and runner-up teams.

### 中文
给4个数组，分别代表各球队胜场数，平局数，进球数，丢球数。胜3分平1分，同分则比较净胜球数。返回冠军和亚军球队的index。

## Input / 输入

### English
- `wins`: Array of win counts for each team
- `draws`: Array of draw counts for each team  
- `goals_for`: Array of goals scored by each team
- `goals_against`: Array of goals conceded by each team

### 中文
- `wins`: 各球队胜场数数组
- `draws`: 各球队平局数数组
- `goals_for`: 各球队进球数数组
- `goals_against`: 各球队丢球数数组

## Scoring Rules / 计分规则

### English
- Win: 3 points
- Draw: 1 point
- Loss: 0 points

### 中文
- 胜利：3分
- 平局：1分
- 失败：0分

## Ranking Rules / 排名规则

### English
1. Teams are ranked by total points (wins × 3 + draws × 1)
2. If points are equal, rank by goal difference (goals_for - goals_against)
3. Higher goal difference ranks higher

### 中文
1. 按总积分排名（胜场数 × 3 + 平局数 × 1）
2. 积分相同时，按净胜球数排名（进球数 - 丢球数）
3. 净胜球数越高排名越靠前

## Output / 输出

### English
Return a tuple containing the indices of:
1. Champion (1st place team)
2. Runner-up (2nd place team)

### 中文
返回包含以下索引的元组：
1. 冠军（第1名球队）
2. 亚军（第2名球队）

## Examples / 示例
- Team 0: 5 wins, 2 draws → 17 points, goal difference +3
- Team 1: 4 wins, 5 draws → 17 points, goal difference +1  
- Team 0 ranks higher due to better goal difference