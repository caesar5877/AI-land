from solution import get_champion_and_runner_up

def test_football_ranking():
    """Comprehensive test cases for football ranking function"""
    
    test_cases = [
        # Basic cases
        {
            "wins": [5, 4, 3, 2],
            "draws": [2, 2, 2, 2], 
            "goals_for": [15, 12, 10, 8],
            "goals_against": [8, 10, 12, 15],
            "expected": (0, 1),
            "desc": "Clear ranking by points"
        },
        
        # Same points, different goal difference
        {
            "wins": [4, 4, 3, 2],
            "draws": [5, 5, 6, 8],
            "goals_for": [20, 15, 12, 10],
            "goals_against": [10, 12, 15, 20],
            "expected": (0, 1),
            "desc": "Same points, rank by goal difference"
        },
        
        # Edge case: same points and goal difference
        {
            "wins": [5, 5, 3, 2],
            "draws": [0, 0, 3, 4],
            "goals_for": [10, 10, 8, 6],
            "goals_against": [5, 5, 10, 12],
            "expected": (0, 1),
            "desc": "Same points and goal diff, first team wins"
        },
        
        # Mixed scenario
        {
            "wins": [3, 6, 4, 2],
            "draws": [6, 0, 4, 6],
            "goals_for": [12, 18, 14, 8],
            "goals_against": [8, 6, 10, 16],
            "expected": (1, 2),
            "desc": "Mixed points and goal differences"
        },
        
        # All teams equal points
        {
            "wins": [3, 3, 3, 3],
            "draws": [3, 3, 3, 3],
            "goals_for": [15, 12, 18, 10],
            "goals_against": [10, 10, 15, 15],
            "expected": (0, 2),
            "desc": "Equal points, rank by goal difference"
        }
    ]
    
    print("Running comprehensive test cases...")
    print("-" * 70)
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = get_champion_and_runner_up(
            test["wins"], test["draws"], 
            test["goals_for"], test["goals_against"]
        )
        expected = test["expected"]
        status = "PASS" if result == expected else "FAIL"
        
        if status == "PASS":
            passed += 1
            
        print(f"Test {i}: {test['desc']}")
        print(f"  Result: {result} (expected: {expected}) [{status}]")
        
        if status == "FAIL":
            # Show team stats for failed tests
            for j in range(len(test["wins"])):
                points = test["wins"][j] * 3 + test["draws"][j]
                goal_diff = test["goals_for"][j] - test["goals_against"][j]
                print(f"  Team {j}: {points} pts, {goal_diff:+d} goal diff")
        print()
    
    print("-" * 70)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("All tests passed!")
    else:
        print(f"{total - passed} test(s) failed!")

if __name__ == "__main__":
    test_football_ranking()