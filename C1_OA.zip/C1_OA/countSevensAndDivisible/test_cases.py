from solution import count_sevens_and_divisible

def run_tests():
    test_cases = [
        {
            'input': [777, 771, 747, 123, 7777],
            'expected': 3,
            'desc': 'Basic case with mixed valid/invalid numbers'
        },
        {
            'input': [77, 777, 7],
            'expected': 1,
            'desc': 'Case with only one valid number'
        },
        {
            'input': [],
            'expected': 0,
            'desc': 'Empty list'
        },
        {
            'input': [777],
            'expected': 1,
            'desc': 'Single valid number'
        },
        {
            'input': [7777, 77777],
            'expected': 0,
            'desc': 'Numbers with many 7s but not divisible by 3'
        },
        {
            'input': [-777, -771],
            'expected': 2,
            'desc': 'Negative numbers that satisfy conditions'
        },
        {
            'input': [123, 456, 789],
            'expected': 0,
            'desc': 'Numbers without any 7s'
        },
        {
            'input': [7770, 7773, 7776],
            'expected': 3,
            'desc': 'Numbers ending in different digits, all divisible by 3'
        },
        {
            'input': [77777777],
            'expected': 0,
            'desc': 'Large number with many 7s but not divisible by 3'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        result = count_sevens_and_divisible(test['input'])
        status = "PASS" if result == test['expected'] else "FAIL"
        print(f"Test {i}: {status}")
        print(f"  Description: {test['desc']}")
        print(f"  Input: {test['input']}")
        print(f"  Expected: {test['expected']}, Got: {result}")
        
        if result == test['expected']:
            passed += 1
        print()
    
    print(f"Results: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    run_tests()