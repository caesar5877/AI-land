# Count Sevens and Divisible / 计算包含七且可被三整除的数字

## Problem Statement / 问题描述

**English:**
Given a list of integers, return the count of integers that satisfy BOTH conditions:
1. Contains at least two '7' digits
2. Can be divided by 3 (divisible by 3)

**中文:**
给定一个整数列表，返回同时满足以下两个条件的整数个数：
1. 包含至少两个数字'7'
2. 能被3整除

## Requirements / 要求

- Input: List of integers / 输入：整数列表
- Output: Count of valid integers / 输出：有效整数的个数
- Both conditions must be satisfied / 两个条件必须同时满足

## Examples / 示例

### Example 1 / 示例1
```
Input: [777, 771, 747, 123, 7777]
Output: 3

Explanation / 解释:
- 777: has 3 sevens (≥2) ✓, 777 ÷ 3 = 259 ✓ → Valid
- 771: has 2 sevens (≥2) ✓, 771 ÷ 3 = 257 ✓ → Valid  
- 747: has 2 sevens (≥2) ✓, 747 ÷ 3 = 249 ✓ → Valid
- 123: has 0 sevens (< 2) ✗ → Invalid
- 7777: has 4 sevens (≥2) ✓, 7777 ÷ 3 = 2592.33... ✗ → Invalid
```

### Example 2 / 示例2
```
Input: [77, 777, 7]
Output: 1

Explanation / 解释:
- 77: has 2 sevens (≥2) ✓, 77 ÷ 3 = 25.67... ✗ → Invalid
- 777: has 3 sevens (≥2) ✓, 777 ÷ 3 = 259 ✓ → Valid
- 7: has 1 seven (< 2) ✗ → Invalid
```

## Edge Cases / 边界情况

- Empty list → 0
- Negative numbers with sevens
- Single digit numbers
- Very large numbers

## Algorithm Approach / 算法思路

1. For each integer in the list / 对列表中的每个整数：
   - Convert to string to count '7' digits / 转换为字符串计算'7'的个数
   - Check if count of '7' ≥ 2 / 检查'7'的个数是否≥2
   - Check if number % 3 == 0 / 检查数字是否能被3整除
   - If both conditions true, increment counter / 如果两个条件都满足，计数器加1

2. Return final counter / 返回最终计数器