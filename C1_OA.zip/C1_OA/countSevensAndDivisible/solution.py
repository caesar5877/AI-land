def count_sevens_and_divisible(nums):
    """
    Count integers that contain at least two '7' digits and are divisible by 3.
    
    Args:
        nums (list[int]): List of integers to check
        
    Returns:
        int: Count of integers satisfying both conditions
    """
    # Initialize counter for numbers meeting both criteria
    count = 0
    
    # Check each number in the input list
    for num in nums:
        # Convert to string to count digit occurrences
        # Use abs() to handle negative numbers (ignore sign for digit counting)
        digit_string = str(abs(num))
        
        # Check both conditions:
        # 1. Contains at least two '7' digits
        # 2. Is divisible by 3 (remainder is 0)
        if digit_string.count('7') >= 2 and num % 3 == 0:
            count += 1
            
    # Return total count of numbers satisfying both conditions
    return count