def count_suffix_pairs(words):
    """
    Count pairs where one string is a suffix of another.
    
    Args:
        words: List of strings
        
    Returns:
        int: Number of valid pairs
    """
    # Initialize counter for valid suffix pairs
    count = 0
    n = len(words)
    
    # Check all possible pairs (i, j) where i < j
    for i in range(n):
        for j in range(i + 1, n):  # Avoid duplicate pairs and self-comparison
            # Check if either string is a suffix of the other
            # endswith() method efficiently checks suffix relationship
            if words[i].endswith(words[j]) or words[j].endswith(words[i]):
                count += 1  # Found valid suffix pair
    
    # Return total count of suffix pairs
    return count