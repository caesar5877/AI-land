def merge_strings(s1, s2):
    """
    Merge two strings by alternating from start/end with character doubling.
    
    Args:
        s1: First string
        s2: Second string
        
    Returns:
        str: Merged string result
    """
    # Store result characters in list for efficient concatenation
    result = []
    # Pointer for s1 from start, pointer for s2 from end
    i, j = 0, len(s2) - 1
    
    # Process characters alternately while both strings have characters
    while i < len(s1) and j >= 0:
        # Get current character from s1 start and s2 end
        char1, char2 = s1[i], s2[j]
        
        # Check if characters at current positions match
        if char1 == char2:
            # Double the character if they match
            result.append(char1 + char1)
        else:
            # Add both characters separately if they don't match
            result.append(char1)
            result.append(char2)
        
        # Move to next positions
        i += 1
        j -= 1
    
    # Add any remaining characters from s1 (left to right)
    while i < len(s1):
        result.append(s1[i])
        i += 1
    
    # Add any remaining characters from s2 (right to left)
    while j >= 0:
        result.append(s2[j])
        j -= 1
    
    # Join all characters into final result string
    return ''.join(result)