from solution import merge_strings

def test_merge_strings():
    test_cases = [
        # Basic functionality
        {
            'input': ("abc", "def"),
            'expected': "afbecd",
            'desc': 'Basic merge without matching characters'
        },
        {
            'input': ("abp", "jda"),
            'expected': "aabdpj",
            'desc': 'First characters match, double them'
        },
        {
            'input': ("abp", "abp"),
            'expected': "apbbpa",
            'desc': 'Mixed matching pattern'
        },
        
        # Edge cases
        {
            'input': ("a", "a"),
            'expected': "aa",
            'desc': 'Single matching characters'
        },
        {
            'input': ("a", "b"),
            'expected': "ab",
            'desc': 'Single non-matching characters'
        },
        {
            'input': ("", "abc"),
            'expected': "cba",
            'desc': 'Empty first string'
        },
        
        # Complex scenarios
        {
            'input': ("hello", "world"),
            'expected': "hdellrloow",
            'desc': 'Different length strings'
        },
        {
            'input': ("abc", "cba"),
            'expected': "aabbcc",
            'desc': 'Palindromic pattern'
        },
        {
            'input': ("test", "best"),
            'expected': "ttessetb",
            'desc': 'Partial matches'
        }
    ]
    
    passed = 0
    total = len(test_cases)
    
    for i, test in enumerate(test_cases, 1):
        try:
            s1, s2 = test['input']
            result = merge_strings(s1, s2)
            
            if result == test['expected']:
                print(f"PASS Test {i}: {test['desc']}")
                passed += 1
            else:
                print(f"FAIL Test {i}: {test['desc']}")
                print(f"  Expected: {test['expected']}")
                print(f"  Got: {result}")
        except Exception as e:
            print(f"FAIL Test {i}: {test['desc']}")
            print(f"  Error: {e}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    return passed == total

if __name__ == "__main__":
    test_merge_strings()