# String Merge / 字符串合并

## Problem Statement / 问题描述

**English:**
Given two strings, merge them by alternating characters: take from s1 left-to-right and s2 right-to-left. If characters at corresponding positions match, double that character instead of adding both.

**中文:**
给出两个字符串，交替合并字符：从s1从左到右取字符，从s2从右到左取字符。如果对应位置的字符相同，就将该字符加倍而不是添加两个字符。

## Examples / 示例

### Example 1 / 示例1
```
Input: s1 = "abc", s2 = "def"
Output: "afbecd"
Explanation: 'a'(s1[0]) + 'f'(s2[2]), 'b'(s1[1]) + 'e'(s2[1]), 'c'(s1[2]) + 'd'(s2[0])
```

### Example 2 / 示例2
```
Input: s1 = "abp", s2 = "jda"
Output: "aabdpj"
Explanation: 'a'(s1[0]) matches 'a'(s2[2]) -> "aa", 'b'(s1[1]) + 'd'(s2[1]), 'p'(s1[2]) + 'j'(s2[0])
```

### Example 3 / 示例3
```
Input: s1 = "abp", s2 = "abp"
Output: "apbbpa"
Explanation: 'a'(s1[0]) + 'p'(s2[2]), 'b'(s1[1]) matches 'b'(s2[1]) -> "bb", 'p'(s1[2]) + 'a'(s2[0])
```

## Input Format / 输入格式
- `s1`: First string
- `s2`: Second string

## Output Format / 输出格式
- String: Merged result

## Constraints / 约束条件
- 1 ≤ s1.length, s2.length ≤ 100
- Strings contain only lowercase letters