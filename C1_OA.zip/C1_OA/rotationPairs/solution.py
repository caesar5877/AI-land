def count_rotation_pairs(nums):
    """
    Count pairs of numbers that can be the same by rotating one of them.
    
    Args:
        nums (list[int]): List of integers to check
        
    Returns:
        int: Number of valid rotation pairs
    """
    # Need at least 2 numbers to form pairs
    if len(nums) < 2:
        return 0
    
    # Counter for valid rotation pairs
    count = 0
    
    # Check all possible pairs (i, j) where i < j
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            # Convert numbers to strings for rotation checking
            s1, s2 = str(nums[i]), str(nums[j])
            
            # Two conditions for valid rotation pair:
            # 1. Same length (same number of digits)
            # 2. One string is a rotation of the other
            #    Check by seeing if s2 appears in s1+s1 (all rotations of s1)
            if len(s1) == len(s2) and s2 in s1 + s1:
                count += 1
                
    # Return total count of valid rotation pairs
    return count